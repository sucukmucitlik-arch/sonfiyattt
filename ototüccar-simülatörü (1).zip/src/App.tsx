import React, { useState } from 'react';
import { GameProvider, useGame } from './store/GameContext';
import { Market } from './components/Market';
import { Garage } from './components/Garage';
import { OffersView } from './components/OffersView';
import { CollectionView } from './components/CollectionView';
import { Shop } from './components/Shop';
import { AchievementsView } from './components/AchievementsView';
import { CAR_DATABASE } from './data/cars';
import { ACHIEVEMENTS_DATA } from './data/achievements';
import { IntroSplash } from './components/IntroSplash';
import { InteractiveTutorial } from './components/InteractiveTutorial';
import { TradeResultModal } from './components/TradeResultModal';
import { formatMoney, generateFullMarketCatalog } from './utils';
import { 
  Store, 
  ShoppingCart, 
  ChevronRight, 
  Wallet, 
  Calendar, 
  Sun, 
  Moon, 
  Info, 
  Flame, 
  Award, 
  Bell, 
  X, 
  CheckCircle,
  TrendingUp,
  Car,
  RotateCcw,
  Sparkles,
  ArrowUpRight,
  Warehouse,
  Trophy,
  Gift,
  GraduationCap
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const MainLayout: React.FC = () => {
  const { state, dispatch } = useGame();
  const [activeTab, setActiveTab] = useState<'market' | 'garage' | 'offers' | 'collection' | 'shop' | 'achievements'>('market');
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [showIntro, setShowIntro] = useState(true);
  const [showTutorial, setShowTutorial] = useState(false);
  const [showResetModal, setShowResetModal] = useState(false);
  const [restartTutorialOnReset, setRestartTutorialOnReset] = useState(true);

  // Toggle dark mode on document element
  React.useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleIntroComplete = () => {
    setShowIntro(false);
    if (!state.tutorialCompleted && (!state.tutorialStep || state.tutorialStep === 'idle')) {
      dispatch({ type: 'START_INTERACTIVE_TUTORIAL' });
    }
  };

  const handleNextDay = () => {
    dispatch({ 
      type: 'NEXT_DAY', 
      payload: { 
        newMarket: generateFullMarketCatalog(), 
        newOffers: [] 
      } 
    });
  };

  const handleConfirmReset = () => {
    try {
      localStorage.removeItem('ototuccar_save');
    } catch (e) {
      console.warn('Storage clear error', e);
    }

    const freshMarket = generateFullMarketCatalog();
    dispatch({ 
      type: 'RESET_GAME', 
      payload: { initialMarket: freshMarket } 
    });

    if (restartTutorialOnReset) {
      dispatch({ type: 'START_INTERACTIVE_TUTORIAL' });
    }

    setActiveTab('market');
    setShowResetModal(false);

    dispatch({
      type: 'ADD_NOTIFICATION',
      payload: {
        title: 'Hesap Sıfırlandı 🔄',
        message: 'Galeri sıfırlandı. 1.000.000 ₺ başlangıç sermayesiyle yeniden başladınız!',
        type: 'info',
      }
    });
  };

  const netWorth = state.money + state.garage.reduce((sum, car) => sum + car.purchasePrice, 0);

  const getDealerTitle = (rep: number) => {
    if (rep >= 85) return 'Seçkin Galeri';
    if (rep >= 70) return 'Güvenilir Esnaf';
    if (rep >= 50) return 'Gelişen Tüccar';
    return 'Acemi Galerici';
  };

  const totalCatalogModels = CAR_DATABASE.length;
  const collectedStampsCount = state.collectedModelKeys?.length || 0;

  const readyAchievementsCount = React.useMemo(() => {
    const claimedSet = new Set(state.claimedAchievementIds || []);
    const uniqueCatalogModels = new Set(CAR_DATABASE.map(c => `${c.brand.trim().toLowerCase()}_${c.model.trim().toLowerCase()}`)).size;
    return ACHIEVEMENTS_DATA.filter(a => {
      if (claimedSet.has(a.id)) return false;
      const progress = a.getProgress(state, uniqueCatalogModels);
      return progress.isCompleted;
    }).length;
  }, [state]);

  return (
    <div className="min-h-screen bg-zinc-100 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 transition-colors duration-300 flex flex-col font-sans pb-20 md:pb-6 selection:bg-orange-500 selection:text-white">
      {/* Sucuk Mucitlik A.Ş. Presents Cinematic Intro */}
      <AnimatePresence>
        {showIntro && <IntroSplash onComplete={handleIntroComplete} />}
      </AnimatePresence>

      {/* Interactive Step-by-Step Tutorial & Academy */}
      <InteractiveTutorial 
        isOpen={showTutorial} 
        onClose={() => setShowTutorial(false)} 
        onNavigateTab={(tab) => setActiveTab(tab)}
      />

      {/* Post-Trade A/B/C/D Performance Report Modal */}
      <TradeResultModal
        report={state.activeTradeReport}
        onClose={() => dispatch({ type: 'CLOSE_TRADE_REPORT' })}
        onNavigateToGarage={() => setActiveTab('garage')}
        onNavigateToOffers={() => setActiveTab('offers')}
      />

      {/* Account Reset Confirmation Modal */}
      <AnimatePresence>
        {showResetModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-zinc-900 border border-zinc-700 text-white rounded-3xl p-6 sm:p-7 max-w-md w-full shadow-2xl relative"
            >
              <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mb-4 border border-rose-500/30 shadow-lg shadow-rose-500/10">
                <RotateCcw size={24} />
              </div>

              <h3 className="text-xl font-black text-white">
                Hesabı & Galeriyi Sıfırla
              </h3>

              <p className="text-xs text-zinc-300 mt-2 leading-relaxed">
                Galerinizdeki tüm vitrin araçları, müşteri teklifleri, pul koleksiyonu ve geliştirmeler silinecek; kasanız <strong className="text-orange-400 font-bold">1.000.000 ₺</strong> başlangıç sermayesine döndürülecektir.
              </p>

              <div className="mt-4 bg-zinc-800/80 border border-zinc-700 rounded-xl p-3 flex items-center gap-2.5">
                <input
                  type="checkbox"
                  id="resetTutCheckbox"
                  checked={restartTutorialOnReset}
                  onChange={(e) => setRestartTutorialOnReset(e.target.checked)}
                  className="w-4 h-4 rounded text-orange-500 focus:ring-orange-500 bg-zinc-900 border-zinc-600"
                />
                <label htmlFor="resetTutCheckbox" className="text-xs text-zinc-200 font-semibold cursor-pointer select-none">
                  Canlı Fiat Egea alım-satım öğreticisini de baştan başlat
                </label>
              </div>

              <div className="flex items-center gap-3 mt-6">
                <button
                  onClick={() => setShowResetModal(false)}
                  className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold py-2.5 px-4 rounded-xl text-xs transition-colors"
                >
                  Vazgeç
                </button>
                <button
                  onClick={handleConfirmReset}
                  className="flex-1 bg-rose-600 hover:bg-rose-700 text-white font-black py-2.5 px-4 rounded-xl text-xs transition-all shadow-lg shadow-rose-600/30 flex items-center justify-center gap-1.5 active:scale-95"
                >
                  <RotateCcw size={14} />
                  <span>Evet, Sıfırla</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Mobile-Friendly Top Bar */}
      <header className="sticky top-0 z-40 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md border-b border-zinc-200/80 dark:border-zinc-800 shadow-sm">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 h-14 sm:h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-tr from-orange-600 to-amber-500 text-white rounded-xl flex items-center justify-center font-black text-lg sm:text-xl shadow-md shadow-orange-500/20 flex-shrink-0">
              <Car size={20} />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-base sm:text-lg font-black tracking-tight leading-none text-zinc-900 dark:text-white">
                  {state.galleryName || 'SonFiyat'}
                </h1>
                <span className="bg-orange-500/10 text-orange-600 dark:text-orange-400 text-[9px] sm:text-[10px] font-black uppercase px-1.5 sm:px-2 py-0.5 rounded-md border border-orange-500/20">
                  Oto Galeri
                </span>
              </div>
              <div className="flex items-center gap-1 text-[10px] sm:text-[11px] text-zinc-400 font-semibold mt-0.5">
                <Award size={11} className="text-orange-500" />
                <span className="truncate max-w-[90px] sm:max-w-none">{getDealerTitle(state.reputation)}</span>
                <span>•</span>
                <span className="text-zinc-500 font-bold">%{state.reputation}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Tutorial Reopen Button */}
            <button
              onClick={() => setShowTutorial(true)}
              className="flex items-center gap-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30 px-2.5 py-1.5 rounded-xl font-bold text-xs transition-all active:scale-95"
              title="Öğretici ve Rehberi Aç"
            >
              <GraduationCap size={15} />
              <span className="hidden sm:inline">Öğretici</span>
            </button>

            {/* Reset Game Button */}
            <button
              onClick={() => setShowResetModal(true)}
              className="flex items-center gap-1 bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-500/30 px-2.5 py-1.5 rounded-xl font-bold text-xs transition-all active:scale-95"
              title="Galeriyi ve Hesabı Baştan Sıfırla"
            >
              <RotateCcw size={14} />
              <span className="hidden md:inline">Sıfırla</span>
            </button>

            {/* Money Pill */}
            <div className="flex flex-col items-end bg-orange-50 dark:bg-zinc-800/80 px-2.5 sm:px-3 py-1 rounded-xl border border-orange-200/60 dark:border-zinc-700">
              <span className="text-[9px] uppercase font-bold text-zinc-500 dark:text-zinc-400 flex items-center gap-1 leading-none">
                <Wallet size={9} className="text-orange-500" /> Bakiye
              </span>
              <span className="text-xs sm:text-base font-black text-orange-600 dark:text-orange-400 leading-tight">
                {formatMoney(state.money)}
              </span>
            </div>
            
            {/* Dark Mode toggle */}
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2 text-zinc-500 hover:text-zinc-900 dark:hover:text-white bg-zinc-100 dark:bg-zinc-800 rounded-xl transition-colors active:scale-95"
              title="Karanlık / Aydınlık Mod"
            >
              {isDarkMode ? <Sun size={16} /> : <Moon size={16} />}
            </button>
            
            {/* Day button */}
            <button
              onClick={handleNextDay}
              className="flex items-center gap-1 bg-orange-500 hover:bg-orange-600 active:scale-95 text-white px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-xl font-bold text-[11px] sm:text-xs transition-all shadow-sm shadow-orange-500/20"
              title="Günü ilerlet"
            >
              <Calendar size={13} />
              <span>Gün {state.day}</span>
              <ChevronRight size={13} className="-ml-0.5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Layout */}
      <main className="flex-grow max-w-7xl mx-auto w-full px-3 sm:px-6 py-4 sm:py-6 flex flex-col md:flex-row gap-6">
        
        {/* Desktop Sidebar Nav */}
        <aside className="hidden md:flex md:w-64 flex-shrink-0 flex-col gap-2">
          <button
            onClick={() => setActiveTab('market')}
            className={`flex items-center gap-3 px-4 py-3 rounded-2xl font-bold text-sm transition-all whitespace-nowrap
              ${activeTab === 'market' 
                ? 'bg-orange-500 text-white shadow-md shadow-orange-500/20' 
                : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-800/50'
              }`}
          >
            <ShoppingCart size={18} />
            <span>Piyasa İlanları</span>
            <span className="ml-auto text-xs font-black opacity-90">
              {state.market.length}
            </span>
          </button>
          
          <button
            onClick={() => {
              setActiveTab('garage');
              if (state.tutorialStep === 'go_garage') {
                dispatch({ type: 'SET_TUTORIAL_STEP', payload: 'repair_egea' });
              }
            }}
            className={`flex items-center gap-3 px-4 py-3 rounded-2xl font-bold text-sm transition-all whitespace-nowrap relative
              ${activeTab === 'garage' 
                ? 'bg-orange-500 text-white shadow-md shadow-orange-500/20' 
                : state.tutorialStep === 'go_garage'
                  ? 'bg-orange-500/20 text-orange-600 dark:text-orange-400 ring-2 ring-orange-500 animate-pulse font-black'
                  : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-800/50'
              }`}
          >
            <Store size={18} />
            <span>Galerim & Vitrin</span>
            {state.tutorialStep === 'go_garage' && (
              <span className="ml-auto bg-orange-500 text-white text-[10px] font-black px-1.5 py-0.5 rounded animate-bounce">
                BURAYA TIKLA
              </span>
            )}
            {state.garage.length > 0 && state.tutorialStep !== 'go_garage' && (
              <span className={`ml-auto text-xs py-0.5 px-2 rounded-full font-bold ${
                activeTab === 'garage' ? 'bg-white text-orange-600' : 'bg-orange-500 text-white'
              }`}>
                {state.garage.length}
              </span>
            )}
          </button>

          <button
            onClick={() => {
              setActiveTab('offers');
              if (state.tutorialStep === 'go_offers') {
                dispatch({ type: 'SET_TUTORIAL_STEP', payload: 'bargain_egea' });
              }
            }}
            className={`flex items-center gap-3 px-4 py-3 rounded-2xl font-bold text-sm transition-all whitespace-nowrap relative
              ${activeTab === 'offers' 
                ? 'bg-orange-500 text-white shadow-md shadow-orange-500/20' 
                : state.tutorialStep === 'go_offers'
                  ? 'bg-orange-500/20 text-orange-600 dark:text-orange-400 ring-2 ring-orange-500 animate-pulse font-black'
                  : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-800/50'
              }`}
          >
            <Flame size={18} className={state.offers.length > 0 ? "fill-orange-400 text-orange-400" : ""} />
            <span>Gelen Teklifler</span>
            {state.tutorialStep === 'go_offers' ? (
              <span className="ml-auto bg-orange-500 text-white text-[10px] font-black px-1.5 py-0.5 rounded animate-bounce">
                BURAYA TIKLA
              </span>
            ) : state.offers.length > 0 ? (
              <span className="ml-auto bg-red-500 text-white text-xs font-black py-0.5 px-2 rounded-full animate-bounce">
                {state.offers.length}
              </span>
            ) : null}
          </button>

          <button
            onClick={() => setActiveTab('collection')}
            className={`flex items-center gap-3 px-4 py-3 rounded-2xl font-bold text-sm transition-all whitespace-nowrap relative
              ${activeTab === 'collection' 
                ? 'bg-amber-500 text-white shadow-md shadow-amber-500/20' 
                : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-800/50'
              }`}
          >
            <Sparkles size={18} className={collectedStampsCount > 0 ? "text-amber-400" : ""} />
            <span>Koleksiyon & Pul</span>
            <span className={`ml-auto text-xs py-0.5 px-2 rounded-full font-bold ${
              activeTab === 'collection' ? 'bg-white text-amber-600' : 'bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-300'
            }`}>
              {collectedStampsCount}/{totalCatalogModels}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('shop')}
            className={`flex items-center gap-3 px-4 py-3 rounded-2xl font-bold text-sm transition-all whitespace-nowrap relative
              ${activeTab === 'shop' 
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20' 
                : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-800/50'
              }`}
          >
            <Warehouse size={18} />
            <span>Dükkan & Seviyeler</span>
            <span className={`ml-auto text-[10px] font-black py-0.5 px-2 rounded-full uppercase tracking-wider ${
              activeTab === 'shop' ? 'bg-white text-blue-600' : 'bg-blue-100 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400'
            }`}>
              Geliştir
            </span>
          </button>

          <button
            onClick={() => setActiveTab('achievements')}
            className={`flex items-center gap-3 px-4 py-3 rounded-2xl font-bold text-sm transition-all whitespace-nowrap relative
              ${activeTab === 'achievements' 
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-zinc-950 shadow-md shadow-amber-500/25 font-black' 
                : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-800/50'
              }`}
          >
            <Trophy size={18} className={readyAchievementsCount > 0 ? "text-amber-500 fill-amber-400 dark:text-amber-400" : ""} />
            <span>Başarımlar & Rozet</span>
            {readyAchievementsCount > 0 ? (
              <span className="ml-auto bg-emerald-500 text-white text-[10px] font-black py-0.5 px-2 rounded-full animate-bounce shadow">
                +{readyAchievementsCount} Ödül
              </span>
            ) : (
              <span className={`ml-auto text-[10px] font-bold py-0.5 px-2 rounded-full ${
                activeTab === 'achievements' ? 'bg-zinc-950/20 text-zinc-900' : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400'
              }`}>
                Görevler
              </span>
            )}
          </button>
          
          <div className="mt-auto pt-6 space-y-3">
            {/* Quick Dealer stats box */}
            <div className="bg-white dark:bg-zinc-900 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-sm">
              <span className="text-[10px] uppercase font-bold text-zinc-400 block mb-2">Galeri Özeti</span>
              <div className="space-y-1.5 text-xs font-semibold">
                <div className="flex justify-between text-zinc-600 dark:text-zinc-400">
                  <span>Satılan:</span>
                  <span className="font-bold text-zinc-900 dark:text-white">{state.carsSold} araç</span>
                </div>
                <div className="flex justify-between text-zinc-600 dark:text-zinc-400">
                  <span>Toplam Kâr:</span>
                  <span className={`font-bold ${state.totalProfit >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                    {formatMoney(state.totalProfit)}
                  </span>
                </div>
                <div className="flex justify-between text-zinc-600 dark:text-zinc-400">
                  <span>Net Varlık:</span>
                  <span className="font-bold text-zinc-900 dark:text-white">
                    {formatMoney(netWorth)}
                  </span>
                </div>
                <div className="flex justify-between text-zinc-600 dark:text-zinc-400 pt-1 border-t border-zinc-100 dark:border-zinc-800">
                  <span>Toplanan Pul:</span>
                  <span className="font-bold text-amber-600 dark:text-amber-400">
                    {collectedStampsCount} / {totalCatalogModels}
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-orange-50/50 dark:bg-zinc-900/60 p-4 rounded-2xl border border-orange-200/50 dark:border-zinc-800 space-y-2">
              <div className="flex items-center justify-between text-zinc-900 dark:text-white font-bold text-xs">
                <span className="flex items-center gap-1.5">
                  <GraduationCap size={15} className="text-orange-500" />
                  Galeri Akademisi
                </span>
              </div>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium leading-relaxed">
                Pazarlık tekniklerini, ekspertiz okumayı ve galeri yönetimini yeniden deneyin.
              </p>
              <button
                onClick={() => setShowTutorial(true)}
                className="w-full py-2 bg-orange-500/10 hover:bg-orange-500/20 text-orange-600 dark:text-orange-400 font-black text-xs rounded-xl border border-orange-500/30 transition-all flex items-center justify-center gap-1.5 active:scale-95"
              >
                🎓 Öğreticiyi Başlat
              </button>
            </div>
          </div>
        </aside>

        {/* Tab Content */}
        <div className="flex-grow min-w-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18 }}
            >
              {activeTab === 'market' && <Market />}
              {activeTab === 'garage' && (
                <Garage 
                  onNavigateToOffers={() => setActiveTab('offers')} 
                  onNavigateToCollection={() => setActiveTab('collection')}
                  onNavigateToShop={() => setActiveTab('shop')}
                />
              )}
              {activeTab === 'offers' && <OffersView />}
              {activeTab === 'collection' && <CollectionView />}
              {activeTab === 'shop' && <Shop />}
              {activeTab === 'achievements' && <AchievementsView />}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* 📱 Native Mobile Bottom Navigation Bar */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-lg border-t border-zinc-200 dark:border-zinc-800 px-1 py-1.5 flex items-center justify-around shadow-2xl safe-area-bottom">
        <button
          onClick={() => setActiveTab('market')}
          className={`flex flex-col items-center justify-center flex-1 py-1 rounded-xl transition-all relative ${
            activeTab === 'market'
              ? 'text-orange-600 dark:text-orange-400 font-black'
              : 'text-zinc-500 dark:text-zinc-400 font-medium'
          }`}
        >
          <ShoppingCart size={17} className={activeTab === 'market' ? 'stroke-[2.5]' : ''} />
          <span className="text-[9px] mt-0.5">Pazar</span>
          {activeTab === 'market' && (
            <motion.div layoutId="mobileTabDot" className="w-1.5 h-1.5 rounded-full bg-orange-500 mt-0.5" />
          )}
        </button>

        <button
          onClick={() => {
            setActiveTab('garage');
            if (state.tutorialStep === 'go_garage') {
              dispatch({ type: 'SET_TUTORIAL_STEP', payload: 'repair_egea' });
            }
          }}
          className={`flex flex-col items-center justify-center flex-1 py-1 rounded-xl transition-all relative ${
            activeTab === 'garage'
              ? 'text-orange-600 dark:text-orange-400 font-black'
              : state.tutorialStep === 'go_garage'
                ? 'text-orange-500 font-black animate-pulse'
                : 'text-zinc-500 dark:text-zinc-400 font-medium'
          }`}
        >
          <div className="relative">
            <Store size={17} className={activeTab === 'garage' || state.tutorialStep === 'go_garage' ? 'stroke-[2.5]' : ''} />
            {state.tutorialStep === 'go_garage' ? (
              <span className="absolute -top-1.5 -right-2 bg-orange-500 text-white text-[7px] font-black px-1 rounded-full animate-bounce shadow">
                👉
              </span>
            ) : state.garage.length > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-orange-500 text-white text-[8px] font-black px-1 rounded-full min-w-[14px] text-center shadow">
                {state.garage.length}
              </span>
            )}
          </div>
          <span className="text-[9px] mt-0.5">Galerim</span>
          {activeTab === 'garage' && (
            <motion.div layoutId="mobileTabDot" className="w-1.5 h-1.5 rounded-full bg-orange-500 mt-0.5" />
          )}
        </button>

        <button
          onClick={() => {
            setActiveTab('offers');
            if (state.tutorialStep === 'go_offers') {
              dispatch({ type: 'SET_TUTORIAL_STEP', payload: 'bargain_egea' });
            }
          }}
          className={`flex flex-col items-center justify-center flex-1 py-1 rounded-xl transition-all relative ${
            activeTab === 'offers'
              ? 'text-orange-600 dark:text-orange-400 font-black'
              : state.tutorialStep === 'go_offers'
                ? 'text-orange-500 font-black animate-pulse'
                : 'text-zinc-500 dark:text-zinc-400 font-medium'
          }`}
        >
          <div className="relative">
            <Flame size={17} className={activeTab === 'offers' ? 'stroke-[2.5] text-orange-500 fill-orange-500' : (state.offers.length > 0 || state.tutorialStep === 'go_offers' ? 'text-orange-500 fill-orange-400' : '')} />
            {state.tutorialStep === 'go_offers' ? (
              <span className="absolute -top-1.5 -right-2 bg-orange-500 text-white text-[7px] font-black px-1 rounded-full animate-bounce shadow">
                👉
              </span>
            ) : state.offers.length > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-red-500 text-white text-[8px] font-black px-1 rounded-full min-w-[14px] text-center shadow animate-bounce">
                {state.offers.length}
              </span>
            )}
          </div>
          <span className="text-[9px] mt-0.5">Teklifler</span>
          {activeTab === 'offers' && (
            <motion.div layoutId="mobileTabDot" className="w-1.5 h-1.5 rounded-full bg-orange-500 mt-0.5" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('shop')}
          className={`flex flex-col items-center justify-center flex-1 py-1 rounded-xl transition-all relative ${
            activeTab === 'shop'
              ? 'text-blue-600 dark:text-blue-400 font-black'
              : 'text-zinc-500 dark:text-zinc-400 font-medium'
          }`}
        >
          <Warehouse size={17} className={activeTab === 'shop' ? 'stroke-[2.5]' : ''} />
          <span className="text-[9px] mt-0.5">Dükkan</span>
          {activeTab === 'shop' && (
            <motion.div layoutId="mobileTabDot" className="w-1.5 h-1.5 rounded-full bg-blue-600 mt-0.5" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('achievements')}
          className={`flex flex-col items-center justify-center flex-1 py-1 rounded-xl transition-all relative ${
            activeTab === 'achievements'
              ? 'text-amber-500 font-black'
              : 'text-zinc-500 dark:text-zinc-400 font-medium'
          }`}
        >
          <div className="relative">
            <Trophy size={17} className={activeTab === 'achievements' ? 'stroke-[2.5] text-amber-500 fill-amber-400' : ''} />
            {readyAchievementsCount > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-emerald-500 text-white text-[8px] font-black px-1 rounded-full min-w-[14px] text-center shadow animate-bounce">
                +{readyAchievementsCount}
              </span>
            )}
          </div>
          <span className="text-[9px] mt-0.5">Başarımlar</span>
          {activeTab === 'achievements' && (
            <motion.div layoutId="mobileTabDot" className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-0.5" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('collection')}
          className={`flex flex-col items-center justify-center flex-1 py-1 rounded-xl transition-all relative ${
            activeTab === 'collection'
              ? 'text-amber-500 font-black'
              : 'text-zinc-500 dark:text-zinc-400 font-medium'
          }`}
        >
          <div className="relative">
            <Sparkles size={17} className={activeTab === 'collection' ? 'stroke-[2.5] text-amber-500' : ''} />
            {collectedStampsCount > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-amber-500 text-white text-[8px] font-black px-1 rounded-full min-w-[14px] text-center shadow">
                {collectedStampsCount}
              </span>
            )}
          </div>
          <span className="text-[9px] mt-0.5">Pul</span>
          {activeTab === 'collection' && (
            <motion.div layoutId="mobileTabDot" className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-0.5" />
          )}
        </button>
      </nav>

      {/* Floating Notification Toasts */}
      <div className="fixed bottom-20 md:bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none px-3 sm:px-0">
        <AnimatePresence>
          {state.notifications.slice(0, 3).map((notif, idx) => (
            <motion.div
              key={notif.id || `notif_${idx}_${notif.timestamp}`}
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, x: 20, scale: 0.9 }}
              className="pointer-events-auto bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-3.5 sm:p-4 shadow-xl flex items-start justify-between gap-3 text-xs"
            >
              <div className="flex items-start gap-2.5">
                <div className={`p-1.5 rounded-lg mt-0.5 ${
                  notif.type === 'offer' ? 'bg-orange-100 text-orange-600 dark:bg-orange-950 dark:text-orange-300' :
                  notif.type === 'sale' ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-300' :
                  notif.type === 'repair' ? 'bg-blue-100 text-blue-600 dark:bg-blue-950 dark:text-blue-300' :
                  'bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300'
                }`}>
                  {notif.type === 'offer' ? <Flame size={15} /> :
                   notif.type === 'sale' ? <TrendingUp size={15} /> :
                   notif.type === 'repair' ? <CheckCircle size={15} /> :
                   <Bell size={15} />}
                </div>
                <div>
                  <h5 className="font-bold text-zinc-900 dark:text-white">{notif.title}</h5>
                  <p className="text-zinc-500 dark:text-zinc-400 mt-0.5 leading-relaxed font-medium">
                    {notif.message}
                  </p>
                </div>
              </div>

              <button
                onClick={() => dispatch({ type: 'DISMISS_NOTIFICATION', payload: { id: notif.id } })}
                className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 p-1"
              >
                <X size={14} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <GameProvider>
      <MainLayout />
    </GameProvider>
  );
}
