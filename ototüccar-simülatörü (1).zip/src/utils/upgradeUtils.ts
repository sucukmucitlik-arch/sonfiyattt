import { SHOP_UPGRADES, UpgradeCategory, UpgradeTier } from '../data/upgrades';
import { GameUpgrades } from '../types';

export const getUpgradeCategory = (id: keyof GameUpgrades): UpgradeCategory => {
  const category = SHOP_UPGRADES.find(u => u.id === id);
  if (!category) {
    throw new Error(`Upgrade category not found for id: ${id}`);
  }
  return category;
};

export const getCurrentTier = (id: keyof GameUpgrades, level: number): UpgradeTier => {
  const category = getUpgradeCategory(id);
  const tier = category.tiers.find(t => t.level === level);
  return tier || category.tiers[0];
};

export const getNextTier = (id: keyof GameUpgrades, currentLevel: number): UpgradeTier | null => {
  const category = getUpgradeCategory(id);
  const nextTier = category.tiers.find(t => t.level === currentLevel + 1);
  return nextTier || null;
};

export const getMaxGarageCapacity = (parkingLevel: number = 1): number => {
  const tier = getCurrentTier('parking', parkingLevel);
  return tier.value || 6;
};
