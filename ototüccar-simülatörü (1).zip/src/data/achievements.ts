import { GameState } from '../types';

export type AchievementCategory = 'trade' | 'profit' | 'workshop' | 'collection' | 'empire';

export type AchievementRarity = 'bronze' | 'silver' | 'gold' | 'diamond' | 'legendary';

export interface AchievementReward {
  money?: number;
  reputation?: number;
  badgeTitle?: string;
}

export interface Achievement {
  id: string;
  category: AchievementCategory;
  title: string;
  description: string;
  icon: string; // Lucide icon name
  rarity: AchievementRarity;
  reward: AchievementReward;
  targetValue: number;
  unit?: string;
  // Progress calculator
  getProgress: (state: GameState, totalCatalogModels: number) => {
    current: number;
    max: number;
    isCompleted: boolean;
    progressPercent: number;
  };
}

export const ACHIEVEMENTS_DATA: Achievement[] = [
  // --- TİCARET & SATIŞ ---
  {
    id: 'first_car_bought',
    category: 'trade',
    title: 'İlk Araba Alımı',
    description: 'Pazardan galerin için ilk otomobilini satın al ve ticarete başla.',
    icon: 'ShoppingCart',
    rarity: 'bronze',
    reward: { money: 30000, reputation: 5, badgeTitle: 'Girişimci Esnaf' },
    targetValue: 1,
    unit: 'Araç',
    getProgress: (state) => {
      const current = (state.carsBought || 0) + (state.garage.length > 0 || state.carsSold > 0 ? 1 : 0);
      const max = 1;
      const completed = current >= max;
      return { current: Math.min(max, current), max, isCompleted: completed, progressPercent: completed ? 100 : (current / max) * 100 };
    },
  },
  {
    id: 'first_sale',
    category: 'trade',
    title: 'İlk Satış & El Sıkışması',
    description: 'Galerindeki ilk arabayı müşteriye satarak kâr elde et.',
    icon: 'Handshake',
    rarity: 'bronze',
    reward: { money: 50000, reputation: 5, badgeTitle: 'İlk El Sıkışma' },
    targetValue: 1,
    unit: 'Satış',
    getProgress: (state) => {
      const current = state.carsSold || 0;
      const max = 1;
      const completed = current >= max;
      return { current: Math.min(max, current), max, isCompleted: completed, progressPercent: completed ? 100 : (current / max) * 100 };
    },
  },
  {
    id: 'cars_sold_5',
    category: 'trade',
    title: 'Hızlı Galeri Esnafı',
    description: 'Galerinde toplam 5 adet araç satışı gerçekleştir.',
    icon: 'Car',
    rarity: 'silver',
    reward: { money: 120000, reputation: 8, badgeTitle: 'Piyasa Kurdu' },
    targetValue: 5,
    unit: 'Satış',
    getProgress: (state) => {
      const current = state.carsSold || 0;
      const max = 5;
      const completed = current >= max;
      return { current: Math.min(max, current), max, isCompleted: completed, progressPercent: Math.min(100, Math.round((current / max) * 100)) };
    },
  },
  {
    id: 'cars_sold_15',
    category: 'trade',
    title: 'Oto Galeri Şampiyonu',
    description: 'Toplam 15 araç satışı yaparak sektörün bilinen yüzü ol.',
    icon: 'Trophy',
    rarity: 'gold',
    reward: { money: 350000, reputation: 15, badgeTitle: 'Satış Rekortmeni' },
    targetValue: 15,
    unit: 'Satış',
    getProgress: (state) => {
      const current = state.carsSold || 0;
      const max = 15;
      const completed = current >= max;
      return { current: Math.min(max, current), max, isCompleted: completed, progressPercent: Math.min(100, Math.round((current / max) * 100)) };
    },
  },

  // --- KÂR & SERMAYE ---
  {
    id: 'profit_250k',
    category: 'profit',
    title: 'İlk Büyük Kazanç',
    description: 'Araç satışlarından toplam 250.000 ₺ net kâr elde et.',
    icon: 'Coins',
    rarity: 'bronze',
    reward: { money: 50000, reputation: 5, badgeTitle: 'Karlı Tüccar' },
    targetValue: 250000,
    unit: '₺',
    getProgress: (state) => {
      const current = Math.max(0, state.totalProfit || 0);
      const max = 250000;
      const completed = current >= max;
      return { current: Math.min(max, current), max, isCompleted: completed, progressPercent: Math.min(100, Math.round((current / max) * 100)) };
    },
  },
  {
    id: 'profit_1m',
    category: 'profit',
    title: '1 Milyon TL Kazanç',
    description: 'Toplam satış kârını 1.000.000 ₺ barajına ulaştır.',
    icon: 'TrendingUp',
    rarity: 'gold',
    reward: { money: 250000, reputation: 12, badgeTitle: 'Milyoner Galeri' },
    targetValue: 1000000,
    unit: '₺',
    getProgress: (state) => {
      const current = Math.max(0, state.totalProfit || 0);
      const max = 1000000;
      const completed = current >= max;
      return { current: Math.min(max, current), max, isCompleted: completed, progressPercent: Math.min(100, Math.round((current / max) * 100)) };
    },
  },
  {
    id: 'money_5m',
    category: 'profit',
    title: '5 Milyon TL Nakit Devi',
    description: 'Kasadaki toplam nakit sermayeni 5.000.000 ₺ seviyesine çıkar.',
    icon: 'Banknote',
    rarity: 'diamond',
    reward: { money: 500000, reputation: 20, badgeTitle: 'Sermaye Babası' },
    targetValue: 5000000,
    unit: '₺',
    getProgress: (state) => {
      const current = Math.max(0, state.money || 0);
      const max = 5000000;
      const completed = current >= max;
      return { current: Math.min(max, current), max, isCompleted: completed, progressPercent: Math.min(100, Math.round((current / max) * 100)) };
    },
  },

  // --- USTA & TAMİRHANE ---
  {
    id: 'first_repair',
    category: 'workshop',
    title: 'Sanayi Çıraklığı',
    description: 'Hasarlı veya değişenli ilk aracı serviste onarıma verip başarıyla tamamla.',
    icon: 'Wrench',
    rarity: 'bronze',
    reward: { money: 35000, reputation: 5, badgeTitle: 'Usta Çırağı' },
    targetValue: 1,
    unit: 'Tamir',
    getProgress: (state) => {
      const current = state.repairsCompleted || 0;
      const max = 1;
      const completed = current >= max;
      return { current: Math.min(max, current), max, isCompleted: completed, progressPercent: completed ? 100 : 0 };
    },
  },
  {
    id: 'repairs_5',
    category: 'workshop',
    title: 'Usta Kaporta & Boyacı',
    description: 'Toplam 5 aracın servis ve kaporta bakımını başarıyla tamamla.',
    icon: 'Paintbrush',
    rarity: 'silver',
    reward: { money: 140000, reputation: 10, badgeTitle: 'Sanayi Duayeni' },
    targetValue: 5,
    unit: 'Tamir',
    getProgress: (state) => {
      const current = state.repairsCompleted || 0;
      const max = 5;
      const completed = current >= max;
      return { current: Math.min(max, current), max, isCompleted: completed, progressPercent: Math.min(100, Math.round((current / max) * 100)) };
    },
  },

  // --- KOLEKSİYON & PULLAR ---
  {
    id: 'collection_3',
    category: 'collection',
    title: 'Koleksiyon Meraklısı',
    description: 'Farklı 3 marka veya model için koleksiyon pulu topla.',
    icon: 'Sparkles',
    rarity: 'bronze',
    reward: { money: 45000, reputation: 5, badgeTitle: 'Pul Koleksiyoneri' },
    targetValue: 3,
    unit: 'Pul',
    getProgress: (state) => {
      const current = state.collectedModelKeys?.length || 0;
      const max = 3;
      const completed = current >= max;
      return { current: Math.min(max, current), max, isCompleted: completed, progressPercent: Math.min(100, Math.round((current / max) * 100)) };
    },
  },
  {
    id: 'collection_8',
    category: 'collection',
    title: 'Otomobil Gurmesi',
    description: '8 farklı modelin pulunu albümüne ekle.',
    icon: 'Layers',
    rarity: 'gold',
    reward: { money: 200000, reputation: 15, badgeTitle: 'Oto Gurmesi' },
    targetValue: 8,
    unit: 'Pul',
    getProgress: (state) => {
      const current = state.collectedModelKeys?.length || 0;
      const max = 8;
      const completed = current >= max;
      return { current: Math.min(max, current), max, isCompleted: completed, progressPercent: Math.min(100, Math.round((current / max) * 100)) };
    },
  },
  {
    id: 'collection_all',
    category: 'collection',
    title: 'Tüm Koleksiyonu Tamamla',
    description: 'Katalogdaki tüm araçların koleksiyon pulunu eksiksiz topla (%100 Başarı).',
    icon: 'Crown',
    rarity: 'legendary',
    reward: { money: 2500000, reputation: 50, badgeTitle: 'Koleksiyon Efsanesi' },
    targetValue: 100,
    unit: '%',
    getProgress: (state, totalCatalogModels) => {
      const currentCount = state.collectedModelKeys?.length || 0;
      const max = totalCatalogModels || 10;
      const completed = currentCount >= max;
      const percent = Math.min(100, Math.round((currentCount / max) * 100));
      return { current: percent, max: 100, isCompleted: completed, progressPercent: percent };
    },
  },

  // --- DÜKKAN & İMPARATORLUK ---
  {
    id: 'upgrade_parking_2',
    category: 'empire',
    title: 'Geniş Otopark',
    description: 'Dükkandan Galeri & Otopark Kapasitesini 2. seviyeye yükselt.',
    icon: 'Building2',
    rarity: 'bronze',
    reward: { money: 60000, reputation: 5, badgeTitle: 'Büyüyen Galeri' },
    targetValue: 2,
    unit: 'Seviye',
    getProgress: (state) => {
      const current = state.upgrades?.parking || 1;
      const max = 2;
      const completed = current >= max;
      return { current: Math.min(max, current), max, isCompleted: completed, progressPercent: completed ? 100 : (current / max) * 100 };
    },
  },
  {
    id: 'upgrade_any_max',
    category: 'empire',
    title: 'Maksimum Donanım',
    description: 'Dükkandaki herhangi bir istasyon veya hizmeti 4. (Son) Seviyeye ulaştır.',
    icon: 'Zap',
    rarity: 'silver',
    reward: { money: 250000, reputation: 12, badgeTitle: 'İleri Teknoloji' },
    targetValue: 4,
    unit: 'Seviye',
    getProgress: (state) => {
      const levels = Object.values(state.upgrades || {});
      const maxLevelReached = levels.length > 0 ? Math.max(...(levels as number[])) : 1;
      const max = 4;
      const completed = maxLevelReached >= max;
      return { current: maxLevelReached, max, isCompleted: completed, progressPercent: completed ? 100 : (maxLevelReached / max) * 100 };
    },
  },
  {
    id: 'upgrade_all_max',
    category: 'empire',
    title: 'Otomotiv İmparatorluğu',
    description: 'Dükkandaki tüm 5 yükseltmeyi de 4. (Maksimum) seviyeye çıkar.',
    icon: 'Award',
    rarity: 'legendary',
    reward: { money: 2000000, reputation: 40, badgeTitle: 'Otomotiv Holdingi' },
    targetValue: 5,
    unit: 'İstasyon',
    getProgress: (state) => {
      const upgrades = state.upgrades || { parking: 1, repair_speed: 1, paint_booth: 1, marketing: 1, mechanic_discount: 1 };
      const maxedCount = Object.values(upgrades).filter(lvl => Number(lvl) >= 4).length;
      const max = 5;
      const completed = maxedCount >= max;
      return { current: maxedCount, max, isCompleted: completed, progressPercent: Math.min(100, Math.round((maxedCount / max) * 100)) };
    },
  },

  // --- İTİBAR ---
  {
    id: 'reputation_85',
    category: 'empire',
    title: 'Güvenilir Esnaf',
    description: 'Müşteri memnuniyeti ve dürüst ticaretle itibarını en az 85 puana çıkar.',
    icon: 'ShieldCheck',
    rarity: 'gold',
    reward: { money: 200000, reputation: 10, badgeTitle: 'Yıldızlı Galeri' },
    targetValue: 85,
    unit: 'İtibar',
    getProgress: (state) => {
      const current = state.reputation || 50;
      const max = 85;
      const completed = current >= max;
      return { current: Math.min(max, current), max, isCompleted: completed, progressPercent: Math.min(100, Math.round((current / max) * 100)) };
    },
  },
];
