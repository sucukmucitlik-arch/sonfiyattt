export interface UpgradeTier {
  level: number;
  name: string;
  description: string;
  cost: number;
  benefitText: string;
  value: number; // effect value (e.g. max cars, speed multiplier, etc.)
}

export interface UpgradeCategory {
  id: 'parking' | 'repair_speed' | 'paint_booth' | 'marketing' | 'mechanic_discount';
  name: string;
  shortDesc: string;
  icon: string; // Lucide icon name
  badgeColor: string;
  tiers: UpgradeTier[];
}

export const SHOP_UPGRADES: UpgradeCategory[] = [
  {
    id: 'parking',
    name: 'Galeri & Otopark Kapasitesi',
    shortDesc: 'Galerinizde aynı anda sergileyebileceğiniz maksimum araç sayısını artırır.',
    icon: 'CarFront',
    badgeColor: 'blue',
    tiers: [
      {
        level: 1,
        name: 'Standart Köşe Galerisi',
        description: 'Başlangıç galerisi. 6 araca kadar vitrin alanı sağlar.',
        cost: 0,
        benefitText: 'Maksimum 6 Araç Vitrini',
        value: 6,
      },
      {
        level: 2,
        name: 'Genişletilmiş Açık Otopark',
        description: 'Yan arsayı kiralayıp asfalt dökerek daha fazla araba sergileyin.',
        cost: 150000,
        benefitText: 'Maksimum 12 Araç Vitrini (+6)',
        value: 12,
      },
      {
        level: 3,
        name: 'Kapalı Plazaya Geçiş',
        description: 'Işıklandırmalı cam vitrinli lüks showroom alanı.',
        cost: 450000,
        benefitText: 'Maksimum 20 Araç Vitrini (+8)',
        value: 20,
      },
      {
        level: 4,
        name: 'Mega Otomotiv Kompleksi',
        description: 'Çok katlı, 35 araçlık devasa otomotiv merkezi.',
        cost: 1200000,
        benefitText: 'Maksimum 35 Araç Vitrini (+15)',
        value: 35,
      },
    ],
  },
  {
    id: 'repair_speed',
    name: 'Hızlı Tamir & Mekanik Ekibi',
    shortDesc: 'Usta kadrosunu güçlendirerek araç onarım bekleme sürelerini önemli ölçüde kısaltır.',
    icon: 'Wrench',
    badgeColor: 'amber',
    tiers: [
      {
        level: 1,
        name: 'Sanayi Çırağı',
        description: 'Standart tamir süresi.',
        cost: 0,
        benefitText: 'Normal Onarım Hızı (1.0x)',
        value: 1.0,
      },
      {
        level: 2,
        name: 'Kıdemli Kaporta Ustası',
        description: 'Deneyimli ustalar işe alınarak tamir hızlandırılır.',
        cost: 120000,
        benefitText: '%35 Daha Hızlı Tamir (1.5x)',
        value: 1.5,
      },
      {
        level: 3,
        name: 'Özel Lift & Pnömatik Takım',
        description: 'Hidrolik liftler ve havalı aletlerle araçlar rekor sürede onarılır.',
        cost: 320000,
        benefitText: '%60 Daha Hızlı Tamir (2.5x)',
        value: 2.5,
      },
      {
        level: 4,
        name: 'F1 Pit-Stop Onarım Ekibi',
        description: 'Araçlar birkaç saniyede kusursuz şekilde onarılır.',
        cost: 850000,
        benefitText: '%80 Ultra Hızlı Tamir (5.0x)',
        value: 5.0,
      },
    ],
  },
  {
    id: 'paint_booth',
    name: 'Oto Boya & Detaylı Fırın İstasyonu',
    shortDesc: 'Boya kalitesini artırır, boyalı ve onarılmış araçlara gelen müşteri tekliflerini yükseltir.',
    icon: 'Paintbrush',
    badgeColor: 'purple',
    tiers: [
      {
        level: 1,
        name: 'Basit Boya Tabancası',
        description: 'Temel boya ve rötüş imkanı.',
        cost: 0,
        benefitText: 'Standart Boya Kalitesi',
        value: 0,
      },
      {
        level: 2,
        name: 'Tozsuz Boya Fırını & Pasta Cila',
        description: 'Fırınlı boya ve seramik kaplama ile araçlar pırıl pırıl parlar.',
        cost: 200000,
        benefitText: 'Müşteri Tekliflerine +%5 Bonus Değer',
        value: 0.05,
      },
      {
        level: 3,
        name: 'Robotik Kızılötesi Kurutma İstasyonu',
        description: 'Nano-teknoloji boya koruma ile araçlar vitrinde hemen dikkat çeker.',
        cost: 550000,
        benefitText: 'Müşteri Tekliflerine +%10 Bonus Değer',
        value: 0.10,
      },
      {
        level: 4,
        name: 'Showroom Seramik & PPF Kaplama Merkezi',
        description: 'Kusursuz kaplama sayesinde boyalı araçlar bile sıfır ayarında alıcı bulur.',
        cost: 1100000,
        benefitText: 'Müşteri Tekliflerine +%18 Bonus Değer',
        value: 0.18,
      },
    ],
  },
  {
    id: 'marketing',
    name: 'Reklam & Sosyal Medya Ajansı',
    shortDesc: 'Galerinize gelen müşteri sıklığını ve teklif sayısını artırır.',
    icon: 'Megaphone',
    badgeColor: 'rose',
    tiers: [
      {
        level: 1,
        name: 'Cama Yazı & Sahibinden İlanı',
        description: 'Standart vitrin ilanı.',
        cost: 0,
        benefitText: 'Standart Müşteri Akışı',
        value: 1.0,
      },
      {
        level: 2,
        name: 'Öne Çıkan İlan Dopingi',
        description: 'İlan sitelerinde en üst sıralarda yer alma ve sosyal medya sponsorluğu.',
        cost: 180000,
        benefitText: 'Müşteri Teklifi Gelme Hızı +%40',
        value: 1.4,
      },
      {
        level: 3,
        name: 'Otomobil Vlogger & Fenomen Ortaklığı',
        description: 'Ünlü otomobil incelemecileri araçlarınızı tanıtır.',
        cost: 480000,
        benefitText: 'Müşteri Teklifi Gelme Hızı +%90 & VIP Müşteriler',
        value: 1.9,
      },
      {
        level: 4,
        name: 'Ulusal TV & Dijital Sponsorluk',
        description: 'Türkiye genelinden binlerce alıcı galerinize akın eder.',
        cost: 1000000,
        benefitText: 'Müşteri Teklifi Gelme Hızı +%160',
        value: 2.6,
      },
    ],
  },
  {
    id: 'mechanic_discount',
    name: 'Toptan Yedek Parça Anlaşması',
    shortDesc: 'Tüm parça değişim ve tamir masraflarında indirim sağlar.',
    icon: 'BadgePercent',
    badgeColor: 'emerald',
    tiers: [
      {
        level: 1,
        name: 'Perakende Parça Alımı',
        description: 'Standart piyasa parça fiyatları.',
        cost: 0,
        benefitText: 'İndirim Yok (%0)',
        value: 0,
      },
      {
        level: 2,
        name: 'Sanayi Esnafı İndirimi',
        description: 'Yerel yedek parçacılardan toptan fiyat anlaşması.',
        cost: 140000,
        benefitText: 'Tamir Masraflarında %20 İndirim',
        value: 0.20,
      },
      {
        level: 3,
        name: 'Ana Dağıtıcı Doğrudan Bayilik',
        description: 'Yurt dışı ve ana ithalatçıdan doğrudan parça temini.',
        cost: 380000,
        benefitText: 'Tamir Masraflarında %40 İndirim',
        value: 0.40,
      },
      {
        level: 4,
        name: 'Kendi Yedek Parça Fabrikanız',
        description: 'Parçalar kendi atölyenizde sıfır maliyetine yakın üretilir.',
        cost: 900000,
        benefitText: 'Tamir Masraflarında %65 İndirim',
        value: 0.65,
      },
    ],
  },
];
