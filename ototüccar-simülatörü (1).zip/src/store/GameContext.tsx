import React, { createContext, useContext, useEffect, useReducer } from 'react';
import { GameState, GameAction, PlayerCar, CustomerOffer, MarketCar } from '../types';
import { 
  generateMarketCars, 
  generateFullMarketCatalog, 
  generateSingleMarketCar, 
  generateDailyOffers, 
  generateCustomerOffer, 
  calculateRepairCost,
  calculateRepairDuration,
  isCarRepairable,
  formatMoney, 
  ensureCar,
  generateUniqueId,
  calculateBuyTradeReport,
  calculateSaleTradeReport
} from '../utils';
import { SHOP_UPGRADES } from '../data/upgrades';
import { getMaxGarageCapacity, getNextTier } from '../utils/upgradeUtils';

const DEFAULT_UPGRADES = {
  parking: 1,
  repair_speed: 1,
  paint_booth: 1,
  marketing: 1,
  mechanic_discount: 1,
};

export const createTutorialEgea = (): MarketCar => ({
  marketId: 'tutorial_egea_01',
  adTitle: 'Öğretici Fırsatı: Fiat Egea 1.4 Fire Urban',
  brand: 'Fiat',
  model: 'Egea',
  series: '1.4 Fire Urban',
  year: 2023,
  basePrice: 620000,
  price: 620000,
  km: 42000,
  type: 'Sedan',
  image: 'https://i.hizliresim.com/xtff08hf.jpg',
  color: 'Kurşun Gri',
  condition: 'Boyalı',
  engine: {
    name: '1.4 Fire',
    fuelType: 'Benzin',
    transmission: 'Manuel',
    motorGucu: '95 hp',
    motorHacmi: '1368 cc',
    cekis: 'Önden Çekiş',
    hizlanma: '11.5 sn',
    azamiSurat: '182 km/saat',
    yakitTuketimi: '6.4 lt / 100km',
  },
  inspection: {
    kaput: 'original',
    tavan: 'original',
    bagaj: 'original',
    solOnCamurluk: 'painted',
    solOnKapi: 'original',
    solArkaKapi: 'original',
    solArkaCamurluk: 'original',
    sagOnCamurluk: 'painted',
    sagOnKapi: 'original',
    sagArkaKapi: 'original',
    sagArkaCamurluk: 'original',
    onTampon: 'painted',
    arkaTampon: 'original',
    agirHasarKayitli: false,
    tramerTutar: 12000,
  },
  originalAskingPrice: 620000,
  fairMarketValue: 685000,
  isOverpriced: false,
  overpricedPercentage: -9,
  sellerType: 'Acil İhtiyaçtan',
  sellerName: 'Ahmet Bey',
  sellerAvatar: '👨‍💼',
  sellerPatience: 4,
  sellerMinPrice: 580000,
  sellerQuote: 'Öğretici araçtır, esnafa hayırlı olsun!',
  description: '🎓 Galeri Akademisi Başlangıç Aracı! Temiz, ufak boyalı 2023 Egea. Bakım yapıp karla satmaya çok uygun.',
});

const INITIAL_STATE: GameState = {
  galleryName: 'Son Fiyat Motors',
  tutorialCompleted: false,
  tutorialStep: 'idle',
  money: 1000000, // 1M TRY starting money
  day: 1,
  reputation: 50,
  garage: [],
  market: generateFullMarketCatalog(),
  offers: [],
  notifications: [
    {
      id: 'init_notif',
      title: 'Galeri Açıldı!',
      message: 'Oto galeriniz hizmete girdi. Yüzlerce araçlık piyasadan dilediğinizi alın, vitrininize koyun ve müşterilere satın.',
      type: 'info',
      timestamp: Date.now(),
    }
  ],
  totalProfit: 0,
  carsSold: 0,
  carsBought: 0,
  repairsCompleted: 0,
  collectedModelKeys: [],
  activeRepairs: [],
  upgrades: DEFAULT_UPGRADES,
  claimedAchievementIds: [],
  activeTradeReport: null,
};

const gameReducer = (state: GameState, action: GameAction): GameState => {
  switch (action.type) {
    case 'START_INTERACTIVE_TUTORIAL': {
      const egea = createTutorialEgea();
      const existingMarket = state.market.filter(c => c.marketId !== egea.marketId);
      return {
        ...state,
        tutorialCompleted: false,
        tutorialStep: 'buy_egea',
        market: [egea, ...existingMarket],
        notifications: [
          {
            id: generateUniqueId('notif_tut_start'),
            title: '🎓 İnteraktif Galeri Öğreticisi Başladı!',
            message: '1. Adım: Piyasadan parlayan Fiat Egea aracını satın alın.',
            type: 'info',
            timestamp: Date.now(),
          },
          ...state.notifications.slice(0, 15),
        ],
      };
    }

    case 'SET_TUTORIAL_STEP': {
      return {
        ...state,
        tutorialStep: action.payload,
      };
    }

    case 'SKIP_TUTORIAL': {
      return {
        ...state,
        tutorialStep: 'idle',
        tutorialCompleted: true,
      };
    }

    case 'SET_GALLERY_NAME': {
      const cleanName = action.payload.trim() || 'Son Fiyat Motors';
      return {
        ...state,
        galleryName: cleanName,
        notifications: [
          {
            id: generateUniqueId('notif_gallery_name'),
            title: 'Galeri İsmi Güncellendi 🏢',
            message: `Galerinizin tabelası artık "${cleanName}" olarak değişti!`,
            type: 'info' as const,
            timestamp: Date.now(),
          },
          ...state.notifications.slice(0, 15),
        ]
      };
    }

    case 'COMPLETE_TUTORIAL': {
      return {
        ...state,
        tutorialCompleted: true,
        tutorialStep: 'idle',
      };
    }

    case 'ADD_MONEY': {
      return {
        ...state,
        money: state.money + action.payload,
        notifications: [
          {
            id: generateUniqueId('notif_bonus'),
            title: 'Kuruluş Teşvik Bonusu 💰',
            message: `Galerinize +${formatMoney(action.payload)} başlangıç hibe desteği tanımlandı!`,
            type: 'info' as const,
            timestamp: Date.now(),
          },
          ...state.notifications.slice(0, 15),
        ]
      };
    }
    case 'BUY_CAR': {
      const payload = action.payload;
      const car = 'marketId' in payload ? payload : payload.car;
      const effectivePrice = 'marketId' in payload 
        ? payload.price 
        : (typeof payload.customPrice === 'number' ? payload.customPrice : payload.car.price);
      
      const discountAmount = 'discountAmount' in payload && typeof payload.discountAmount === 'number'
        ? payload.discountAmount
        : Math.max(0, (car.originalAskingPrice || car.price) - effectivePrice);

      if (state.money < effectivePrice) return state;

      const maxSlots = getMaxGarageCapacity(state.upgrades?.parking || 1);
      if (state.garage.length >= maxSlots) {
        return {
          ...state,
          notifications: [
            {
              id: generateUniqueId('notif_full'),
              title: 'Galeri Otoparkı Dolu! ⚠️',
              message: `Galerinizde yer kalmadı (${state.garage.length}/${maxSlots}). 'Dükkan' sekmesinden otopark kapasitesini yükseltin veya araç satın.`,
              type: 'info' as const,
              timestamp: Date.now(),
            },
            ...state.notifications.slice(0, 15),
          ],
        };
      }
      
      const buyTradeReport = calculateBuyTradeReport(car, effectivePrice, discountAmount);

      const newPlayerCar: PlayerCar = {
        ...car,
        purchasePrice: effectivePrice,
        totalInvestedCost: effectivePrice,
        isUnrepairable: car.isUnrepairable || car.inspection?.isUnrepairable || false,
        unrepairableReason: car.unrepairableReason || car.inspection?.unrepairableReason,
        boughtAtDay: state.day,
        originalConditionWhenBought: car.condition,
        buyDealGrade: buyTradeReport.grade,
        buyDiffPercentage: buyTradeReport.diffPercentage,
      };

      const newNotification = {
        id: generateUniqueId('notif_buy'),
        title: discountAmount > 0 ? `Pazarlıkla Araç Alındı! 🤝 (Not: ${buyTradeReport.grade})` : `Araç Satın Alındı 🔑 (Not: ${buyTradeReport.grade})`,
        message: discountAmount > 0 
          ? `${car.brand} ${car.model} pazarlık sonucu ${formatMoney(effectivePrice)}'ye (${formatMoney(discountAmount)} indirimle, Not: ${buyTradeReport.grade}) satın alındı!`
          : `${car.brand} ${car.model} (${buyTradeReport.badgeLabel}) galerine eklendi. Koleksiyon pulu kazanıldı!`,
        type: 'info' as const,
        timestamp: Date.now(),
      };

      // Add car model to collection stamps if not already present
      const stampKey = `${car.brand.trim().toLowerCase()}_${car.model.trim().toLowerCase()}`;
      const updatedStamps = state.collectedModelKeys.includes(stampKey)
        ? state.collectedModelKeys
        : [...state.collectedModelKeys, stampKey];

      // Remove purchased car and immediately generate a fresh new listing so the market stays packed
      const updatedMarket = state.market.filter(c => c.marketId !== car.marketId);
      const replacementCar = generateSingleMarketCar(undefined, Date.now());

      const isTutorialBuy = state.tutorialStep === 'buy_egea';

      return {
        ...state,
        money: state.money - effectivePrice,
        garage: [...state.garage, newPlayerCar],
        market: [...updatedMarket, replacementCar],
        collectedModelKeys: updatedStamps,
        carsBought: (state.carsBought || 0) + 1,
        activeTradeReport: buyTradeReport,
        tutorialStep: isTutorialBuy ? 'go_garage' : state.tutorialStep,
        notifications: [
          newNotification,
          ...(isTutorialBuy ? [{
            id: generateUniqueId('notif_tut_garage'),
            title: '🚗 2. Adım: Garajına Git!',
            message: 'Fiat Egea satın alındı! Şimdi üst menüden "Garaj" sekmesine tıkla.',
            type: 'info' as const,
            timestamp: Date.now(),
          }] : []),
          ...state.notifications.slice(0, 15)
        ],
      };
    }
    
    case 'ACCEPT_OFFER': {
      const { offerId } = action.payload;
      const offer = state.offers.find(o => o.id === offerId);
      if (!offer) return state;

      const carIndex = state.garage.findIndex(c => c.marketId === offer.carMarketId);
      if (carIndex === -1) return state;

      const car = state.garage[carIndex];
      const costBasis = car.totalInvestedCost || car.purchasePrice;
      const profit = offer.offeredPrice - costBasis;
      const isLoss = profit < 0;
      const newGarage = [...state.garage];
      newGarage.splice(carIndex, 1);

      // Calculate sale trade report
      const sellTradeReport = calculateSaleTradeReport(car, offer);

      // Remove all offers for this sold car
      const remainingOffers = state.offers.filter(o => o.carMarketId !== offer.carMarketId);

      const saleNotification = {
        id: generateUniqueId('notif_sale'),
        title: isLoss ? `Zararına Satış Gerçekleşti 📉 (Not: ${sellTradeReport.grade})` : `Araç Satıldı! 🎉 (Not: ${sellTradeReport.grade})`,
        message: isLoss 
          ? `${offer.buyerName}, ${offer.carName} aracını ${formatMoney(offer.offeredPrice)} karşılığında satın aldı (${formatMoney(Math.abs(profit))} ZARAR EDİLDİ, Not: ${sellTradeReport.grade}).`
          : `${offer.buyerName}, ${offer.carName} aracını ${formatMoney(offer.offeredPrice)} karşılığında satın aldı (+${formatMoney(profit)} kâr, Not: ${sellTradeReport.grade}).`,
        type: 'sale' as const,
        timestamp: Date.now(),
      };

      const isTutorialBargain = state.tutorialStep === 'bargain_egea';

      return {
        ...state,
        money: state.money + offer.offeredPrice,
        garage: newGarage,
        offers: remainingOffers,
        activeTradeReport: sellTradeReport,
        reputation: Math.max(10, Math.min(100, state.reputation + (isLoss ? -2 : 2))),
        totalProfit: state.totalProfit + profit,
        carsSold: state.carsSold + 1,
        tutorialStep: isTutorialBargain ? 'completed' : state.tutorialStep,
        notifications: [saleNotification, ...state.notifications.slice(0, 15)],
      };
    }

    case 'REJECT_OFFER': {
      const { offerId } = action.payload;
      return {
        ...state,
        offers: state.offers.filter(o => o.id !== offerId),
      };
    }

    case 'COUNTER_OFFER_RESULT': {
      const { offerId, newPrice, success, buyerResponse } = action.payload;
      
      if (!success && !newPrice) {
        // Buyer walked away
        return {
          ...state,
          offers: state.offers.filter(o => o.id !== offerId),
          notifications: [
            {
              id: generateUniqueId('notif_counter'),
              title: 'Pazarlık Bozuldu 🙅‍♂️',
              message: `Müşteri teklifi geri çekip masadan kalktı: "${buyerResponse}"`,
              type: 'info',
              timestamp: Date.now(),
            },
            ...state.notifications.slice(0, 15),
          ],
        };
      }

      return {
        ...state,
        offers: state.offers.map(o => {
          if (o.id === offerId) {
            return {
              ...o,
              offeredPrice: newPrice || o.offeredPrice,
              message: buyerResponse,
              negotiated: true,
            };
          }
          return o;
        }),
      };
    }

    case 'START_REPAIR': {
      const { carMarketId, cost, durationSeconds } = action.payload;
      if (state.money < cost) return state;

      const car = state.garage.find(c => c.marketId === carMarketId);
      if (!car) return state;

      const repairCheck = isCarRepairable(car);
      if (!repairCheck.repairable) {
        return {
          ...state,
          notifications: [
            {
              id: generateUniqueId('notif_rep_blocked'),
              title: 'Onarım Yapılamaz! 🚫',
              message: repairCheck.reason || 'Bu araç ağır pert kayıtlı veya kusursuz olduğundan serviste onarılamaz.',
              type: 'info' as const,
              timestamp: Date.now(),
            },
            ...state.notifications.slice(0, 15),
          ],
        };
      }

      // Realistic condition transitions:
      // - Ağır Hasarlı -> Değişen
      // - Değişen -> Boyalı
      // - Boyalı -> Boyalı (detaylı pasta-cila / boya koruma / ekspertiz iyileştirme)
      let targetCond = car.condition;
      if (car.condition === 'Ağır Hasarlı') targetCond = 'Değişen';
      else if (car.condition === 'Değişen') targetCond = 'Boyalı';
      else targetCond = 'Boyalı';

      const isTutorialRepair = state.tutorialStep === 'repair_egea';
      // In tutorial, make repair fast (2 seconds)
      const duration = (isTutorialRepair ? 2 : (durationSeconds || 10)) * 1000;
      const finishTimestamp = Date.now() + duration;

      const activeRepair = {
        carMarketId,
        finishTimestamp,
        totalDurationMs: duration,
        cost,
        targetCondition: targetCond,
      };

      const startNotif = {
        id: generateUniqueId('notif_rep_start'),
        title: 'Tamir / Bakım Başladı 🔧',
        message: `${car.brand} ${car.model} serviste işleme alındı (${Math.round(duration / 1000)} sn sürecek).`,
        type: 'repair' as const,
        timestamp: Date.now(),
      };

      let newOffers = state.offers;
      if (isTutorialRepair) {
        const tutOffer: CustomerOffer = {
          id: 'tut_offer_ahmet_egea',
          carMarketId: carMarketId,
          carName: `${car.brand} ${car.model}`,
          carImage: car.image || 'https://i.hizliresim.com/xtff08hf.jpg',
          buyerName: 'Ahmet Bey (Müteahhit)',
          buyerAvatar: '👨‍💼',
          buyerType: 'Galeri Esnafı',
          offeredPrice: 710000,
          originalPrice: 710000,
          dayReceived: state.day,
          expiresDay: state.day + 3,
          message: 'Hayırlı işler ustam! Fiat Egea ilanı için nakit hazır, hemen notere geçelim mi? Son fiyatın nedir?',
          negotiated: false,
        };
        newOffers = [tutOffer, ...state.offers.filter(o => o.id !== 'tut_offer_ahmet_egea')];
      }

      return {
        ...state,
        money: state.money - cost,
        garage: state.garage.map(c => {
          if (c.marketId === carMarketId) {
            return {
              ...c,
              repairingUntil: finishTimestamp,
              purchasePrice: c.purchasePrice + cost,
              totalInvestedCost: (c.totalInvestedCost || c.purchasePrice) + cost,
            };
          }
          return c;
        }),
        offers: newOffers,
        tutorialStep: isTutorialRepair ? 'go_offers' : state.tutorialStep,
        activeRepairs: [...state.activeRepairs.filter(r => r.carMarketId !== carMarketId), activeRepair],
        notifications: [
          startNotif,
          ...(isTutorialRepair ? [{
            id: generateUniqueId('notif_tut_offers'),
            title: '🔔 4. Adım: Müşteri Geldi!',
            message: 'Ahmet Bey Fiat Egea için 710.000 ₺ teklif etti. Üst menüden "Teklifler" sekmesine tıkla.',
            type: 'offer' as const,
            timestamp: Date.now(),
          }] : []),
          ...state.notifications.slice(0, 15)
        ],
      };
    }

    case 'COMPLETE_REPAIR': {
      const { carMarketId } = action.payload;
      const car = state.garage.find(c => c.marketId === carMarketId);
      const repairInfo = state.activeRepairs.find(r => r.carMarketId === carMarketId);
      if (!car) return state;

      const newCondition = repairInfo ? repairInfo.targetCondition : (car.condition === 'Ağır Hasarlı' ? 'Değişen' : 'Boyalı');

      // Update inspection details realistically
      const updatedInspection = { ...car.inspection };
      if (car.condition === 'Ağır Hasarlı') {
        updatedInspection.agirHasarKayitli = false; // Ağır hasar şasi onarımı tamamlandı
        updatedInspection.tramerTutar = Math.floor(updatedInspection.tramerTutar * 0.5);
      } else if (car.condition === 'Değişen') {
        // Değişen parçalar sıfırlanmaz ama boyalıya dönüştürülüp uyumlanır
        (Object.keys(updatedInspection) as (keyof typeof updatedInspection)[]).forEach(k => {
          if (updatedInspection[k] === 'replaced') {
            (updatedInspection as any)[k] = 'painted';
          }
        });
      }

      const completeNotif = {
        id: generateUniqueId('notif_rep_done'),
        title: 'Tamir Tamamlandı! ✨',
        message: `${car.brand} ${car.model} ustalarca başarıyla onarıldı. Yeni Durum: '${newCondition}'. Müşteri ilgisi arttı!`,
        type: 'repair' as const,
        timestamp: Date.now(),
      };

      return {
        ...state,
        garage: state.garage.map(c => {
          if (c.marketId === carMarketId) {
            return {
              ...c,
              condition: newCondition,
              inspection: updatedInspection,
              repairingUntil: undefined,
            };
          }
          return c;
        }),
        repairsCompleted: (state.repairsCompleted || 0) + 1,
        activeRepairs: state.activeRepairs.filter(r => r.carMarketId !== carMarketId),
        notifications: [completeNotif, ...state.notifications.slice(0, 15)],
      };
    }

    case 'CANCEL_REPAIR': {
      const { carMarketId } = action.payload;
      return {
        ...state,
        garage: state.garage.map(c => {
          if (c.marketId === carMarketId) {
            return {
              ...c,
              repairingUntil: undefined,
            };
          }
          return c;
        }),
        activeRepairs: state.activeRepairs.filter(r => r.carMarketId !== carMarketId),
      };
    }

    case 'REPAIR_CAR': {
      const { carMarketId, cost } = action.payload;
      if (state.money < cost) return state;

      const car = state.garage.find(c => c.marketId === carMarketId);
      if (!car) return state;

      let nextCond = car.condition;
      if (car.condition === 'Ağır Hasarlı') nextCond = 'Değişen';
      else if (car.condition === 'Değişen') nextCond = 'Boyalı';
      else nextCond = 'Boyalı';

      const isTutorialRepair = state.tutorialStep === 'repair_egea';
      let newOffers = state.offers;
      if (isTutorialRepair) {
        const tutOffer: CustomerOffer = {
          id: 'tut_offer_ahmet_egea',
          carMarketId: carMarketId,
          carName: `${car.brand} ${car.model}`,
          carImage: car.image || 'https://i.hizliresim.com/xtff08hf.jpg',
          buyerName: 'Ahmet Bey (Müteahhit)',
          buyerAvatar: '👨‍💼',
          buyerType: 'Galeri Esnafı',
          offeredPrice: 710000,
          originalPrice: 710000,
          dayReceived: state.day,
          expiresDay: state.day + 3,
          message: 'Hayırlı işler ustam! Fiat Egea ilanı için nakit hazır, hemen notere geçelim mi? Son fiyatın nedir?',
          negotiated: false,
        };
        newOffers = [tutOffer, ...state.offers.filter(o => o.id !== 'tut_offer_ahmet_egea')];
      }

      const repairNotif = {
        id: generateUniqueId('notif_rep_instant'),
        title: 'Araç Bakımı Tamamlandı ✨',
        message: `${car.brand} ${car.model} onarılarak '${nextCond}' kondisyona getirildi.`,
        type: 'repair' as const,
        timestamp: Date.now(),
      };

      return {
        ...state,
        money: state.money - cost,
        garage: state.garage.map(c => {
          if (c.marketId === carMarketId) {
            return {
              ...c,
              condition: nextCond,
              purchasePrice: c.purchasePrice + cost,
            };
          }
          return c;
        }),
        offers: newOffers,
        tutorialStep: isTutorialRepair ? 'go_offers' : state.tutorialStep,
        repairsCompleted: (state.repairsCompleted || 0) + 1,
        notifications: [repairNotif, ...state.notifications.slice(0, 15)],
      };
    }

    case 'CLAIM_ACHIEVEMENT': {
      const { achievementId, moneyReward = 0, reputationReward = 0, title = 'Başarım' } = action.payload;
      if (state.claimedAchievementIds?.includes(achievementId)) return state;

      const claimNotif = {
        id: generateUniqueId(`notif_ach_${achievementId}`),
        title: '🏆 Başarım Ödülü Alındı!',
        message: `'${title}' başarımı tamamlandı! Ödül: ${moneyReward > 0 ? `+${formatMoney(moneyReward)} ` : ''}${reputationReward > 0 ? `+${reputationReward} İtibar` : ''}`,
        type: 'info' as const,
        timestamp: Date.now(),
      };

      return {
        ...state,
        money: state.money + moneyReward,
        reputation: Math.min(100, state.reputation + reputationReward),
        claimedAchievementIds: [...(state.claimedAchievementIds || []), achievementId],
        notifications: [claimNotif, ...state.notifications.slice(0, 15)],
      };
    }

    case 'BUY_UPGRADE': {
      const { upgradeId, cost } = action.payload;
      if (state.money < cost) return state;

      const currentLvl = state.upgrades?.[upgradeId] || 1;
      const nextTier = getNextTier(upgradeId, currentLvl);
      if (!nextTier) return state;

      const updatedUpgrades = {
        ...state.upgrades,
        [upgradeId]: nextTier.level,
      };

      const upgradeNotif = {
        id: generateUniqueId('notif_upg'),
        title: 'Dükkan Geliştirmesi Alındı! 🚀',
        message: `${nextTier.name} seviyesine yükseltildi! (${nextTier.benefitText})`,
        type: 'info' as const,
        timestamp: Date.now(),
      };

      return {
        ...state,
        money: state.money - cost,
        upgrades: updatedUpgrades,
        notifications: [upgradeNotif, ...state.notifications.slice(0, 15)],
      };
    }

    case 'REFRESH_MARKET': {
      const newMarket = action.payload?.newMarket || generateFullMarketCatalog();
      return {
        ...state,
        market: newMarket,
        notifications: [
          {
            id: generateUniqueId('notif_mkt_ref'),
            title: 'Piyasa Güncellendi 🔄',
            message: `${newMarket.length} adet güncel ilan yüklendi. Tüm markalarda yeni fırsatlar mevcut!`,
            type: 'info',
            timestamp: Date.now(),
          },
          ...state.notifications.slice(0, 15),
        ],
      };
    }

    case 'NEXT_DAY': {
      const nextDay = state.day + 1;
      // Filter out offers that expired
      const validOldOffers = state.offers.filter(o => o.expiresDay >= nextDay);
      // Generate daily offers for garage cars with marketing & paint booth bonuses
      const marketingLvl = state.upgrades?.marketing || 1;
      const paintLvl = state.upgrades?.paint_booth || 1;
      const newOffers = generateDailyOffers(state.garage, nextDay, state.reputation, marketingLvl, paintLvl);
      const combinedOffers = [...validOldOffers, ...newOffers];

      let newNotifications = [...state.notifications];
      if (newOffers.length > 0) {
        newNotifications.unshift({
          id: generateUniqueId(`notif_day_${nextDay}`),
          title: `Gün ${nextDay}: Yeni Müşteri Teklifleri! 🔔`,
          message: `Galerinizdeki araçlar için ${newOffers.length} yeni müşteri teklifi geldi.`,
          type: 'offer',
          timestamp: Date.now(),
        });
      }

      // If action has newMarket, use it, else keep full catalog
      const marketToUse = action.payload.newMarket && action.payload.newMarket.length > 30 
        ? action.payload.newMarket 
        : (state.market.length > 30 ? state.market : generateFullMarketCatalog());

      return {
        ...state,
        day: nextDay,
        market: marketToUse,
        offers: combinedOffers,
        notifications: newNotifications.slice(0, 15),
      };
    }

    case 'ADD_OFFER': {
      // Check if offer for this car is already there from this buyer
      const exists = state.offers.some(o => o.id === action.payload.id || (o.carMarketId === action.payload.carMarketId && o.buyerName === action.payload.buyerName));
      if (exists) return state;

      const offerNotif = {
        id: generateUniqueId('notif_offer'),
        title: 'Yeni Müşteri Geldi! 🔔',
        message: `${action.payload.buyerName}, ${action.payload.carName} için ${formatMoney(action.payload.offeredPrice)} teklif etti.`,
        type: 'offer' as const,
        timestamp: Date.now(),
      };

      return {
        ...state,
        offers: [action.payload, ...state.offers],
        notifications: [offerNotif, ...state.notifications.slice(0, 15)],
      };
    }

    case 'ADD_NOTIFICATION': {
      const newNotif = {
        ...action.payload,
        id: generateUniqueId('notif_custom'),
        timestamp: Date.now(),
      };
      return {
        ...state,
        notifications: [newNotif, ...state.notifications.slice(0, 15)],
      };
    }

    case 'DISMISS_NOTIFICATION': {
      return {
        ...state,
        notifications: state.notifications.filter(n => n.id !== action.payload.id),
      };
    }

    case 'SET_TRADE_REPORT': {
      return {
        ...state,
        activeTradeReport: action.payload,
      };
    }

    case 'CLOSE_TRADE_REPORT': {
      return {
        ...state,
        activeTradeReport: null,
      };
    }
    
    case 'RESET_GAME': {
      return {
        ...INITIAL_STATE,
        market: action.payload.initialMarket || generateFullMarketCatalog(),
      };
    }

    default:
      return state;
  }
};

const GameContext = createContext<{
  state: GameState;
  dispatch: React.Dispatch<GameAction>;
} | undefined>(undefined);

export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(gameReducer, INITIAL_STATE, (initial) => {
    try {
      const saved = localStorage.getItem('ototuccar_save');
      if (saved) {
        const parsed = JSON.parse(saved);
        // Ensure the market always has the massive catalog (at least 40+ cars)
        if (!Array.isArray(parsed.market) || parsed.market.length < 30) {
          parsed.market = generateFullMarketCatalog();
        } else {
          parsed.market = parsed.market.map(ensureCar);
        }
        if (!Array.isArray(parsed.garage)) {
          parsed.garage = [];
        } else {
          parsed.garage = parsed.garage.map(ensureCar);
        }
        if (!Array.isArray(parsed.collectedModelKeys)) {
          // Initialize stamps from existing garage cars if any
          parsed.collectedModelKeys = Array.isArray(parsed.garage)
            ? Array.from(new Set(parsed.garage.map((c: any) => `${c.brand.trim().toLowerCase()}_${c.model.trim().toLowerCase()}`)))
            : [];
        }
        if (!Array.isArray(parsed.activeRepairs)) parsed.activeRepairs = [];
        if (!Array.isArray(parsed.offers)) parsed.offers = [];
        if (!Array.isArray(parsed.notifications)) {
          parsed.notifications = [];
        } else {
          const seenNotifIds = new Set<string>();
          parsed.notifications = parsed.notifications.map((n: any, idx: number) => {
            let nid = n?.id;
            if (!nid || seenNotifIds.has(nid)) {
              nid = generateUniqueId(`notif_loaded_${idx}`);
            }
            seenNotifIds.add(nid);
            return { ...n, id: nid };
          });
        }
        if (!Array.isArray(parsed.claimedAchievementIds)) parsed.claimedAchievementIds = [];
        if (typeof parsed.totalProfit !== 'number') parsed.totalProfit = 0;
        if (typeof parsed.carsSold !== 'number') parsed.carsSold = 0;
        if (typeof parsed.carsBought !== 'number') parsed.carsBought = parsed.garage.length + (parsed.carsSold || 0);
        if (typeof parsed.repairsCompleted !== 'number') parsed.repairsCompleted = 0;
        if (typeof parsed.money !== 'number') parsed.money = 1000000;
        if (typeof parsed.day !== 'number') parsed.day = 1;
        if (typeof parsed.reputation !== 'number') parsed.reputation = 50;
        if (!parsed.galleryName || typeof parsed.galleryName !== 'string') {
          parsed.galleryName = 'Son Fiyat Motors';
        }
        if (typeof parsed.tutorialCompleted !== 'boolean') {
          parsed.tutorialCompleted = false;
        }
        if (!parsed.upgrades || typeof parsed.upgrades !== 'object') {
          parsed.upgrades = DEFAULT_UPGRADES;
        } else {
          parsed.upgrades = {
            ...DEFAULT_UPGRADES,
            ...parsed.upgrades,
          };
        }
        return parsed;
      }
    } catch (e) {
      console.error('Failed to load save game', e);
    }
    return initial;
  });

  useEffect(() => {
    localStorage.setItem('ototuccar_save', JSON.stringify(state));
  }, [state]);

  // Active Repairs countdown monitor
  useEffect(() => {
    if (state.activeRepairs.length === 0) return;

    const interval = setInterval(() => {
      const now = Date.now();
      state.activeRepairs.forEach(repair => {
        if (now >= repair.finishTimestamp) {
          dispatch({ type: 'COMPLETE_REPAIR', payload: { carMarketId: repair.carMarketId } });
        }
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [state.activeRepairs]);

  // Periodic incoming offer simulation:
  // Random customer visits the gallery faster if marketing is upgraded
  useEffect(() => {
    if (state.garage.length === 0) return;

    // Base interval ~18s; reduced by marketing level (e.g. lvl 4: ~7.5s)
    const marketingLvl = state.upgrades?.marketing || 1;
    const marketingDelays = [18000, 18000, 13000, 9500, 6500];
    const delay = marketingDelays[marketingLvl] || 18000;

    const interval = setInterval(() => {
      if (Math.random() < 0.70 && state.garage.length > 0) {
        const randomCar = state.garage[Math.floor(Math.random() * state.garage.length)];
        // Check if car doesn't already have 3 active offers
        const currentCarOffers = state.offers.filter(o => o.carMarketId === randomCar.marketId);
        if (currentCarOffers.length < 3) {
          const paintLvl = state.upgrades?.paint_booth || 1;
          const newOffer = generateCustomerOffer(randomCar, state.day, state.reputation, paintLvl);
          dispatch({ type: 'ADD_OFFER', payload: newOffer });
        }
      }
    }, delay);

    return () => clearInterval(interval);
  }, [state.garage, state.day, state.reputation, state.offers, state.upgrades?.marketing, state.upgrades?.paint_booth]);

  return (
    <GameContext.Provider value={{ state, dispatch }}>
      {children}
    </GameContext.Provider>
  );
};

export const useGame = () => {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};

