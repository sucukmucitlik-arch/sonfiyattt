export type Condition = 'Temiz' | 'Boyalı' | 'Değişen' | 'Ağır Hasarlı';

export type BuyerType = 'Bireysel Alıcı' | 'Galeri Esnafı' | 'Acele Alıcı' | 'Koleksiyoner' | 'Ölücü / Fırsatçı Alıcı';

export type PartStatus = 'original' | 'painted' | 'replaced' | string;

export type InspectionPartKey = 
  | 'kaput' 
  | 'tavan' 
  | 'bagaj' 
  | 'solOnCamurluk' 
  | 'solOnKapi' 
  | 'solArkaKapi' 
  | 'solArkaCamurluk' 
  | 'sagOnCamurluk' 
  | 'sagOnKapi' 
  | 'sagArkaKapi' 
  | 'sagArkaCamurluk' 
  | 'onTampon' 
  | 'arkaTampon';

export interface CarInspection {
  kaput: PartStatus;
  tavan: PartStatus;
  bagaj: PartStatus;
  solOnCamurluk: PartStatus;
  solOnKapi: PartStatus;
  solArkaKapi: PartStatus;
  solArkaCamurluk: PartStatus;
  sagOnCamurluk: PartStatus;
  sagOnKapi: PartStatus;
  sagArkaKapi: PartStatus;
  sagArkaCamurluk: PartStatus;
  onTampon: PartStatus;
  arkaTampon: PartStatus;
  agirHasarKayitli: boolean;
  tramerTutar: number;
  isUnrepairable?: boolean;
  unrepairableReason?: string;
}

export interface EngineSpec {
  name: string; // e.g. "1.4 Fire", "1.6 Multijet"
  fuelType: 'Benzin' | 'Dizel' | 'Hibrit' | 'Elektrik' | 'LPG' | string;
  transmission: 'Manuel' | 'Otomatik' | 'Yarı Otomatik' | string;
  motorGucu: string; // "95 hp", "130 hp"
  motorHacmi: string; // "1368 cc", "1598 cc"
  cekis: 'Önden Çekiş' | 'Arkadan İtiş' | '4x4 (AWD)' | string;
  hizlanma: string; // "11.5 sn"
  azamiSurat: string; // "186 km/saat"
  yakitTuketimi: string; // "5.8 lt / 100km"
}

export interface CarModel {
  id?: string;
  brand: string;
  model: string;
  series?: string;
  year: number;
  basePrice: number;
  type: 'Sedan' | 'Hatchback' | 'SUV' | 'Coupe' | 'Spor' | 'Minivan' | string;
  image: string;
  color: string;
  engine: EngineSpec;
  inspection: CarInspection;
  description?: string;
}

export type SellerType = 
  | 'Tok Satıcı' 
  | 'Normal Binici' 
  | 'Acil İhtiyaçtan' 
  | 'Galeri Esnafı' 
  | 'Gözü Açık Satıcı';

export type DealGrade = 'A' | 'B' | 'C' | 'D';

export interface TradeReport {
  id: string;
  type: 'buy' | 'sell';
  grade: DealGrade;
  carBrand: string;
  carModel: string;
  carYear: number;
  carImage: string;
  price: number; // buy price or sell price
  referenceValue: number; // fairMarketValue (if buy) or totalCost (if sell)
  diffAmount: number; // (fairMarketValue - purchasePrice) or profit
  diffPercentage: number; // % difference from FMV or profit margin %
  partnerName?: string; // sellerName or buyerName
  partnerAvatar?: string;
  discountAmount?: number;
  title: string;
  badgeLabel: string;
  badgeClass: string;
  description: string;
  advice: string;
  stars: number;
  timestamp: number;
}

export interface MarketCar extends CarModel {
  marketId: string;
  km: number;
  condition: Condition;
  price: number;
  originalAskingPrice?: number; // Initial asking price before bargaining
  fairMarketValue?: number; // True estimated market valuation
  isOverpriced?: boolean; // True when price is +12% to +30% above market value
  overpricedPercentage?: number; // E.g. +22% or -15%
  sellerType?: SellerType;
  sellerName?: string;
  sellerAvatar?: string;
  sellerPatience?: number; // How many counter offers before walking away (1-4)
  sellerMinPrice?: number; // Lowest price seller will accept
  sellerQuote?: string; // Characteristic quote from seller
  adTitle: string;
  isUnrepairable?: boolean;
  unrepairableReason?: string;
}

export interface ActiveRepair {
  carMarketId: string;
  finishTimestamp: number;
  totalDurationMs: number;
  cost: number;
  targetCondition: Condition;
}

export interface PlayerCar extends MarketCar {
  purchasePrice: number;
  totalInvestedCost?: number; // purchasePrice + repair costs
  listedPrice?: number;
  boughtAtDay: number;
  repairingUntil?: number; // timestamp when repair finishes
  originalConditionWhenBought?: Condition;
  buyDealGrade?: DealGrade;
  buyDiffPercentage?: number;
}

export interface CustomerOffer {
  id: string;
  carMarketId: string;
  carName: string;
  carImage: string;
  buyerName: string;
  buyerType: BuyerType;
  buyerAvatar: string;
  offeredPrice: number;
  originalPrice: number;
  message: string;
  dayReceived: number;
  expiresDay: number;
  negotiated?: boolean;
}

export interface GameNotification {
  id: string;
  title: string;
  message: string;
  type: 'offer' | 'sale' | 'info' | 'repair';
  timestamp: number;
  read?: boolean;
}

export type TutorialStep = 
  | 'idle'
  | 'buy_egea'
  | 'go_garage'
  | 'repair_egea'
  | 'go_offers'
  | 'bargain_egea'
  | 'completed';

export interface GameUpgrades {
  parking: number; // level 1-4
  repair_speed: number; // level 1-4
  paint_booth: number; // level 1-4
  marketing: number; // level 1-4
  mechanic_discount: number; // level 1-4
}

export interface GameState {
  galleryName?: string;
  tutorialCompleted?: boolean;
  tutorialStep?: TutorialStep;
  money: number;
  day: number;
  reputation: number;
  garage: PlayerCar[];
  market: MarketCar[];
  offers: CustomerOffer[];
  notifications: GameNotification[];
  totalProfit: number;
  carsSold: number;
  carsBought: number;
  repairsCompleted: number;
  collectedModelKeys: string[]; // List of collected unique "brand_model" stamps
  activeRepairs: ActiveRepair[]; // Timer based repairs
  upgrades: GameUpgrades; // Shop purchased upgrades
  claimedAchievementIds: string[]; // List of claimed achievement IDs
  activeTradeReport?: TradeReport | null; // Popup report for buy/sell grades A/B/C/D
}

export type GameAction = 
  | { type: 'SET_GALLERY_NAME'; payload: string }
  | { type: 'START_INTERACTIVE_TUTORIAL' }
  | { type: 'SET_TUTORIAL_STEP'; payload: TutorialStep }
  | { type: 'SKIP_TUTORIAL' }
  | { type: 'COMPLETE_TUTORIAL' }
  | { type: 'ADD_MONEY'; payload: number }
  | { type: 'BUY_CAR'; payload: MarketCar | { car: MarketCar; customPrice?: number; discountAmount?: number } }
  | { type: 'ACCEPT_OFFER'; payload: { offerId: string } }
  | { type: 'REJECT_OFFER'; payload: { offerId: string } }
  | { type: 'COUNTER_OFFER_RESULT'; payload: { offerId: string; newPrice?: number; success: boolean; buyerResponse: string } }
  | { type: 'START_REPAIR'; payload: { carMarketId: string; cost: number; durationSeconds?: number } }
  | { type: 'COMPLETE_REPAIR'; payload: { carMarketId: string } }
  | { type: 'CANCEL_REPAIR'; payload: { carMarketId: string } }
  | { type: 'REPAIR_CAR'; payload: { carMarketId: string; cost: number } }
  | { type: 'BUY_UPGRADE'; payload: { upgradeId: keyof GameUpgrades; cost: number } }
  | { type: 'CLAIM_ACHIEVEMENT'; payload: { achievementId: string; moneyReward?: number; reputationReward?: number; title?: string } }
  | { type: 'NEXT_DAY'; payload: { newMarket: MarketCar[]; newOffers: CustomerOffer[] } }
  | { type: 'REFRESH_MARKET'; payload?: { newMarket?: MarketCar[] } }
  | { type: 'ADD_OFFER'; payload: CustomerOffer }
  | { type: 'ADD_NOTIFICATION'; payload: Omit<GameNotification, 'id' | 'timestamp'> }
  | { type: 'DISMISS_NOTIFICATION'; payload: { id: string } }
  | { type: 'SET_TRADE_REPORT'; payload: TradeReport | null }
  | { type: 'CLOSE_TRADE_REPORT' }
  | { type: 'RESET_GAME'; payload: { initialMarket: MarketCar[] } };


