import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MarketCar, PlayerCar } from '../types';
import { formatMoney, formatKm, getConditionColor, ensureInspection, ensureEngine, normalizeImageUrl, getDealGradeInfo } from '../utils';
import { CarInspectionDiagram } from './CarInspectionDiagram';
import { 
  X, 
  Share2, 
  Star, 
  ArrowLeft, 
  ShieldCheck, 
  AlertTriangle, 
  Check, 
  Fuel, 
  Gauge, 
  Layers, 
  Calendar, 
  Zap,
  MapPin,
  User,
  CheckCircle,
  Clock,
  Award,
  TrendingDown,
  TrendingUp
} from 'lucide-react';

interface CarDetailModalProps {
  car: MarketCar | PlayerCar | null;
  isOpen: boolean;
  onClose: () => void;
  actionButton?: React.ReactNode;
  isGarage?: boolean;
  onRepair?: () => void;
  onStartBargain?: () => void;
}

export const CarDetailModal: React.FC<CarDetailModalProps> = ({
  car,
  isOpen,
  onClose,
  actionButton,
  isGarage = false,
  onRepair,
  onStartBargain,
}) => {
  const [activeTab, setActiveTab] = useState<'info' | 'desc' | 'location'>('info');
  const [copied, setCopied] = useState(false);
  const [starred, setStarred] = useState(false);

  if (!isOpen || !car) return null;

  const isPlayerCar = isGarage && 'purchasePrice' in car;
  const inspection = ensureInspection(car.inspection, car.condition);
  const engine = ensureEngine(car.engine);
  const dealInfo = !isPlayerCar && !isGarage 
    ? getDealGradeInfo(car.price, (car as MarketCar).fairMarketValue)
    : null;

  const handleShare = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="bg-white dark:bg-zinc-900 rounded-2xl w-full max-w-4xl shadow-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden flex flex-col my-auto max-h-[92vh]"
        >
          {/* Header Bar */}
          <div className="bg-orange-500 text-white px-4 py-3 flex items-center justify-between shadow-sm">
            <div className="flex items-center space-x-2">
              <button
                onClick={onClose}
                className="p-1.5 hover:bg-orange-600 rounded-full transition-colors"
                title="Geri"
              >
                <ArrowLeft size={20} />
              </button>
              <h2 className="font-bold text-base sm:text-lg">İlan Detayı</h2>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={handleShare}
                className="p-1.5 hover:bg-orange-600 rounded-lg transition-colors text-white/90 relative"
                title="Paylaş"
              >
                {copied ? <Check size={18} className="text-emerald-300" /> : <Share2 size={18} />}
              </button>
              <button
                onClick={() => setStarred(!starred)}
                className={`p-1.5 hover:bg-orange-600 rounded-lg transition-colors ${
                  starred ? 'text-yellow-300' : 'text-white/90'
                }`}
                title="Favorilere Ekle"
              >
                <Star size={18} className={starred ? 'fill-yellow-300' : ''} />
              </button>
              <button
                onClick={onClose}
                className="p-1.5 hover:bg-orange-600 rounded-lg transition-colors text-white/90"
              >
                <X size={20} />
              </button>
            </div>
          </div>

          {/* Ad Title Ribbon */}
          <div className="bg-zinc-100 dark:bg-zinc-850 px-4 py-2.5 border-b border-zinc-200 dark:border-zinc-800 text-center font-bold text-zinc-900 dark:text-zinc-100 text-xs sm:text-sm tracking-wide">
            "{car.adTitle || `${car.year} ${car.brand} ${car.model} ${car.series || ''} ${formatKm(car.km || 0)}`}"
          </div>

          {/* Navigation Tabs (İlan Bilgileri / Açıklama / Konumu) */}
          <div className="grid grid-cols-3 bg-white dark:bg-zinc-900 border-b border-zinc-200 dark:border-zinc-800 text-center">
            <button
              onClick={() => setActiveTab('info')}
              className={`py-3 text-xs sm:text-sm font-bold transition-all border-b-2 ${
                activeTab === 'info'
                  ? 'border-orange-500 text-orange-600 dark:text-orange-400 bg-orange-50/50 dark:bg-orange-950/20'
                  : 'border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
              }`}
            >
              İlan Bilgileri
            </button>
            <button
              onClick={() => setActiveTab('desc')}
              className={`py-3 text-xs sm:text-sm font-bold transition-all border-b-2 ${
                activeTab === 'desc'
                  ? 'border-orange-500 text-orange-600 dark:text-orange-400 bg-orange-50/50 dark:bg-orange-950/20'
                  : 'border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
              }`}
            >
              Açıklama
            </button>
            <button
              onClick={() => setActiveTab('location')}
              className={`py-3 text-xs sm:text-sm font-bold transition-all border-b-2 ${
                activeTab === 'location'
                  ? 'border-orange-500 text-orange-600 dark:text-orange-400 bg-orange-50/50 dark:bg-orange-950/20'
                  : 'border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
              }`}
            >
              Konumu / Galeri
            </button>
          </div>

          {/* Modal Content Scrollable Body */}
          <div className="overflow-y-auto p-4 sm:p-6 space-y-6 flex-grow">
            {/* Top Showcase: Car Large Icon + Price + Quick Badges */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 bg-gradient-to-r from-orange-50 to-amber-50 dark:from-zinc-800 dark:to-zinc-850 rounded-2xl border border-orange-200/60 dark:border-zinc-700">
              <div className="flex items-center space-x-4">
                <div className="w-24 h-20 sm:w-28 sm:h-24 bg-white dark:bg-zinc-800 rounded-2xl flex items-center justify-center text-5xl shadow-sm border border-orange-100 dark:border-zinc-700 select-none overflow-hidden flex-shrink-0">
                  {car.image && (car.image.startsWith('http') || car.image.startsWith('/') || car.image.startsWith('data:')) ? (
                    <img 
                      src={normalizeImageUrl(car.image)} 
                      alt={`${car.brand} ${car.model}`}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span>{car.image || '🚗'}</span>
                  )}
                </div>
                <div>
                  <div className="text-xs uppercase font-bold text-orange-600 dark:text-orange-400 tracking-wider">
                    {car.brand} {car.type || 'Sedan'}
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-white">
                    {car.brand} {car.model}
                  </h3>
                  <div className="text-xs text-zinc-500 dark:text-zinc-400 font-medium">
                    {car.series || engine.name} • {car.color || 'Beyaz'}
                  </div>
                </div>
              </div>

              <div className="text-right flex flex-col sm:items-end">
                <span className="text-xs text-zinc-400 font-bold uppercase">
                  {isPlayerCar ? 'Alış Maliyeti' : 'Satış Fiyatı'}
                </span>
                <span className="text-2xl sm:text-3xl font-black text-orange-600 dark:text-orange-400">
                  {formatMoney(isPlayerCar ? (car as PlayerCar).purchasePrice : car.price)}
                </span>
                <span className={`inline-block mt-1 px-2.5 py-0.5 rounded-full text-xs font-bold ${getConditionColor(car.condition)}`}>
                  {car.condition}
                </span>
              </div>
            </div>

            {/* TAB 1: İLAN BİLGİLERİ */}
            {activeTab === 'info' && (
              <div className="space-y-6">
                {/* 1. Main Specs Table (Sahibinden Style) */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-3 flex items-center gap-1.5">
                    <Layers size={14} /> Genel Araç Parametreleri
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 divide-y divide-zinc-100 dark:divide-zinc-800 text-sm">
                    <div className="py-2.5 flex justify-between">
                      <span className="text-zinc-500">Araç Durumu</span>
                      <span className="font-semibold text-zinc-800 dark:text-zinc-200">İkinci El</span>
                    </div>
                    <div className="py-2.5 flex justify-between">
                      <span className="text-zinc-500">Yıl</span>
                      <span className="font-semibold text-zinc-800 dark:text-zinc-200">{car.year}</span>
                    </div>
                    <div className="py-2.5 flex justify-between">
                      <span className="text-zinc-500">KM</span>
                      <span className="font-semibold text-zinc-800 dark:text-zinc-200">{formatKm(car.km || 0)}</span>
                    </div>
                    <div className="py-2.5 flex justify-between">
                      <span className="text-zinc-500">Kasa Tipi</span>
                      <span className="font-semibold text-zinc-800 dark:text-zinc-200">{car.type || 'Sedan'}</span>
                    </div>
                    <div className="py-2.5 flex justify-between">
                      <span className="text-zinc-500">Motor Gücü</span>
                      <span className="font-semibold text-zinc-800 dark:text-zinc-200">{engine.motorGucu}</span>
                    </div>
                    <div className="py-2.5 flex justify-between">
                      <span className="text-zinc-500">Motor Hacmi</span>
                      <span className="font-semibold text-zinc-800 dark:text-zinc-200">{engine.motorHacmi}</span>
                    </div>
                    <div className="py-2.5 flex justify-between">
                      <span className="text-zinc-500">Çekiş</span>
                      <span className="font-semibold text-zinc-800 dark:text-zinc-200">{engine.cekis}</span>
                    </div>
                    <div className="py-2.5 flex justify-between">
                      <span className="text-zinc-500">Yakıt Türü</span>
                      <span className="font-semibold text-zinc-800 dark:text-zinc-200">{engine.fuelType}</span>
                    </div>
                    <div className="py-2.5 flex justify-between">
                      <span className="text-zinc-500">Vites</span>
                      <span className="font-semibold text-zinc-800 dark:text-zinc-200">{engine.transmission}</span>
                    </div>
                    <div className="py-2.5 flex justify-between">
                      <span className="text-zinc-500">Renk</span>
                      <span className="font-semibold text-zinc-800 dark:text-zinc-200">{car.color || 'Beyaz'}</span>
                    </div>
                    <div className="py-2.5 flex justify-between">
                      <span className="text-zinc-500">Garanti</span>
                      <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                        {car.isUnrepairable || inspection.isUnrepairable ? 'Yok (Pert Kaydı)' : 'Evet'}
                      </span>
                    </div>
                    <div className="py-2.5 flex justify-between">
                      <span className="text-zinc-500">Ağır Hasar Kayıtlı</span>
                      <span className={`font-bold ${inspection.agirHasarKayitli ? 'text-red-600' : 'text-zinc-800 dark:text-zinc-200'}`}>
                        {inspection.agirHasarKayitli ? 'Evet (Ağır Hasarlı)' : 'Hayır'}
                      </span>
                    </div>
                    {(car.isUnrepairable || inspection.isUnrepairable) && (
                      <div className="py-2.5 flex justify-between bg-rose-50 dark:bg-rose-950/40 px-2 rounded-lg border border-rose-200 dark:border-rose-800">
                        <span className="text-rose-700 dark:text-rose-300 font-bold">Onarım Durumu</span>
                        <span className="font-black text-rose-600 dark:text-rose-400">TAMİR EDİLEMEZ (Pert)</span>
                      </div>
                    )}
                    <div className="py-2.5 flex justify-between">
                      <span className="text-zinc-500">Plaka / Uyruk</span>
                      <span className="font-semibold text-zinc-800 dark:text-zinc-200">Türkiye (TR) Plakalı</span>
                    </div>
                    <div className="py-2.5 flex justify-between">
                      <span className="text-zinc-500">Kimden</span>
                      <span className="font-semibold text-zinc-800 dark:text-zinc-200">{isGarage ? 'Galeriden (Sizden)' : 'Sahibinden / Galeriden'}</span>
                    </div>
                    <div className="py-2.5 flex justify-between">
                      <span className="text-zinc-500">Takas</span>
                      <span className="font-semibold text-emerald-600 dark:text-emerald-400">Evet</span>
                    </div>
                  </div>
                </div>

                {/* 2. Technical Performance Specs */}
                <div className="bg-zinc-50 dark:bg-zinc-800/40 p-4 rounded-xl border border-zinc-100 dark:border-zinc-800">
                  <div className="flex justify-between items-center mb-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-500 flex items-center gap-1.5">
                      <Zap size={14} className="text-orange-500" /> TEKNİK PERFORMANS ÖZELLİKLERİ
                    </h4>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                    <div className="bg-white dark:bg-zinc-850 p-3 rounded-lg border border-zinc-100 dark:border-zinc-800">
                      <span className="text-[10px] text-zinc-400 uppercase font-semibold">0-100 Hızlanma</span>
                      <div className="text-base font-black text-zinc-800 dark:text-zinc-100 mt-0.5">{engine.hizlanma}</div>
                    </div>
                    <div className="bg-white dark:bg-zinc-850 p-3 rounded-lg border border-zinc-100 dark:border-zinc-800">
                      <span className="text-[10px] text-zinc-400 uppercase font-semibold">Azami Sürat</span>
                      <div className="text-base font-black text-zinc-800 dark:text-zinc-100 mt-0.5">{engine.azamiSurat}</div>
                    </div>
                    <div className="bg-white dark:bg-zinc-850 p-3 rounded-lg border border-zinc-100 dark:border-zinc-800">
                      <span className="text-[10px] text-zinc-400 uppercase font-semibold">Motor Gücü</span>
                      <div className="text-base font-black text-zinc-800 dark:text-zinc-100 mt-0.5">{engine.motorGucu}</div>
                    </div>
                    <div className="bg-white dark:bg-zinc-850 p-3 rounded-lg border border-zinc-100 dark:border-zinc-800">
                      <span className="text-[10px] text-zinc-400 uppercase font-semibold">Ort. Yakıt</span>
                      <div className="text-base font-black text-zinc-800 dark:text-zinc-100 mt-0.5">{engine.yakitTuketimi}</div>
                    </div>
                  </div>
                </div>

                {/* 3. Boya, Değişen ve Ekspertiz Şeması */}
                <CarInspectionDiagram inspection={inspection} />
              </div>
            )}

            {/* TAB 2: AÇIKLAMA */}
            {activeTab === 'desc' && (
              <div className="space-y-4 text-sm text-zinc-700 dark:text-zinc-300 leading-relaxed bg-zinc-50 dark:bg-zinc-800/30 p-5 rounded-xl border border-zinc-200 dark:border-zinc-800">
                <h4 className="font-bold text-zinc-900 dark:text-white text-base">
                  Satıcı Açıklaması
                </h4>
                <p>
                  {car.description ||
                    `${car.year} model ${car.brand} ${car.model} ${car.series || ''} aracımız ${formatKm(
                      car.km || 0
                    )} kilometrede olup son derece temiz durumdadır. Tüm periyodik bakımları zamanında yapılmıştır. Yedek anahtarı ve kitapçıkları mevcuttur.`}
                </p>
                <div className="pt-4 border-t border-zinc-200 dark:border-zinc-700 space-y-2 text-xs text-zinc-500">
                  <div className="flex items-center gap-2">
                    <CheckCircle size={14} className="text-emerald-500" />
                    <span>Ekspertiz raporu günceldir ve fotoğraflarda belirtilmiştir.</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle size={14} className="text-emerald-500" />
                    <span>Noter satışına hazırdır, borcu veya haczi yoktur.</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle size={14} className="text-emerald-500" />
                    <span>Takas teklifleri sadece değerinde araçlar için değerlendirilir.</span>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: KONUMU & SATICI BİLGİSİ */}
            {activeTab === 'location' && (
              <div className="space-y-4 bg-zinc-50 dark:bg-zinc-800/30 p-5 rounded-xl border border-zinc-200 dark:border-zinc-800 text-sm">
                <div className="flex items-center space-x-3 pb-4 border-b border-zinc-200 dark:border-zinc-700">
                  <div className="w-12 h-12 bg-orange-100 dark:bg-orange-950/60 rounded-full flex items-center justify-center text-orange-600 font-bold text-xl">
                    <User size={24} />
                  </div>
                  <div>
                    <h5 className="font-bold text-zinc-900 dark:text-white">
                      {isGarage ? 'Kendi Galeriniz (Vitrin)' : 'Güvenilir Otomotiv Galerisi'}
                    </h5>
                    <p className="text-xs text-zinc-500">Üyelik Tarihi: Mart 2021 • Onaylı Kurumsal Satıcı</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3 text-zinc-600 dark:text-zinc-300">
                  <MapPin size={18} className="text-orange-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-zinc-900 dark:text-white block">Oto Galericiler Sitesi B Blok No: 42</span>
                    <span className="text-xs text-zinc-500">İstanbul / Kadıköy / Kozyatağı</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Action Footer */}
          <div className="bg-zinc-50 dark:bg-zinc-850 p-4 border-t border-zinc-200 dark:border-zinc-800 flex items-center justify-between gap-4">
            <div>
              <span className="text-xs text-zinc-400 block font-medium">Toplam Tutar</span>
              <span className="text-xl sm:text-2xl font-black text-orange-600 dark:text-orange-400">
                {formatMoney(isPlayerCar ? (car as PlayerCar).purchasePrice : car.price)}
              </span>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={onClose}
                className="px-4 py-2.5 bg-zinc-200 dark:bg-zinc-700 hover:bg-zinc-300 dark:hover:bg-zinc-600 text-zinc-800 dark:text-zinc-200 font-bold rounded-xl text-sm transition-colors"
              >
                Kapat
              </button>
              {!isPlayerCar && onStartBargain && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onStartBargain();
                  }}
                  className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-white font-black rounded-xl text-sm transition-all shadow-sm flex items-center gap-1.5"
                >
                  🤝 Pazarlık Masası
                </button>
              )}
              {actionButton}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
