import React, { useState } from 'react';
import { useGame } from '../store/GameContext';
import { SHOP_UPGRADES, UpgradeCategory, UpgradeTier } from '../data/upgrades';
import { getCurrentTier, getNextTier, getMaxGarageCapacity } from '../utils/upgradeUtils';
import { formatMoney } from '../utils';
import { 
  CarFront, 
  Wrench, 
  Paintbrush, 
  Megaphone, 
  BadgePercent, 
  CheckCircle2, 
  ArrowUpRight, 
  Sparkles, 
  ShieldCheck, 
  TrendingUp, 
  Store,
  ChevronRight,
  Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface UpgradeModalProps {
  category: UpgradeCategory;
  currentLevel: number;
  onClose: () => void;
  onUpgrade: (cost: number) => void;
  canAfford: boolean;
  userMoney: number;
}

const getCategoryIcon = (iconName: string, className: string = "w-6 h-6") => {
  switch (iconName) {
    case 'CarFront': return <CarFront className={className} />;
    case 'Wrench': return <Wrench className={className} />;
    case 'Paintbrush': return <Paintbrush className={className} />;
    case 'Megaphone': return <Megaphone className={className} />;
    case 'BadgePercent': return <BadgePercent className={className} />;
    default: return <Sparkles className={className} />;
  }
};

const getBadgeColorClasses = (color: string) => {
  switch (color) {
    case 'blue':
      return {
        bg: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20',
        glow: 'shadow-blue-500/10',
        btn: 'bg-blue-600 hover:bg-blue-700 text-white',
        border: 'border-blue-500/30',
        progress: 'bg-blue-500',
      };
    case 'amber':
      return {
        bg: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20',
        glow: 'shadow-amber-500/10',
        btn: 'bg-amber-600 hover:bg-amber-700 text-white',
        border: 'border-amber-500/30',
        progress: 'bg-amber-500',
      };
    case 'purple':
      return {
        bg: 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20',
        glow: 'shadow-purple-500/10',
        btn: 'bg-purple-600 hover:bg-purple-700 text-white',
        border: 'border-purple-500/30',
        progress: 'bg-purple-500',
      };
    case 'rose':
      return {
        bg: 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/20',
        glow: 'shadow-rose-500/10',
        btn: 'bg-rose-600 hover:bg-rose-700 text-white',
        border: 'border-rose-500/30',
        progress: 'bg-rose-500',
      };
    case 'emerald':
    default:
      return {
        bg: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20',
        glow: 'shadow-emerald-500/10',
        btn: 'bg-emerald-600 hover:bg-emerald-700 text-white',
        border: 'border-emerald-500/30',
        progress: 'bg-emerald-500',
      };
  }
};

export const Shop: React.FC = () => {
  const { state, dispatch } = useGame();
  const [selectedCategory, setSelectedCategory] = useState<UpgradeCategory | null>(null);
  const [purchaseSuccess, setPurchaseSuccess] = useState<string | null>(null);

  const upgrades = state.upgrades || {
    parking: 1,
    repair_speed: 1,
    paint_booth: 1,
    marketing: 1,
    mechanic_discount: 1,
  };

  const handleBuyUpgrade = (category: UpgradeCategory, nextTier: UpgradeTier) => {
    if (state.money < nextTier.cost) return;

    dispatch({
      type: 'BUY_UPGRADE',
      payload: {
        upgradeId: category.id,
        cost: nextTier.cost,
      },
    });

    setPurchaseSuccess(`${category.name} başarıyla ${nextTier.name} seviyesine yükseltildi!`);
    setTimeout(() => setPurchaseSuccess(null), 4000);
    setSelectedCategory(null);
  };

  // Calculate total upgrades completed
  const totalLevels = (Object.values(upgrades) as number[]).reduce((acc: number, curr: number) => acc + (Number(curr) - 1), 0);
  const maxPossibleLevels = SHOP_UPGRADES.length * 3; // each upgrade has 3 upgrades beyond lvl 1
  const completionPercentage = Math.round((Number(totalLevels) / maxPossibleLevels) * 100);

  return (
    <div className="space-y-6" id="shop-view">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 text-white rounded-2xl p-6 sm:p-8 border border-zinc-700/60 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-10 -translate-y-10 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute left-1/3 bottom-0 w-64 h-64 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="p-2 bg-orange-500/20 text-orange-400 border border-orange-500/30 rounded-xl">
                <Store size={22} />
              </span>
              <span className="text-xs uppercase tracking-widest font-black text-orange-400">
                Galeri Geliştirme Merkezi
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Dükkan & Hizmet İstasyonları
            </h1>
            <p className="text-sm text-zinc-300 mt-2 max-w-2xl font-medium leading-relaxed">
              Oto galerinizi büyütün, servis hızınızı katlayın ve kazancınızı maksimize edin. Her seviye yeni ayrıcalıklar, daha geniş otopark ve daha karlı müşteri teklifleri kazandırır.
            </p>
          </div>

          {/* Quick Stats Widget */}
          <div className="bg-zinc-800/80 backdrop-blur-md border border-zinc-700 p-4 rounded-xl flex items-center gap-5 w-full md:w-auto shrink-0 shadow-lg">
            <div>
              <p className="text-xs text-zinc-400 font-medium">Toplam Geliştirme</p>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-2xl font-black text-white">%{completionPercentage}</span>
                <span className="text-xs text-zinc-400">({totalLevels}/{maxPossibleLevels})</span>
              </div>
              {/* Mini progress bar */}
              <div className="w-32 h-2 bg-zinc-700 rounded-full mt-2 overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-orange-500 to-amber-400 rounded-full transition-all duration-500"
                  style={{ width: `${completionPercentage}%` }}
                />
              </div>
            </div>

            <div className="h-10 w-px bg-zinc-700" />

            <div>
              <p className="text-xs text-zinc-400 font-medium">Garaj Kapasitesi</p>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-2xl font-black text-orange-400">
                  {state.garage.length}
                </span>
                <span className="text-xs text-zinc-400">/ {getMaxGarageCapacity(upgrades.parking)} Araç</span>
              </div>
              <p className="text-[11px] text-zinc-400 mt-1 font-semibold">
                {upgrades.parking === 4 ? 'Maksimum Seviye' : `Seviye ${upgrades.parking}/4`}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Success Notification Alert */}
      <AnimatePresence>
        {purchaseSuccess && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 rounded-2xl flex items-center justify-between gap-3 text-emerald-800 dark:text-emerald-300 shadow-sm"
          >
            <div className="flex items-center gap-2.5">
              <CheckCircle2 size={20} className="text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span className="text-sm font-bold">{purchaseSuccess}</span>
            </div>
            <button 
              onClick={() => setPurchaseSuccess(null)}
              className="text-xs font-black uppercase text-emerald-700 dark:text-emerald-400 hover:underline"
            >
              Kapat
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Upgrade Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {SHOP_UPGRADES.map((category) => {
          const currentLvl = upgrades[category.id] || 1;
          const currentTier = getCurrentTier(category.id, currentLvl);
          const nextTier = getNextTier(category.id, currentLvl);
          const isMaxLevel = !nextTier;
          const canAfford = nextTier ? state.money >= nextTier.cost : false;
          const colors = getBadgeColorClasses(category.badgeColor);

          return (
            <div
              key={category.id}
              id={`upgrade-card-${category.id}`}
              className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-5 sm:p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between group relative overflow-hidden"
            >
              {/* Top Row: Icon + Level Badge */}
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className={`p-3 rounded-2xl border ${colors.bg}`}>
                    {getCategoryIcon(category.icon, "w-6 h-6")}
                  </div>

                  <div className="flex flex-col items-end">
                    <span className="text-xs font-black px-2.5 py-1 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700">
                      {isMaxLevel ? (
                        <span className="text-amber-600 dark:text-amber-400 font-black flex items-center gap-1">
                          <Sparkles size={12} /> MAKS SEVİYE
                        </span>
                      ) : (
                        `Seviye ${currentLvl} / ${category.tiers.length}`
                      )}
                    </span>

                    {/* Level step indicator dots */}
                    <div className="flex items-center gap-1.5 mt-2">
                      {category.tiers.map((t) => (
                        <div
                          key={t.level}
                          className={`h-1.5 rounded-full transition-all ${
                            t.level <= currentLvl
                              ? `w-4 ${colors.progress}`
                              : 'w-2 bg-zinc-200 dark:bg-zinc-700'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                {/* Title & Description */}
                <h3 className="text-lg font-black text-zinc-900 dark:text-white mt-4 group-hover:text-orange-500 dark:group-hover:text-orange-400 transition-colors">
                  {category.name}
                </h3>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1 font-medium leading-relaxed">
                  {category.shortDesc}
                </p>

                {/* Current Active Status Box */}
                <div className="mt-4 p-3.5 rounded-xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/80 dark:border-zinc-700/80">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-zinc-500 dark:text-zinc-400 font-medium">Mevcut Durum:</span>
                    <span className="font-bold text-zinc-900 dark:text-white">
                      {currentTier.name}
                    </span>
                  </div>
                  <div className="mt-1 flex items-center gap-1.5 text-xs font-black text-emerald-600 dark:text-emerald-400">
                    <ShieldCheck size={14} className="shrink-0" />
                    <span>{currentTier.benefitText}</span>
                  </div>
                </div>

                {/* Next Upgrade Teaser */}
                {!isMaxLevel && nextTier && (
                  <div className="mt-3 p-3 rounded-xl border border-dashed border-orange-300 dark:border-orange-900/60 bg-orange-50/50 dark:bg-orange-950/20 text-xs">
                    <div className="flex items-center justify-between text-zinc-600 dark:text-zinc-400 font-medium mb-1">
                      <span className="flex items-center gap-1 text-orange-600 dark:text-orange-400 font-bold">
                        <ArrowUpRight size={13} />
                        Sıradaki: Seviye {nextTier.level} ({nextTier.name})
                      </span>
                    </div>
                    <p className="font-bold text-zinc-800 dark:text-zinc-200">
                      {nextTier.benefitText}
                    </p>
                  </div>
                )}
              </div>

              {/* Action Button & Cost */}
              <div className="mt-6 pt-4 border-t border-zinc-100 dark:border-zinc-800">
                {isMaxLevel ? (
                  <button
                    disabled
                    className="w-full py-3 px-4 rounded-xl font-bold text-xs bg-zinc-100 dark:bg-zinc-800 text-zinc-400 dark:text-zinc-500 cursor-default flex items-center justify-center gap-1.5"
                  >
                    <CheckCircle2 size={16} className="text-emerald-500" />
                    Maksimum Seviyeye Ulaşıldı
                  </button>
                ) : nextTier ? (
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center justify-between text-xs px-1">
                      <span className="text-zinc-500 dark:text-zinc-400 font-medium">Geliştirme Ücreti:</span>
                      <span className="font-black text-sm text-zinc-900 dark:text-white">
                        {formatMoney(nextTier.cost)}
                      </span>
                    </div>
                    
                    <button
                      onClick={() => handleBuyUpgrade(category, nextTier)}
                      disabled={!canAfford}
                      className={`w-full py-3 px-4 rounded-xl font-black text-xs flex items-center justify-center gap-2 transition-all active:scale-[0.98] shadow-sm ${
                        canAfford
                          ? 'bg-orange-500 hover:bg-orange-600 text-white shadow-orange-500/20'
                          : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-400 dark:text-zinc-500 cursor-not-allowed border border-zinc-200 dark:border-zinc-700'
                      }`}
                    >
                      <ArrowUpRight size={16} />
                      {canAfford ? 'Seviye Yükselt' : 'Yetersiz Bakiye'}
                    </button>
                  </div>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>

      {/* Upgrade Explanatory Help Card */}
      <div className="bg-zinc-50 dark:bg-zinc-900/60 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-5 sm:p-6 text-xs text-zinc-600 dark:text-zinc-400">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-xl bg-orange-100 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400 shrink-0">
            <Info size={18} />
          </div>
          <div>
            <h4 className="font-bold text-sm text-zinc-900 dark:text-white mb-1">
              Dükkan & Seviye Avantajları Nasıl Çalışır?
            </h4>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2 font-medium">
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-orange-500 shrink-0" />
                <strong>Geniş Otopark:</strong> Vitrininizde aynı anda daha çok araba depolayıp satabilirsiniz.
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
                <strong>Hızlı Tamir Ekibi:</strong> Servisteki saniye sayaçlarını 5 kata kadar hızlandırır.
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-500 shrink-0" />
                <strong>Boya Fırını:</strong> Müşterilerin araçlarınıza verdiği para teklifini %18'e kadar artırır.
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0" />
                <strong>Reklam Ajansı:</strong> Müşteri tekliflerinin gelme sıklığını ve VIP alıcıları artırır.
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
