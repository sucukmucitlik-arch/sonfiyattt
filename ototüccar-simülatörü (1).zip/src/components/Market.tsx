import React, { useState } from 'react';
import { useGame } from '../store/GameContext';
import { CarCard } from './CarCard';
import { CarDetailModal } from './CarDetailModal';
import { BuyBargainModal } from './BuyBargainModal';
import { CategorySelector } from './CategorySelector';
import { MarketCar } from '../types';
import { formatMoney } from '../utils';
import { getMaxGarageCapacity } from '../utils/upgradeUtils';
import { ShoppingCart, AlertCircle, RefreshCw, Search, Layers, X, Filter, Sparkles, Check, CarFront, Handshake } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const Market: React.FC = () => {
  const { state, dispatch } = useGame();
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  
  const upgrades = state.upgrades || {
    parking: 1,
    repair_speed: 1,
    paint_booth: 1,
    marketing: 1,
    mechanic_discount: 1,
  };
  const maxCapacity = getMaxGarageCapacity(upgrades.parking);
  const isGarageFull = state.garage.length >= maxCapacity;

  // Category selection state
  const [selectedBrand, setSelectedBrand] = useState<string | null>(null);
  const [selectedModel, setSelectedModel] = useState<string | null>(null);
  const [selectedEngine, setSelectedEngine] = useState<string | null>(null);
  const [showCategoryModal, setShowCategoryModal] = useState<boolean>(false);

  // Detail Modal state
  const [inspectingCar, setInspectingCar] = useState<MarketCar | null>(null);

  // Bargain Modal state (Alırken Pazarlık Masası)
  const [bargainingCar, setBargainingCar] = useState<MarketCar | null>(null);

  // Other filters
  const [selectedCondition, setSelectedCondition] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'price_asc' | 'price_desc' | 'year_desc' | 'km_asc'>('price_asc');

  const handleBuy = (car: MarketCar) => {
    if (state.money < car.price) {
      setErrorMsg('Yetersiz bakiye! Bu aracı almak için paranız yetmiyor.');
      setTimeout(() => setErrorMsg(null), 3000);
      return;
    }
    if (state.garage.length >= maxCapacity) {
      setErrorMsg(`Galeri otoparkı dolu (${state.garage.length}/${maxCapacity}). 'Dükkan' sekmesinden kapasiteyi artırın veya mevcut araçları satın.`);
      setTimeout(() => setErrorMsg(null), 4000);
      return;
    }
    dispatch({ type: 'BUY_CAR', payload: car });
    setSuccessMsg(`Tebrikler! ${car.brand} ${car.model} galerine eklendi.`);
    if (inspectingCar?.marketId === car.marketId) {
      setInspectingCar(null);
    }
    setTimeout(() => setSuccessMsg(null), 3500);
  };

  const handleConfirmBargainBuy = (car: MarketCar, finalPrice: number, discountAmount: number) => {
    if (state.money < finalPrice) {
      setErrorMsg('Yetersiz bakiye!');
      setTimeout(() => setErrorMsg(null), 3000);
      return;
    }
    if (state.garage.length >= maxCapacity) {
      setErrorMsg(`Galeri otoparkı dolu (${state.garage.length}/${maxCapacity}).`);
      setTimeout(() => setErrorMsg(null), 4000);
      return;
    }
    dispatch({
      type: 'BUY_CAR',
      payload: {
        car,
        customPrice: finalPrice,
        discountAmount,
      },
    });
    setSuccessMsg(
      discountAmount > 0
        ? `Tebrikler! ${car.brand} ${car.model} pazarlıkla ${formatMoney(discountAmount)} indirimle alındı!`
        : `Tebrikler! ${car.brand} ${car.model} galerine eklendi.`
    );
    setBargainingCar(null);
    if (inspectingCar?.marketId === car.marketId) {
      setInspectingCar(null);
    }
    setTimeout(() => setSuccessMsg(null), 3500);
  };

  const handleCategorySelect = (brand: string | null, model: string | null, engine: string | null) => {
    setSelectedBrand(brand);
    setSelectedModel(model);
    setSelectedEngine(engine);
  };

  const resetCategories = () => {
    setSelectedBrand(null);
    setSelectedModel(null);
    setSelectedEngine(null);
  };

  const filteredCars = state.market
    .filter((car) => {
      // Search query
      if (searchQuery && !`${car.brand} ${car.model} ${car.series || ''}`.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
      // Brand filter
      if (selectedBrand && car.brand !== selectedBrand) {
        return false;
      }
      // Model filter
      if (selectedModel && car.model !== selectedModel) {
        return false;
      }
      // Engine filter
      if (selectedEngine && !car.engine.name.includes(selectedEngine)) {
        return false;
      }
      // Condition filter
      if (selectedCondition !== 'all' && car.condition !== selectedCondition) {
        return false;
      }
      return true;
    })
    .sort((a, b) => {
      // Always put tutorial Egea at the top during tutorial
      if (state.tutorialStep === 'buy_egea') {
        const isAEgea = a.marketId === 'tutorial_egea_01' || (a.brand === 'Fiat' && a.model.includes('Egea'));
        const isBEgea = b.marketId === 'tutorial_egea_01' || (b.brand === 'Fiat' && b.model.includes('Egea'));
        if (isAEgea && !isBEgea) return -1;
        if (!isAEgea && isBEgea) return 1;
      }
      if (sortBy === 'price_asc') return a.price - b.price;
      if (sortBy === 'price_desc') return b.price - a.price;
      if (sortBy === 'year_desc') return b.year - a.year;
      if (sortBy === 'km_asc') return a.km - b.km;
      return 0;
    });

  const activeFilterCount = (selectedBrand ? 1 : 0) + (selectedModel ? 1 : 0) + (selectedEngine ? 1 : 0) + (selectedCondition !== 'all' ? 1 : 0);

  const POPULAR_BRANDS = [
    'Tümü',
    'Fiat',
    'Renault',
    'Volkswagen',
    'BMW',
    'Mercedes-Benz',
    'Audi',
    'Toyota',
    'Peugeot',
    'Honda',
    'Ford',
    'Hyundai',
    'Volvo',
    'Porsche',
  ];

  const handleRefreshMarket = () => {
    dispatch({ type: 'REFRESH_MARKET' });
    setSuccessMsg('Piyasa yenilendi! 120+ yeni araç ilanı listelendi.');
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="text-2xl font-black tracking-tight text-zinc-900 dark:text-white">
              İlanlar & Araç Pazarı
            </h2>
            <span className="bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 text-xs font-black px-2.5 py-0.5 rounded-full border border-emerald-300 dark:border-emerald-800 flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              {state.market.length} Araç Yayında
            </span>
          </div>
          <p className="text-sm text-zinc-500 mt-1 font-medium">
            Tüm marka ve modeller 7/24 piyasada hazır. Gün geçmesini beklemeden dilediğin aracı hemen satın alabilir veya yeni ilanlar getirebilirsin.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleRefreshMarket}
            className="flex items-center gap-2 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 active:scale-95 text-zinc-800 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-700 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all shadow-sm"
            title="Piyasadaki tüm araçları ve fiyatları hemen yeniler"
          >
            <RefreshCw size={15} className="text-orange-500" />
            <span>Piyasayı Yenile</span>
          </button>

          <button
            onClick={() => setShowCategoryModal(true)}
            className="flex items-center gap-2 bg-orange-500 hover:bg-orange-600 active:scale-95 text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow-md shadow-orange-500/20 transition-all"
          >
            <Layers size={16} />
            <span>Kategori Seçimi (Marka / Model)</span>
            {selectedBrand && (
              <span className="bg-white text-orange-600 px-1.5 py-0.2 rounded-full text-[10px] font-black">
                {selectedBrand}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Quick Brand Navigation Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-hide">
        {POPULAR_BRANDS.map((brand) => {
          const isSelected = brand === 'Tümü' ? !selectedBrand : selectedBrand === brand;
          return (
            <button
              key={brand}
              onClick={() => {
                if (brand === 'Tümü') {
                  resetCategories();
                } else {
                  setSelectedBrand(brand);
                  setSelectedModel(null);
                  setSelectedEngine(null);
                }
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                isSelected
                  ? 'bg-orange-500 text-white shadow-sm shadow-orange-500/30'
                  : 'bg-white dark:bg-zinc-850 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-800'
              }`}
            >
              {brand}
            </button>
          );
        })}
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-zinc-900 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 flex flex-col md:flex-row gap-3 items-center justify-between shadow-sm">
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
          <input
            type="text"
            placeholder="Marka, model veya motor ara (örn: Egea 1.6 Multijet)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs text-zinc-800 dark:text-zinc-200 focus:outline-none focus:border-orange-500 font-medium transition-colors"
          />
        </div>

        {/* Dropdowns */}
        <div className="flex flex-wrap gap-2 w-full md:w-auto items-center">
          {/* Quick Category Trigger */}
          <button
            onClick={() => setShowCategoryModal(true)}
            className={`px-3 py-2 border rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors ${
              selectedBrand
                ? 'bg-orange-50 dark:bg-orange-950/40 border-orange-300 dark:border-orange-700 text-orange-600 dark:text-orange-400'
                : 'bg-zinc-50 dark:bg-zinc-800/60 border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300'
            }`}
          >
            <Layers size={14} className="text-orange-500" />
            <span>
              {selectedModel
                ? `${selectedBrand} ${selectedModel}`
                : selectedBrand
                ? `${selectedBrand}`
                : 'Tüm Markalar'}
            </span>
          </button>

          {/* Condition Filter */}
          <select
            value={selectedCondition}
            onChange={(e) => setSelectedCondition(e.target.value)}
            className="px-3 py-2 bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs font-semibold text-zinc-700 dark:text-zinc-300 focus:outline-none focus:border-orange-500"
          >
            <option value="all">Tüm Ekspertiz Durumları</option>
            <option value="Temiz">Hatasız / Temiz</option>
            <option value="Boyalı">Boyalı</option>
            <option value="Değişen">Değişenli</option>
            <option value="Ağır Hasarlı">Ağır Hasarlı</option>
          </select>

          {/* Sort By */}
          <select
            value={sortBy}
            onChange={(e: any) => setSortBy(e.target.value)}
            className="px-3 py-2 bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs font-semibold text-zinc-700 dark:text-zinc-300 focus:outline-none focus:border-orange-500"
          >
            <option value="price_asc">Fiyat (En Düşük)</option>
            <option value="price_desc">Fiyat (En Yüksek)</option>
            <option value="year_desc">Model Yılı (En Yeni)</option>
            <option value="km_asc">Kilometre (En Düşük)</option>
          </select>

          {/* Reset Filters button */}
          {activeFilterCount > 0 && (
            <button
              onClick={() => {
                resetCategories();
                setSelectedCondition('all');
                setSearchQuery('');
              }}
              className="px-2.5 py-2 text-xs font-semibold text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-xl transition-colors flex items-center gap-1"
              title="Filtreleri Temizle"
            >
              <X size={14} /> Temizle
            </button>
          )}
        </div>
      </div>

      {/* Active Breadcrumb / Filter chips */}
      {selectedBrand && (
        <div className="flex items-center flex-wrap gap-2 px-1">
          <span className="text-xs font-semibold text-zinc-400">Aktif Kategori:</span>
          <div className="flex items-center gap-1.5 bg-orange-100 dark:bg-orange-950/60 border border-orange-300 dark:border-orange-800 text-orange-800 dark:text-orange-300 px-3 py-1 rounded-full text-xs font-bold">
            <span>{selectedBrand}</span>
            {selectedModel && <span>› {selectedModel}</span>}
            {selectedEngine && <span>› {selectedEngine}</span>}
            <button
              onClick={resetCategories}
              className="ml-1 hover:bg-orange-200 dark:hover:bg-orange-900 rounded-full p-0.5"
            >
              <X size={12} />
            </button>
          </div>
          <span className="text-xs text-zinc-500">
            ({filteredCars.length} ilan listeleniyor)
          </span>
        </div>
      )}

      {/* Error & Success Messages */}
      <AnimatePresence>
        {errorMsg && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 p-4 rounded-xl flex items-center gap-3 border border-red-200 dark:border-red-900/50 text-sm font-semibold"
          >
            <AlertCircle size={20} />
            <span>{errorMsg}</span>
          </motion.div>
        )}
        {successMsg && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 p-4 rounded-xl flex items-center gap-3 border border-emerald-200 dark:border-emerald-900/50 text-sm font-semibold"
          >
            <Check size={20} />
            <span>{successMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Cars Grid */}
      {state.market.length === 0 ? (
        <div className="text-center py-20 bg-white dark:bg-zinc-900 rounded-2xl border border-dashed border-zinc-200 dark:border-zinc-800 p-8">
          <RefreshCw size={40} className="mx-auto text-zinc-300 dark:text-zinc-700 mb-4 animate-spin-slow" />
          <p className="text-zinc-500 font-medium">Piyasada şu an hiç ilan kalmadı. "Sonraki Gün" diyerek yeni ilanları getirebilirsiniz.</p>
        </div>
      ) : filteredCars.length === 0 ? (
        <div className="text-center py-16 bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 text-zinc-500 text-sm font-medium space-y-3">
          <p>Arama ve kategori kriterlerinize uygun araç bulunamadı.</p>
          <button
            onClick={() => {
              resetCategories();
              setSelectedCondition('all');
              setSearchQuery('');
            }}
            className="px-4 py-2 bg-orange-500 text-white font-bold rounded-xl text-xs hover:bg-orange-600 transition-colors"
          >
            Tüm İlanları Göster
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredCars.map((car) => {
            const isTutorialTarget = state.tutorialStep === 'buy_egea' && 
              (car.marketId === 'tutorial_egea_01' || (car.brand === 'Fiat' && car.model.includes('Egea')));

            return (
              <CarCard 
                key={car.marketId} 
                car={car} 
                isHighlighted={isTutorialTarget}
                highlightBadge={isTutorialTarget ? "👉 1. ADIM: BU ARACI SATIN AL" : undefined}
                onInspect={() => setInspectingCar(car)}
                actionButton={
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setInspectingCar(car)}
                      className="py-2.5 px-2.5 rounded-xl font-bold text-xs bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 transition-colors"
                      title="Ekspertiz ve İlan Detayı"
                    >
                      İncele
                    </button>
                    <button
                      onClick={() => setBargainingCar(car)}
                      className="py-2.5 px-2.5 rounded-xl font-black text-xs bg-amber-500 hover:bg-amber-600 text-white transition-all shadow-xs flex items-center justify-center gap-1 flex-shrink-0"
                      title="Satıcıyla Pazarlık Yap"
                    >
                      <Handshake size={14} />
                      <span>Pazarlık</span>
                    </button>
                    <button
                      onClick={() => handleBuy(car)}
                      disabled={state.money < car.price || isGarageFull}
                      className={`flex-grow py-2.5 px-2.5 rounded-xl font-black text-xs flex items-center justify-center gap-1 transition-all active:scale-[0.98] shadow-sm
                        ${isGarageFull
                          ? 'bg-zinc-100 dark:bg-zinc-800 text-zinc-400 cursor-not-allowed border border-zinc-200 dark:border-zinc-700'
                          : isTutorialTarget
                            ? 'bg-orange-500 hover:bg-orange-600 text-white shadow-lg shadow-orange-500/40 ring-2 ring-white animate-pulse'
                            : state.money >= car.price 
                              ? 'bg-orange-500 hover:bg-orange-600 text-white shadow-orange-500/20' 
                              : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-400 cursor-not-allowed border border-zinc-200 dark:border-zinc-700'
                        }`}
                    >
                      <ShoppingCart size={14} />
                      <span>{isGarageFull ? 'Dolu' : state.money >= car.price ? 'Satın Al' : 'Yetersiz'}</span>
                    </button>
                  </div>
                }
              />
            );
          })}
        </div>
      )}

      {/* Category Selection Modal */}
      {showCategoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-lg">
            <CategorySelector
              marketCars={state.market}
              selectedBrand={selectedBrand}
              selectedModel={selectedModel}
              selectedEngine={selectedEngine}
              onSelectCategory={(brand, model, engine) => {
                handleCategorySelect(brand, model, engine);
              }}
              onClose={() => setShowCategoryModal(false)}
            />
          </div>
        </div>
      )}

      {/* Car Detail Modal (Resim 3 Sahibinden İlan Detayı & Ekspertiz Raporu) */}
      <CarDetailModal
        car={inspectingCar}
        isOpen={!!inspectingCar}
        onClose={() => setInspectingCar(null)}
        onStartBargain={inspectingCar ? () => setBargainingCar(inspectingCar) : undefined}
        actionButton={
          inspectingCar && (
            <button
              onClick={() => handleBuy(inspectingCar)}
              disabled={state.money < inspectingCar.price}
              className={`px-5 py-2.5 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all active:scale-[0.98] shadow-md
                ${state.money >= inspectingCar.price 
                  ? 'bg-orange-500 hover:bg-orange-600 text-white shadow-orange-500/25' 
                  : 'bg-zinc-200 dark:bg-zinc-700 text-zinc-400 cursor-not-allowed'
                }`}
            >
              <ShoppingCart size={16} />
              {state.money >= inspectingCar.price ? 'Hemen Galerine Satın Al' : 'Bakiye Yetersiz'}
            </button>
          )
        }
      />

      {/* Alırken Satıcı ile Pazarlık Masası Modal */}
      <BuyBargainModal
        car={bargainingCar}
        isOpen={!!bargainingCar}
        onClose={() => setBargainingCar(null)}
        onConfirmBuy={handleConfirmBargainBuy}
        playerMoney={state.money}
        playerReputation={state.reputation}
      />
    </div>
  );
};
