import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TradeReport } from '../types';
import { formatMoney, normalizeImageUrl } from '../utils';
import { 
  X, 
  Award, 
  TrendingUp, 
  TrendingDown, 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles, 
  Star, 
  ArrowRight,
  ShieldCheck,
  Zap,
  ShoppingBag,
  Coins,
  BadgeCheck,
  CarFront
} from 'lucide-react';

interface TradeResultModalProps {
  report: TradeReport | null;
  onClose: () => void;
  onNavigateToGarage?: () => void;
  onNavigateToOffers?: () => void;
}

export const TradeResultModal: React.FC<TradeResultModalProps> = ({
  report,
  onClose,
  onNavigateToGarage,
  onNavigateToOffers,
}) => {
  if (!report) return null;

  const isBuy = report.type === 'buy';
  const isGradeA = report.grade === 'A';
  const isGradeB = report.grade === 'B';
  const isGradeC = report.grade === 'C';
  const isGradeD = report.grade === 'D';

  const getGradeTheme = () => {
    switch (report.grade) {
      case 'A':
        return {
          bgGradient: 'from-emerald-500/20 via-emerald-500/5 to-transparent',
          borderClass: 'border-emerald-500/40',
          badgeBg: 'bg-emerald-500 text-white',
          glowShadow: 'shadow-emerald-500/30',
          textColor: 'text-emerald-600 dark:text-emerald-400',
          icon: '🔥',
          bannerText: isBuy ? 'FIRSAT YAKALANDI!' : 'REKOR KÂR ELDE EDİLDİ!',
          bannerBg: 'bg-emerald-600 text-white',
        };
      case 'B':
        return {
          bgGradient: 'from-sky-500/20 via-sky-500/5 to-transparent',
          borderClass: 'border-sky-500/40',
          badgeBg: 'bg-sky-500 text-white',
          glowShadow: 'shadow-sky-500/30',
          textColor: 'text-sky-600 dark:text-sky-400',
          icon: '✅',
          bannerText: isBuy ? 'UYGUN FİYATLI ALIM' : 'BAŞARILI TEMİZ SATIŞ',
          bannerBg: 'bg-sky-600 text-white',
        };
      case 'C':
        return {
          bgGradient: 'from-amber-500/20 via-amber-500/5 to-transparent',
          borderClass: 'border-amber-500/40',
          badgeBg: 'bg-amber-500 text-white',
          glowShadow: 'shadow-amber-500/30',
          textColor: 'text-amber-600 dark:text-amber-400',
          icon: '⚖️',
          bannerText: isBuy ? 'STANDART PİYASA ALIMI' : 'MAKUL HIZLI SATIŞ',
          bannerBg: 'bg-amber-600 text-white',
        };
      case 'D':
      default:
        return {
          bgGradient: 'from-rose-500/20 via-rose-500/5 to-transparent',
          borderClass: 'border-rose-500/40',
          badgeBg: 'bg-rose-500 text-white',
          glowShadow: 'shadow-rose-500/30',
          textColor: 'text-rose-600 dark:text-rose-400',
          icon: '⚠️',
          bannerText: isBuy ? 'PAHALIYA ALINDI' : 'ZARARINA / DÜŞÜK KÂR',
          bannerBg: 'bg-rose-600 text-white',
        };
    }
  };

  const theme = getGradeTheme();

  return (
    <AnimatePresence>
      <div 
        id="trade-result-modal-backdrop"
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md overflow-y-auto"
      >
        <motion.div
          id="trade-result-modal-container"
          initial={{ opacity: 0, scale: 0.88, y: 25 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 350 }}
          className={`relative w-full max-w-lg bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border ${theme.borderClass} overflow-hidden my-auto`}
        >
          {/* Top Status Header Ribbon */}
          <div className={`${theme.bannerBg} px-4 py-2 text-center text-xs font-black tracking-widest uppercase flex items-center justify-center gap-2 shadow-sm`}>
            <Sparkles size={14} className="fill-white" />
            <span>{isBuy ? '🛍️ ALIŞ DEĞERLENDİRMESİ' : '💰 SATIŞ VE KÂR RAPORU'} • {theme.bannerText}</span>
            <Sparkles size={14} className="fill-white" />
          </div>

          <div className={`p-6 sm:p-7 bg-gradient-to-b ${theme.bgGradient} relative`}>
            {/* Close Button */}
            <button
              id="trade-result-close-btn"
              onClick={onClose}
              className="absolute top-4 right-4 p-2 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
            >
              <X size={20} />
            </button>

            {/* Giant Grade Stamp */}
            <div className="flex flex-col items-center text-center mt-2 mb-6">
              <motion.div
                initial={{ scale: 0, rotate: -25 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: 'spring', damping: 15, stiffness: 260, delay: 0.1 }}
                className={`relative w-24 h-24 rounded-3xl ${theme.badgeBg} flex flex-col items-center justify-center shadow-xl ${theme.glowShadow} border-4 border-white dark:border-zinc-800 mb-3`}
              >
                <span className="text-4xl font-black tracking-tighter leading-none">{report.grade}</span>
                <span className="text-[10px] font-black uppercase tracking-wider mt-0.5 opacity-90">NOTU</span>

                {/* Corner Star/Icon */}
                <div className="absolute -top-2 -right-2 w-7 h-7 bg-white dark:bg-zinc-800 rounded-full flex items-center justify-center text-sm shadow-md">
                  {theme.icon}
                </div>
              </motion.div>

              {/* Star Rating */}
              <div className="flex items-center gap-1 mb-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    size={16}
                    className={star <= report.stars ? 'text-amber-400 fill-amber-400' : 'text-zinc-300 dark:text-zinc-700'}
                  />
                ))}
              </div>

              <h2 className="text-xl sm:text-2xl font-black text-zinc-900 dark:text-white tracking-tight">
                {report.title}
              </h2>

              <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-300 font-medium max-w-sm mt-1.5 leading-relaxed">
                {report.description}
              </p>
            </div>

            {/* Vehicle Info Strip */}
            <div className="bg-white/80 dark:bg-zinc-850/80 backdrop-blur-sm rounded-2xl p-3.5 border border-zinc-200/80 dark:border-zinc-700/80 flex items-center gap-3.5 mb-5 shadow-xs">
              <img
                src={normalizeImageUrl(report.carImage)}
                alt={report.carModel}
                className="w-16 h-12 object-cover rounded-xl border border-zinc-200 dark:border-zinc-700 flex-shrink-0"
              />
              <div className="min-w-0 flex-1">
                <div className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
                  {report.carYear} Modeli
                </div>
                <h4 className="text-sm font-black text-zinc-900 dark:text-white truncate">
                  {report.carBrand} {report.carModel}
                </h4>
                <div className="text-[11px] text-zinc-500 font-medium mt-0.5 truncate flex items-center gap-1">
                  <span>{isBuy ? 'Satıcı:' : 'Alıcı:'}</span>
                  <span className="font-bold text-zinc-700 dark:text-zinc-300">
                    {report.partnerAvatar} {report.partnerName}
                  </span>
                </div>
              </div>
            </div>

            {/* Stats Metric Cards Grid */}
            <div className="grid grid-cols-2 gap-3 mb-5">
              {isBuy ? (
                <>
                  {/* Buy Stats: Paid vs FMV */}
                  <div className="bg-zinc-50 dark:bg-zinc-800/60 rounded-xl p-3 border border-zinc-200 dark:border-zinc-700/60">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">
                      Ödenen Alış Fiyatı
                    </span>
                    <span className="text-base sm:text-lg font-black text-zinc-900 dark:text-white">
                      {formatMoney(report.price)}
                    </span>
                    {report.discountAmount && report.discountAmount > 0 ? (
                      <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 block mt-0.5">
                        🎉 {formatMoney(report.discountAmount)} Pazarlık İndirimi
                      </span>
                    ) : null}
                  </div>

                  <div className="bg-zinc-50 dark:bg-zinc-800/60 rounded-xl p-3 border border-zinc-200 dark:border-zinc-700/60">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">
                      Tahmini Piyasa Değeri
                    </span>
                    <span className="text-base sm:text-lg font-black text-zinc-900 dark:text-white">
                      {formatMoney(report.referenceValue)}
                    </span>
                    <div className="flex items-center gap-1 mt-0.5">
                      {report.diffPercentage <= 0 ? (
                        <span className="text-[10px] font-black text-emerald-600 dark:text-emerald-400 flex items-center gap-0.5">
                          <TrendingDown size={11} /> %{Math.abs(report.diffPercentage)} Kelepir
                        </span>
                      ) : (
                        <span className="text-[10px] font-black text-rose-500 flex items-center gap-0.5">
                          <TrendingUp size={11} /> +%{report.diffPercentage} Piyasa Üstü
                        </span>
                      )}
                    </div>
                  </div>
                </>
              ) : (
                <>
                  {/* Sell Stats: Sold Price vs Total Cost -> Profit */}
                  <div className="bg-zinc-50 dark:bg-zinc-800/60 rounded-xl p-3 border border-zinc-200 dark:border-zinc-700/60">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">
                      Satış Fiyatı
                    </span>
                    <span className="text-base sm:text-lg font-black text-zinc-900 dark:text-white">
                      {formatMoney(report.price)}
                    </span>
                    <span className="text-[10px] font-medium text-zinc-500 block mt-0.5">
                      Maliyet: {formatMoney(report.referenceValue)}
                    </span>
                  </div>

                  <div className={`rounded-xl p-3 border ${report.diffAmount >= 0 ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800' : 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800'}`}>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">
                      Net Kâr / Zarar
                    </span>
                    <span className={`text-base sm:text-lg font-black ${report.diffAmount >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
                      {report.diffAmount >= 0 ? `+${formatMoney(report.diffAmount)}` : `-${formatMoney(Math.abs(report.diffAmount))}`}
                    </span>
                    <span className={`text-[10px] font-black block mt-0.5 ${report.diffAmount >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-500'}`}>
                      {report.diffAmount >= 0 ? `📈 %${report.diffPercentage} Kâr Marjı` : `📉 %${report.diffPercentage} Zarar`}
                    </span>
                  </div>
                </>
              )}
            </div>

            {/* Advice / Expert Commentary Box */}
            <div className="p-3.5 rounded-xl bg-orange-50/70 dark:bg-zinc-800/80 border border-orange-200/80 dark:border-zinc-700/80 mb-6">
              <div className="flex items-center gap-1.5 text-xs font-black text-orange-600 dark:text-orange-400 uppercase tracking-wider mb-1">
                <BadgeCheck size={14} />
                <span>Usta Esnaf Değerlendirmesi:</span>
              </div>
              <p className="text-xs text-zinc-700 dark:text-zinc-300 font-medium leading-relaxed">
                "{report.advice}"
              </p>
            </div>

            {/* Bottom Actions */}
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                id="trade-result-confirm-btn"
                onClick={onClose}
                className="flex-1 py-3 px-4 bg-zinc-900 hover:bg-black dark:bg-white dark:hover:bg-zinc-100 text-white dark:text-zinc-900 rounded-xl font-black text-sm transition-all shadow-md flex items-center justify-center gap-2"
              >
                <span>Tamam, Anlaşıldı</span>
                <CheckCircle2 size={16} />
              </button>

              {isBuy && onNavigateToGarage && (
                <button
                  id="trade-result-garage-btn"
                  onClick={() => {
                    onClose();
                    onNavigateToGarage();
                  }}
                  className="py-3 px-4 bg-orange-500 hover:bg-orange-600 text-white rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-1.5 shadow-md shadow-orange-500/20"
                >
                  <CarFront size={16} />
                  <span>Garaja Git</span>
                </button>
              )}

              {!isBuy && onNavigateToOffers && (
                <button
                  id="trade-result-offers-btn"
                  onClick={() => {
                    onClose();
                    onNavigateToOffers();
                  }}
                  className="py-3 px-4 bg-orange-500 hover:bg-orange-600 text-white rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-1.5 shadow-md shadow-orange-500/20"
                >
                  <Coins size={16} />
                  <span>Diğer Tekliflere Bak</span>
                </button>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
