import React, { useState } from 'react';
import { useGame } from '../store/GameContext';
import { OfferCard } from './OfferCard';
import { BuyerType } from '../types';
import { MessageSquare, Filter, Clock, Sparkles, Store, Calendar, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { generateFullMarketCatalog } from '../utils';

export const OffersView: React.FC = () => {
  const { state, dispatch } = useGame();
  const [filterType, setFilterType] = useState<string>('all');
  const [selectedCarFilter, setSelectedCarFilter] = useState<string>('all');

  const filteredOffers = state.offers.filter(offer => {
    if (filterType !== 'all' && offer.buyerType !== filterType) return false;
    if (selectedCarFilter !== 'all' && offer.carMarketId !== selectedCarFilter) return false;
    return true;
  });

  const handleNextDay = () => {
    dispatch({ type: 'NEXT_DAY', payload: { newMarket: generateFullMarketCatalog(), newOffers: [] } });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-black tracking-tight text-zinc-900 dark:text-white">
              Gelen Müşteri Teklifleri
            </h2>
            {state.offers.length > 0 && (
              <span className="bg-orange-500 text-white text-xs font-black px-2.5 py-1 rounded-full shadow-sm">
                {state.offers.length} Aktif Teklif
              </span>
            )}
          </div>
          <p className="text-sm text-zinc-500 mt-1 font-medium">
            Galerinizdeki araçlara alıcılardan gelen teklifleri inceleyin, "Son Fiyatım Bu" diyerek pazarlık yapın veya doğrudan satın.
          </p>
        </div>

        {/* Action to advance day if waiting for buyers */}
        <button
          onClick={handleNextDay}
          className="flex items-center gap-2 text-xs font-bold bg-orange-50 hover:bg-orange-100 dark:bg-orange-950/40 dark:hover:bg-orange-900/40 text-orange-600 dark:text-orange-400 px-3.5 py-2.5 rounded-xl border border-orange-200 dark:border-orange-800 transition-colors"
        >
          <Calendar size={14} className="text-orange-500" />
          Sonraki Güne Geç & Yeni Teklifler Al
        </button>
      </div>

      {/* Filters Bar */}
      {state.offers.length > 0 && (
        <div className="flex flex-wrap gap-2 items-center bg-white dark:bg-zinc-900 p-3 rounded-xl border border-zinc-200 dark:border-zinc-800">
          <span className="text-xs font-bold text-zinc-400 flex items-center gap-1 mr-2">
            <Filter size={13} /> Filtrele:
          </span>

          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
              filterType === 'all'
                ? 'bg-orange-500 text-white'
                : 'text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800'
            }`}
          >
            Tümü ({state.offers.length})
          </button>

          {['Bireysel Alıcı', 'Galeri Esnafı', 'Acele Alıcı', 'Koleksiyoner'].map(type => {
            const count = state.offers.filter(o => o.buyerType === type).length;
            if (count === 0) return null;
            return (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                  filterType === type
                    ? 'bg-orange-500 text-white'
                    : 'text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                }`}
              >
                {type} ({count})
              </button>
            );
          })}
        </div>
      )}

      {/* Offers Grid or Empty state */}
      {state.offers.length === 0 ? (
        <div className="text-center py-20 bg-white dark:bg-zinc-900 rounded-2xl border border-dashed border-zinc-200 dark:border-zinc-800 p-8 flex flex-col items-center">
          <div className="w-16 h-16 bg-orange-50 dark:bg-zinc-800 rounded-2xl flex items-center justify-center mb-4 text-orange-500">
            <Clock size={32} />
          </div>
          <h3 className="text-lg font-bold text-zinc-900 dark:text-white mb-2">
            Şu Anda Bekleyen Teklif Yok
          </h3>
          <p className="text-zinc-500 font-medium max-w-md text-sm mb-6 leading-relaxed">
            {state.garage.length === 0
              ? 'Galerinizde henüz hiç araç yok. Piyasa ilanlarından araç satın alarak müşterilerin teklif vermesini sağlayabilirsiniz.'
              : 'Galerinizdeki araçlar vitrinde sergileniyor. Zaman geçtikçe veya "Sonraki Gün" butonuna basarak yeni müşterilerin tekliflerini alabilirsiniz.'}
          </p>

          <div className="flex gap-3">
            {state.garage.length === 0 ? (
              <div className="text-xs font-bold text-zinc-400">
                👉 Piyasa İlanları sekmesine gidip ilk aracınızı satın alın.
              </div>
            ) : (
              <button
                onClick={handleNextDay}
                className="py-2.5 px-5 bg-orange-500 hover:bg-orange-600 text-white rounded-xl font-bold text-sm transition-all flex items-center gap-2 shadow-md shadow-orange-500/20"
              >
                <Calendar size={16} />
                Sonraki Güne Geç (Günün Tekliflerini Getir)
              </button>
            )}
          </div>
        </div>
      ) : filteredOffers.length === 0 ? (
        <div className="text-center py-12 bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800 text-zinc-500 text-sm">
          Seçilen filtre kriterlerine uygun teklif bulunamadı.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredOffers.map(offer => (
            <OfferCard key={offer.id} offer={offer} />
          ))}
        </div>
      )}
    </div>
  );
};
