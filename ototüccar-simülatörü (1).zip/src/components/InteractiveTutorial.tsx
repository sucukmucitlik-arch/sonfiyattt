import React, { useState } from 'react';
import { useGame } from '../store/GameContext';
import { formatMoney } from '../utils';
import { 
  Building2, 
  Car, 
  Wrench, 
  Handshake, 
  TrendingUp, 
  CheckCircle2, 
  Sparkles, 
  ChevronRight, 
  X, 
  AlertTriangle, 
  ShieldCheck, 
  Award, 
  HelpCircle,
  Pencil,
  ArrowRight,
  Flame,
  Gift,
  Play,
  RotateCcw,
  Zap,
  Check
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TutorialStep } from '../types';

interface InteractiveTutorialProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateTab?: (tab: 'market' | 'garage' | 'offers' | 'collection' | 'shop' | 'achievements') => void;
}

export const InteractiveTutorial: React.FC<InteractiveTutorialProps> = ({ 
  isOpen, 
  onClose,
  onNavigateTab
}) => {
  const { state, dispatch } = useGame();

  // Gallery Name Edit in Academy Modal
  const [dealerNameInput, setDealerNameInput] = useState<string>(state.galleryName || 'Son Fiyat Motors');
  const [selectedBadge, setSelectedBadge] = useState<string>('🏎️');

  const tutorialStep: TutorialStep = state.tutorialStep || 'idle';
  const isLiveTutorialActive = tutorialStep !== 'idle';

  const handleStartLiveTutorial = () => {
    if (dealerNameInput.trim()) {
      dispatch({ type: 'SET_GALLERY_NAME', payload: dealerNameInput.trim() });
    }
    dispatch({ type: 'START_INTERACTIVE_TUTORIAL' });
    if (onNavigateTab) onNavigateTab('market');
    onClose();
  };

  const handleSkipTutorial = () => {
    dispatch({ type: 'SKIP_TUTORIAL' });
  };

  const handleClaimBonusAndFinish = () => {
    dispatch({ type: 'ADD_MONEY', payload: 50000 });
    dispatch({ type: 'COMPLETE_TUTORIAL' });
  };

  const handleSaveDealerName = () => {
    if (dealerNameInput.trim()) {
      dispatch({ type: 'SET_GALLERY_NAME', payload: dealerNameInput.trim() });
    }
  };

  return (
    <>
      {/* 1. FLOATING LIVE TUTORIAL HUD (Visible during gameplay) */}
      <AnimatePresence>
        {isLiveTutorialActive && tutorialStep !== 'completed' && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.98 }}
            className="fixed top-16 sm:top-20 left-1/2 -translate-x-1/2 z-50 w-[95%] max-w-3xl pointer-events-auto"
          >
            <div className="bg-zinc-900/95 backdrop-blur-xl border-2 border-orange-500 text-white rounded-2xl p-3.5 sm:p-4 shadow-2xl shadow-orange-500/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 relative overflow-hidden">
              {/* Background glowing sweep */}
              <div className="absolute top-0 right-0 w-48 h-48 bg-orange-500/15 rounded-full blur-3xl pointer-events-none" />

              <div className="flex items-center gap-3 relative z-10">
                <div className="w-10 h-10 rounded-xl bg-orange-500 text-white flex items-center justify-center font-black shadow-lg shadow-orange-500/30 flex-shrink-0 animate-pulse">
                  {tutorialStep === 'buy_egea' && <Car size={20} />}
                  {tutorialStep === 'go_garage' && <Building2 size={20} />}
                  {tutorialStep === 'repair_egea' && <Wrench size={20} />}
                  {tutorialStep === 'go_offers' && <Flame size={20} />}
                  {tutorialStep === 'bargain_egea' && <Handshake size={20} />}
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <span className="bg-orange-500 text-white text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wider">
                      {tutorialStep === 'buy_egea' && 'ADIM 1 / 5'}
                      {tutorialStep === 'go_garage' && 'ADIM 2 / 5'}
                      {tutorialStep === 'repair_egea' && 'ADIM 3 / 5'}
                      {tutorialStep === 'go_offers' && 'ADIM 4 / 5'}
                      {tutorialStep === 'bargain_egea' && 'ADIM 5 / 5'}
                    </span>
                    <span className="text-xs font-bold text-orange-400">
                      Canlı Galeri Rehberi
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm font-semibold text-zinc-200 mt-0.5">
                    {tutorialStep === 'buy_egea' && (
                      <span>
                        Piyasadaki parlayan <strong className="text-white underline decoration-orange-500">Fiat Egea</strong> ilanını bul ve <strong className="text-orange-400">"Satın Al"</strong> butonuna tıkla!
                      </span>
                    )}
                    {tutorialStep === 'go_garage' && (
                      <span>
                        Tebrikler! Fiat Egea galerine eklendi. Şimdi üst menüden <strong className="text-orange-400">"Garaj"</strong> sekmesine tıkla.
                      </span>
                    )}
                    {tutorialStep === 'repair_egea' && (
                      <span>
                        Aracın kondisyonunu ve değerini artırmak için Egea kartındaki <strong className="text-orange-400">"Bakım Yap / Onar"</strong> butonuna tıkla!
                      </span>
                    )}
                    {tutorialStep === 'go_offers' && (
                      <span>
                        Müşteri Geldi! 🔔 Ahmet Bey Egea için 710.000 ₺ teklif etti. Üst menüden <strong className="text-orange-400">"Teklifler"</strong> sekmesine tıkla!
                      </span>
                    )}
                    {tutorialStep === 'bargain_egea' && (
                      <span>
                        Ahmet Bey'in teklifinde <strong className="text-orange-400">"Pazarlık Yap (Son Fiyat)"</strong> butonuna bas, karşı teklif ver ve satışı tamamla!
                      </span>
                    )}
                  </p>
                </div>
              </div>

              {/* Action buttons on the HUD */}
              <div className="flex items-center gap-2 self-end sm:self-center relative z-10">
                {tutorialStep === 'go_garage' && onNavigateTab && (
                  <button
                    onClick={() => {
                      onNavigateTab('garage');
                      dispatch({ type: 'SET_TUTORIAL_STEP', payload: 'repair_egea' });
                    }}
                    className="bg-orange-500 hover:bg-orange-600 text-white text-xs font-black px-3 py-1.5 rounded-xl shadow-md transition-all flex items-center gap-1 active:scale-95"
                  >
                    <span>Garaja Git</span>
                    <ArrowRight size={13} />
                  </button>
                )}

                {tutorialStep === 'go_offers' && onNavigateTab && (
                  <button
                    onClick={() => {
                      onNavigateTab('offers');
                      dispatch({ type: 'SET_TUTORIAL_STEP', payload: 'bargain_egea' });
                    }}
                    className="bg-orange-500 hover:bg-orange-600 text-white text-xs font-black px-3 py-1.5 rounded-xl shadow-md transition-all flex items-center gap-1 active:scale-95"
                  >
                    <span>Tekliflere Git</span>
                    <ArrowRight size={13} />
                  </button>
                )}

                <button
                  onClick={handleSkipTutorial}
                  className="text-zinc-400 hover:text-white hover:bg-zinc-800 text-[11px] font-bold px-2.5 py-1.5 rounded-lg transition-colors"
                  title="Öğreticiyi Kapat"
                >
                  Atla (✕)
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. CELEBRATION VICTORY MODAL (Step 6 / Completed) */}
      <AnimatePresence>
        {tutorialStep === 'completed' && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-zinc-900 border-2 border-emerald-500 text-white rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl relative overflow-hidden text-center"
            >
              <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/20 blur-3xl pointer-events-none" />

              <div className="w-20 h-20 bg-gradient-to-tr from-emerald-500 to-teal-400 rounded-3xl mx-auto flex items-center justify-center text-4xl shadow-xl shadow-emerald-500/30 mb-4 animate-bounce">
                🏆
              </div>

              <span className="bg-emerald-500/20 text-emerald-400 text-xs font-black px-3 py-1 rounded-full border border-emerald-500/30 uppercase tracking-widest">
                ÖĞRETİCİ MEZUNİYETİ
              </span>

              <h3 className="text-2xl sm:text-3xl font-black mt-2 text-white">
                Tebrikler, İlk Ticaret Tamam!
              </h3>

              <p className="text-sm text-zinc-300 mt-2 leading-relaxed">
                Piyasadan <strong className="text-white">Fiat Egea</strong>'yı satın aldınız, bakımını yapıp kondisyonunu yükselttiniz ve <strong className="text-white">Ahmet Bey</strong> ile pazarlık yaparak karlı şekilde sattınız!
              </p>

              {/* Bonus Card */}
              <div className="bg-emerald-950/40 border border-emerald-500/40 rounded-2xl p-4 my-5 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 text-left">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold">
                    <Gift size={22} />
                  </div>
                  <div>
                    <div className="text-xs font-black text-emerald-400 uppercase">
                      Kuruluş Hibe Desteği
                    </div>
                    <div className="text-lg font-black text-white">
                      +50.000 ₺ Nakit
                    </div>
                  </div>
                </div>

                <div className="text-xs text-emerald-300 font-bold bg-emerald-500/20 px-2.5 py-1 rounded-lg">
                  Kazanıldı
                </div>
              </div>

              <button
                onClick={handleClaimBonusAndFinish}
                className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-black py-4 px-6 rounded-2xl text-base shadow-xl shadow-emerald-500/30 transition-all flex items-center justify-center gap-2 active:scale-95"
              >
                <Sparkles size={18} />
                <span>+50.000 ₺ Hibeyi Al & Serbest Ticarete Başla</span>
                <ArrowRight size={18} />
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 3. ACADEMY & RESTART MODAL (When clicked from top header "Öğretici" button) */}
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 10 }}
              className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl relative"
            >
              {/* Header */}
              <div className="p-5 sm:p-6 bg-zinc-900 text-white flex items-center justify-between border-b border-zinc-800">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-orange-500 to-amber-500 flex items-center justify-center text-white text-xl font-black shadow-lg shadow-orange-500/20">
                    🎓
                  </div>
                  <div>
                    <h2 className="text-lg font-black tracking-tight flex items-center gap-2">
                      Galeri Akademisi & Öğretici
                    </h2>
                    <p className="text-xs text-zinc-400">
                      Oto galerini yönet, araba al, ekspertiz yap, bakım yap ve pazarlıkla sat!
                    </p>
                  </div>
                </div>

                <button 
                  onClick={onClose}
                  className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-xl transition-colors"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Body */}
              <div className="p-5 sm:p-6 overflow-y-auto space-y-5">
                {/* Gallery Name Customizer */}
                <div className="bg-orange-50 dark:bg-zinc-800/80 border border-orange-200/60 dark:border-zinc-700 p-4 rounded-2xl">
                  <label className="block text-xs font-black text-zinc-700 dark:text-zinc-300 uppercase tracking-wider mb-2">
                    Galeri Tabelası & Markan
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      maxLength={32}
                      value={dealerNameInput}
                      onChange={(e) => setDealerNameInput(e.target.value)}
                      placeholder="Galeri adınızı yazın..."
                      className="flex-grow bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 rounded-xl px-3.5 py-2 text-sm font-bold text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                    />
                    <button
                      onClick={handleSaveDealerName}
                      className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-xl text-xs font-black transition-all shadow-sm"
                    >
                      Kaydet
                    </button>
                  </div>
                </div>

                {/* Big Action: Start Live In-Game Interactive Walkthrough */}
                <div className="bg-gradient-to-r from-orange-500/10 via-amber-500/10 to-orange-500/10 border-2 border-orange-500/30 rounded-2xl p-5 text-center">
                  <span className="inline-block bg-orange-500 text-white text-[10px] font-black uppercase px-2.5 py-1 rounded-full mb-2">
                    ETKİLEŞİMLİ DENEYİM
                  </span>
                  <h3 className="text-lg font-black text-zinc-900 dark:text-white">
                    Canlı Fiat Egea Alım-Satım Rehberi
                  </h3>
                  <p className="text-xs text-zinc-600 dark:text-zinc-400 mt-1 max-w-md mx-auto">
                    Oyunun arayüzünde canlı yönlendirmelerle piyasadan Fiat Egea alın, serviste bakım yaptırın, müşteri teklifini değerlendirip pazarlık yapın!
                  </p>
                  
                  <button
                    onClick={handleStartLiveTutorial}
                    className="mt-4 inline-flex items-center gap-2 bg-orange-500 hover:bg-orange-600 text-white font-black px-6 py-3 rounded-xl text-sm shadow-lg shadow-orange-500/30 transition-all active:scale-95"
                  >
                    <Play size={16} className="fill-white" />
                    <span>Canlı Öğreticiyi Başlat (Fiat Egea)</span>
                  </button>
                </div>

                {/* Quick Step Guide Summary */}
                <div className="space-y-3">
                  <h4 className="text-xs font-black uppercase tracking-wider text-zinc-400">
                    5 Adımda Galericilik Rehberi
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-800 p-3.5 rounded-2xl flex items-start gap-3">
                      <div className="w-8 h-8 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center font-black flex-shrink-0 text-sm">
                        1
                      </div>
                      <div>
                        <div className="text-xs font-black text-zinc-900 dark:text-white">
                          Piyasayı İncele & Araç Al
                        </div>
                        <div className="text-[11px] text-zinc-500 mt-0.5">
                          Ekspertiz raporlarına, tramer kaydına ve km'sine bakarak uygun fiyatlı araçları kap.
                        </div>
                      </div>
                    </div>

                    <div className="bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-800 p-3.5 rounded-2xl flex items-start gap-3">
                      <div className="w-8 h-8 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center font-black flex-shrink-0 text-sm">
                        2
                      </div>
                      <div>
                        <div className="text-xs font-black text-zinc-900 dark:text-white">
                          Bakım & Değer Artırma
                        </div>
                        <div className="text-[11px] text-zinc-500 mt-0.5">
                          Garajında aracına bakım ve onarım yaptırarak kondisyonunu ve satış değerini yükselt.
                        </div>
                      </div>
                    </div>

                    <div className="bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-800 p-3.5 rounded-2xl flex items-start gap-3">
                      <div className="w-8 h-8 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center font-black flex-shrink-0 text-sm">
                        3
                      </div>
                      <div>
                        <div className="text-xs font-black text-zinc-900 dark:text-white">
                          Müşteri Teklifleri Al
                        </div>
                        <div className="text-[11px] text-zinc-500 mt-0.5">
                          Günü ilerletip gelen alıcıların bütçelerini ve tekliflerini incele.
                        </div>
                      </div>
                    </div>

                    <div className="bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-800 p-3.5 rounded-2xl flex items-start gap-3">
                      <div className="w-8 h-8 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center font-black flex-shrink-0 text-sm">
                        4
                      </div>
                      <div>
                        <div className="text-xs font-black text-zinc-900 dark:text-white">
                          Pazarlık & "Son Fiyatım Bu"
                        </div>
                        <div className="text-[11px] text-zinc-500 mt-0.5">
                          Karşı teklif ver, son fiyatını söyle ve en yüksek karla aracını sat.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="p-4 bg-zinc-100 dark:bg-zinc-850 border-t border-zinc-200 dark:border-zinc-800 flex justify-end">
                <button
                  onClick={onClose}
                  className="bg-zinc-200 hover:bg-zinc-300 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 font-bold px-5 py-2 rounded-xl text-xs transition-colors"
                >
                  Kapat
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
