import React from 'react';
import { motion } from 'motion/react';
import { MarketCar, PlayerCar } from '../types';
import { formatMoney, formatKm, getConditionColor, ensureInspection, ensureEngine, normalizeImageUrl } from '../utils';
import { Settings, Gauge, Calendar, Tag, Flame, Clock, Eye, AlertTriangle, Zap, ShieldCheck, Award } from 'lucide-react';

interface CarCardProps {
  car: MarketCar | PlayerCar;
  actionButton?: React.ReactNode;
  secondaryAction?: React.ReactNode;
  isGarage?: boolean;
  offersCount?: number;
  onInspect?: () => void;
  repairingSecondsLeft?: number;
  isHighlighted?: boolean;
  highlightBadge?: string;
}

export const CarCard: React.FC<CarCardProps> = ({ 
  car, 
  actionButton, 
  secondaryAction, 
  isGarage, 
  offersCount = 0,
  onInspect,
  repairingSecondsLeft,
  isHighlighted = false,
  highlightBadge,
}) => {
  const isPlayerCar = isGarage && 'purchasePrice' in car;
  const playerCar = isPlayerCar ? (car as PlayerCar) : null;
  const inspection = ensureInspection(car?.inspection, car?.condition);
  const engine = ensureEngine(car?.engine);
  const isRepairing = typeof repairingSecondsLeft === 'number' && repairingSecondsLeft > 0;
  
  return (
    <motion.div 
      whileHover={{ y: -4 }}
      className={`bg-white dark:bg-zinc-900 border rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col group cursor-pointer relative ${
        isHighlighted
          ? 'border-orange-500 dark:border-orange-500 ring-4 ring-orange-500/50 shadow-xl shadow-orange-500/30'
          : isRepairing 
            ? 'border-amber-400 dark:border-amber-600 ring-2 ring-amber-400/20' 
            : 'border-zinc-200 dark:border-zinc-800'
      }`}
      onClick={() => {
        if (onInspect) onInspect();
      }}
    >
      {/* Highlight Banner Badge */}
      {isHighlighted && highlightBadge && (
        <div className="bg-gradient-to-r from-orange-600 to-amber-500 text-white text-xs font-black px-3 py-1.5 text-center flex items-center justify-center gap-1.5 shadow-md uppercase tracking-wider animate-pulse">
          <Zap size={14} className="fill-white" />
          <span>{highlightBadge}</span>
        </div>
      )}

      {/* Top Banner / Image Area */}
      <div className="h-44 bg-gradient-to-b from-zinc-100 to-zinc-200 dark:from-zinc-800 dark:to-zinc-850 relative flex items-center justify-center p-4">
        <div className="absolute top-3 left-3 flex items-center gap-1.5">
          <div className="bg-white/95 dark:bg-zinc-900/95 backdrop-blur-sm px-2.5 py-1 rounded-md text-xs font-bold shadow-sm text-zinc-800 dark:text-zinc-200 uppercase tracking-wider">
            {car.brand}
          </div>
          {isPlayerCar && playerCar?.buyDealGrade && (
            <div className={`px-2 py-1 rounded-md text-[10px] font-black tracking-wide flex items-center gap-1 shadow-sm ${
              playerCar.buyDealGrade === 'A' ? 'bg-emerald-500 text-white' :
              playerCar.buyDealGrade === 'B' ? 'bg-sky-500 text-white' :
              playerCar.buyDealGrade === 'C' ? 'bg-amber-500 text-white' :
              'bg-rose-500 text-white'
            }`}>
              <Award size={11} />
              <span>Alış Notu: {playerCar.buyDealGrade}</span>
            </div>
          )}
        </div>
        
        <div className="absolute top-3 right-3 flex items-center gap-1.5">
          {isRepairing ? (
            <span className="bg-amber-500 text-white text-[10px] font-black px-2 py-0.5 rounded shadow-sm animate-pulse flex items-center gap-1">
              <Clock size={11} /> {repairingSecondsLeft}s SERVİSTE
            </span>
          ) : (
            <>
              {car.isUnrepairable || inspection.isUnrepairable ? (
                <span className="bg-rose-700 text-white text-[10px] font-black px-2 py-0.5 rounded shadow-sm animate-pulse">
                  PERT (Onarılamaz)
                </span>
              ) : inspection.agirHasarKayitli ? (
                <span className="bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded shadow-sm">
                  AĞIR HASARLI
                </span>
              ) : null}
              <div className="bg-orange-500 text-white backdrop-blur-sm px-2.5 py-1 rounded-md text-xs font-bold shadow-sm">
                {car.type || 'Sedan'}
              </div>
            </>
          )}
        </div>
        
        {isGarage && (
          <div className="absolute bottom-2 left-3">
            {isRepairing ? (
              <span className="inline-flex items-center gap-1 bg-amber-500/90 text-white text-[11px] font-black px-2.5 py-0.5 rounded-full shadow-md backdrop-blur-sm">
                <Settings size={11} className="animate-spin" /> Onarım Yapılıyor...
              </span>
            ) : offersCount > 0 ? (
              <span className="inline-flex items-center gap-1 bg-orange-500 text-white text-[11px] font-black px-2.5 py-0.5 rounded-full shadow-md animate-pulse">
                <Flame size={12} className="fill-white" />
                {offersCount} Teklif Var
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 bg-zinc-800/80 text-zinc-300 text-[11px] font-medium px-2 py-0.5 rounded-full backdrop-blur-sm">
                <Clock size={11} />
                Teklif Bekleniyor
              </span>
            )}
          </div>
        )}

        {car.image && (car.image.startsWith('http') || car.image.startsWith('/') || car.image.startsWith('data:')) ? (
          <img 
            src={normalizeImageUrl(car.image)} 
            alt={`${car.brand} ${car.model}`}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover select-none transform transition-transform group-hover:scale-105 duration-300"
            onError={(e) => {
              // Fallback if image fails to load
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
        ) : (
          <span className="text-7xl drop-shadow-xl select-none transform transition-transform group-hover:scale-110 duration-300">
            {car.image || '🚗'}
          </span>
        )}

        {/* Inspect Overlay Prompt */}
        <div className="absolute bottom-2 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
          <span className="bg-black/75 text-white text-[10px] font-bold px-2 py-1 rounded-md flex items-center gap-1">
            <Eye size={12} /> Ekspertiz & İlan
          </span>
        </div>
      </div>

      <div className="p-5 flex flex-col flex-grow">
        <h3 className="text-base sm:text-lg font-black text-zinc-900 dark:text-white leading-tight mb-0.5 group-hover:text-orange-600 dark:group-hover:text-orange-400 transition-colors">
          {car.brand} {car.model}
        </h3>
        
        <div className="text-xs font-medium text-zinc-500 dark:text-zinc-400 mb-3 truncate">
          {car.series || engine.name} • {car.color || 'Beyaz'}
        </div>
        
        {/* Quick Specs Badges */}
        <div className="grid grid-cols-2 gap-2 mb-3">
          <div className="flex flex-col bg-zinc-50 dark:bg-zinc-800/50 p-2 rounded-xl border border-zinc-100 dark:border-zinc-800 text-xs">
            <span className="text-[10px] uppercase font-bold text-zinc-400 mb-0.5 flex items-center gap-1">
              <Gauge size={11}/> KM & Yıl
            </span>
            <span className="font-semibold text-zinc-800 dark:text-zinc-200">
              {formatKm(car.km || 0)} • {car.year}
            </span>
          </div>

          <div className="flex flex-col bg-zinc-50 dark:bg-zinc-800/50 p-2 rounded-xl border border-zinc-100 dark:border-zinc-800 text-xs">
            <span className="text-[10px] uppercase font-bold text-zinc-400 mb-0.5 flex items-center gap-1">
              <Zap size={11} className="text-orange-500" /> Motor & Vites
            </span>
            <span className="font-semibold text-zinc-800 dark:text-zinc-200 truncate">
              {engine.motorGucu} • {engine.transmission}
            </span>
          </div>
        </div>

        {/* Condition and Hasar Badge */}
        <div className="mb-3 space-y-1.5">
          <div className={`flex items-center justify-between p-2 rounded-xl border ${getConditionColor(car.condition)} text-xs font-bold`}>
            <span className="flex items-center gap-1.5">
              {car.condition === 'Temiz' ? (
                <ShieldCheck size={14} className="text-emerald-600" />
              ) : (
                <Settings size={14} />
              )}
              {car.condition}
            </span>
            <span className="text-[11px] opacity-85">
              {inspection.tramerTutar > 0 
                ? `Tramer: ${formatMoney(inspection.tramerTutar)}`
                : 'Tramer Kaydı Yok'}
            </span>
          </div>

          {/* Seller Tag (for market cars) */}
          {!isGarage && (car as MarketCar).sellerType && (
            <div className="flex items-center justify-between px-2 py-1 rounded-lg bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-100 dark:border-zinc-800 text-[11px]">
              <span className="flex items-center gap-1 text-zinc-600 dark:text-zinc-300 font-semibold truncate">
                <span>{(car as MarketCar).sellerAvatar || '👤'}</span>
                <span className="truncate">{(car as MarketCar).sellerName || (car as MarketCar).sellerType}</span>
              </span>
              {(car as MarketCar).isOverpriced ? (
                <span className="font-extrabold text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/40 px-1.5 py-0.5 rounded text-[10px] flex-shrink-0">
                  Tok Satıcı (+%{(car as MarketCar).overpricedPercentage || 18})
                </span>
              ) : (car as MarketCar).sellerType === 'Acil İhtiyaçtan' ? (
                <span className="font-extrabold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-1.5 py-0.5 rounded text-[10px] flex-shrink-0">
                  🔥 Kelepir İlan
                </span>
              ) : (
                <span className="text-zinc-400 text-[10px] flex-shrink-0">
                  {(car as MarketCar).sellerType}
                </span>
              )}
            </div>
          )}
        </div>

        <div className="mt-auto pt-3 border-t border-zinc-100 dark:border-zinc-800 flex justify-between items-end mb-4">
          <div>
            <span className="text-[11px] text-zinc-400 font-medium uppercase flex items-center gap-1 mb-0.5">
              <Tag size={11} /> {isPlayerCar ? 'Alış Maliyeti' : 'Satış Fiyatı'}
            </span>
            <div className="text-xl font-black text-orange-600 dark:text-orange-400">
              {formatMoney(isPlayerCar ? (car as PlayerCar).purchasePrice : car.price)}
            </div>
          </div>
          {isPlayerCar && car.condition !== 'Temiz' && secondaryAction && (
             <div className="text-right" onClick={(e) => e.stopPropagation()}>
               {secondaryAction}
             </div>
          )}
        </div>
        
        <div className="w-full" onClick={(e) => e.stopPropagation()}>
          {actionButton}
        </div>
      </div>
    </motion.div>
  );
};
