import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MarketCar } from '../types';
import { formatMoney, formatKm, getConditionColor, ensureEngine, normalizeImageUrl, evaluateBuyBargain, BuyBargainResult } from '../utils';
import { 
  X, 
  MessageSquare, 
  Handshake, 
  Sparkles, 
  AlertTriangle, 
  TrendingUp, 
  TrendingDown, 
  Coins, 
  Clock, 
  Send, 
  CheckCircle2, 
  Heart,
  Zap,
  HelpCircle,
  Percent,
  Check,
  ShoppingCart,
  Award
} from 'lucide-react';

interface BuyBargainModalProps {
  car: MarketCar | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirmBuy: (car: MarketCar, finalPrice: number, discountAmount: number) => void;
  playerMoney: number;
  playerReputation: number;
}

interface ChatMessage {
  id: string;
  sender: 'seller' | 'player' | 'system';
  text: string;
  price?: number;
  time: string;
}

export const BuyBargainModal: React.FC<BuyBargainModalProps> = ({
  car,
  isOpen,
  onClose,
  onConfirmBuy,
  playerMoney,
  playerReputation,
}) => {
  if (!isOpen || !car) return null;

  const askingPrice = car.price;
  const originalAskingPrice = car.originalAskingPrice || car.price;
  const fairMarketValue = car.fairMarketValue || Math.floor(askingPrice * 0.95);
  const sellerType = car.sellerType || 'Normal Binici';
  const sellerName = car.sellerName || 'Araç Sahibi';
  const sellerAvatar = car.sellerAvatar || '👨‍💼';
  const initialPatience = car.sellerPatience || 3;

  const [currentNegotiatedPrice, setCurrentNegotiatedPrice] = useState<number>(askingPrice);
  const [patience, setPatience] = useState<number>(initialPatience);
  const [hasAgreed, setHasAgreed] = useState<boolean>(false);
  const [hasWalkedAway, setHasWalkedAway] = useState<boolean>(false);
  const [customOfferInput, setCustomOfferInput] = useState<string>('');
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);

  // Chat message history
  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'init_seller',
      sender: 'seller',
      text: car.sellerQuote || `Selamlar esnaf kardeşim. Aracım için istediğim fiyat ${formatMoney(askingPrice)}. Mal ortada, ciddi alıcıysan konuşalım.`,
      price: askingPrice,
      time: 'Şimdi',
    },
  ]);

  const getTimeString = () => {
    const d = new Date();
    return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
  };

  const handleMakeOffer = (
    offerPrice: number,
    tactic: 'ikram' | 'nakit' | 'masraf' | 'son_fiyat' | 'custom',
    playerText: string
  ) => {
    if (hasWalkedAway || hasAgreed || isEvaluating) return;

    const cleanOffer = Math.max(10000, Math.min(offerPrice, currentNegotiatedPrice));

    // Add Player Message
    const playerMsg: ChatMessage = {
      id: `player_${Date.now()}`,
      sender: 'player',
      text: playerText,
      price: tactic === 'son_fiyat' ? undefined : cleanOffer,
      time: getTimeString(),
    };

    setMessages((prev) => [...prev, playerMsg]);
    setIsEvaluating(true);

    setTimeout(() => {
      const result: BuyBargainResult = evaluateBuyBargain(
        car,
        cleanOffer,
        currentNegotiatedPrice,
        tactic,
        patience,
        playerReputation
      );

      setPatience(result.patienceLeft);

      if (result.accepted) {
        setHasAgreed(true);
        setCurrentNegotiatedPrice(cleanOffer);
        setMessages((prev) => [
          ...prev,
          {
            id: `seller_${Date.now()}`,
            sender: 'seller',
            text: result.sellerMessage,
            price: cleanOffer,
            time: getTimeString(),
          },
          {
            id: `sys_${Date.now()}`,
            sender: 'system',
            text: `🎉 Satıcı teklifinizi kabul etti! Araç ${formatMoney(cleanOffer)} karşılığında satın alınabilir.`,
            time: getTimeString(),
          },
        ]);
      } else if (result.walkedAway) {
        setHasWalkedAway(true);
        setMessages((prev) => [
          ...prev,
          {
            id: `seller_${Date.now()}`,
            sender: 'seller',
            text: result.sellerMessage,
            time: getTimeString(),
          },
          {
            id: `sys_${Date.now()}`,
            sender: 'system',
            text: `❌ Satıcı pazarlıktan çekildi ve teklifleri kapattı.`,
            time: getTimeString(),
          },
        ]);
      } else {
        // Counter offer or rejection
        if (result.newPrice && result.newPrice < currentNegotiatedPrice) {
          setCurrentNegotiatedPrice(result.newPrice);
        }
        setMessages((prev) => [
          ...prev,
          {
            id: `seller_${Date.now()}`,
            sender: 'seller',
            text: result.sellerMessage,
            price: result.newPrice,
            time: getTimeString(),
          },
        ]);
      }

      setIsEvaluating(false);
    }, 700);
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseInt(customOfferInput.replace(/\D/g, ''), 10);
    if (!val || val <= 0) return;
    if (val >= currentNegotiatedPrice) {
      handleMakeOffer(currentNegotiatedPrice, 'custom', `Fiyatı kabul ediyorum, ${formatMoney(currentNegotiatedPrice)}'ye alıyorum.`);
    } else {
      handleMakeOffer(val, 'custom', `Usta benim bütçem ${formatMoney(val)} nakit. Uyarsa hemen notere geçelim.`);
    }
    setCustomOfferInput('');
  };

  const discountAmount = originalAskingPrice - currentNegotiatedPrice;
  const isAffordable = playerMoney >= currentNegotiatedPrice;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/75 backdrop-blur-sm overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="bg-white dark:bg-zinc-900 rounded-2xl w-full max-w-3xl shadow-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden flex flex-col my-auto max-h-[94vh]"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-orange-600 to-amber-600 text-white px-5 py-3.5 flex items-center justify-between shadow-md">
            <div className="flex items-center space-x-2.5">
              <div className="w-9 h-9 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center font-bold text-lg shadow-inner">
                🤝
              </div>
              <div>
                <h2 className="font-black text-base sm:text-lg leading-tight">Satıcı ile Pazarlık Masası</h2>
                <p className="text-xs text-orange-100 font-medium">Fiyatı düşürmek için esnaflığını konuştur!</p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 hover:bg-white/20 rounded-lg transition-colors text-white/90"
              title="Kapat"
            >
              <X size={20} />
            </button>
          </div>

          {/* Car & Seller Snapshot Ribbon */}
          <div className="bg-zinc-50 dark:bg-zinc-850 p-4 border-b border-zinc-200 dark:border-zinc-800 grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
            {/* Left: Car Details */}
            <div className="flex items-center space-x-3">
              <div className="w-16 h-14 bg-white dark:bg-zinc-800 rounded-xl overflow-hidden flex-shrink-0 flex items-center justify-center text-3xl shadow-sm border border-zinc-200 dark:border-zinc-700">
                {car.image && (car.image.startsWith('http') || car.image.startsWith('/') || car.image.startsWith('data:')) ? (
                  <img 
                    src={normalizeImageUrl(car.image)} 
                    alt={`${car.brand} ${car.model}`}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span>{car.image || '🚗'}</span>
                )}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className="font-black text-zinc-900 dark:text-white text-sm truncate">
                    {car.brand} {car.model}
                  </span>
                  <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${getConditionColor(car.condition)}`}>
                    {car.condition}
                  </span>
                </div>
                <div className="text-xs text-zinc-500 truncate">
                  {car.year} • {formatKm(car.km || 0)} • {car.engine?.motorGucu}
                </div>
              </div>
            </div>

            {/* Right: Seller Persona & Patience */}
            <div className="bg-white dark:bg-zinc-800 p-3 rounded-xl border border-zinc-200 dark:border-zinc-700 flex items-center justify-between shadow-xs">
              <div className="flex items-center space-x-2.5 min-w-0">
                <span className="text-2xl select-none">{sellerAvatar}</span>
                <div className="min-w-0">
                  <div className="font-bold text-xs text-zinc-900 dark:text-white truncate">
                    {sellerName}
                  </div>
                  <span className={`inline-block text-[10px] font-extrabold px-2 py-0.5 rounded-full mt-0.5 ${
                    sellerType === 'Tok Satıcı'
                      ? 'bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800'
                      : sellerType === 'Acil İhtiyaçtan'
                        ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                        : 'bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800'
                  }`}>
                    {sellerType}
                  </span>
                </div>
              </div>

              {/* Patience Hearts */}
              <div className="text-right flex flex-col items-end">
                <span className="text-[10px] uppercase font-bold text-zinc-400">Satıcı Sabrı</span>
                <div className="flex items-center gap-1 mt-0.5">
                  {Array.from({ length: initialPatience }).map((_, idx) => (
                    <Heart
                      key={idx}
                      size={14}
                      className={idx < patience ? 'fill-rose-500 text-rose-500' : 'text-zinc-300 dark:text-zinc-600'}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Pricing Analysis Bar */}
          <div className="bg-orange-50/70 dark:bg-zinc-800/40 px-5 py-2.5 border-b border-zinc-200 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-4">
              <div>
                <span className="text-zinc-400 block text-[10px] uppercase font-semibold">İlan Liste Fiyatı</span>
                <span className="font-bold text-zinc-800 dark:text-zinc-200 line-through opacity-70">
                  {formatMoney(originalAskingPrice)}
                </span>
              </div>

              <div>
                <span className="text-zinc-400 block text-[10px] uppercase font-semibold">Tahmini Piyasa Değeri</span>
                <span className="font-bold text-zinc-700 dark:text-zinc-300">
                  {formatMoney(fairMarketValue)}
                </span>
              </div>
            </div>

            {/* Overpriced / Fırsat Tag */}
            <div className="flex items-center gap-2">
              {car.isOverpriced ? (
                <div className="flex items-center gap-1 bg-rose-100 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 font-bold px-2 py-1 rounded-lg border border-rose-200 dark:border-rose-800 text-[11px]">
                  <TrendingUp size={13} />
                  <span>Piyasanın +%{car.overpricedPercentage || 18} Üzerinde (Pahalı)</span>
                </div>
              ) : sellerType === 'Acil İhtiyaçtan' ? (
                <div className="flex items-center gap-1 bg-emerald-100 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 font-bold px-2 py-1 rounded-lg border border-emerald-200 dark:border-emerald-800 text-[11px]">
                  <TrendingDown size={13} />
                  <span>Piyasa Altı Kelepir Fırsat!</span>
                </div>
              ) : (
                <div className="flex items-center gap-1 bg-sky-100 dark:bg-sky-950/50 text-sky-700 dark:text-sky-300 font-bold px-2 py-1 rounded-lg border border-sky-200 dark:border-sky-800 text-[11px]">
                  <Coins size={13} />
                  <span>Uygun / Piyasa Fiyatı</span>
                </div>
              )}
            </div>

            <div className="text-right">
              <span className="text-zinc-400 block text-[10px] uppercase font-semibold">Mevcut Pazarlık Fiyatı</span>
              <span className="font-black text-sm text-orange-600 dark:text-orange-400">
                {formatMoney(currentNegotiatedPrice)}
              </span>
            </div>
          </div>

          {/* Interactive Chat Stream */}
          <div className="flex-grow p-4 sm:p-5 overflow-y-auto space-y-3 min-h-[220px] max-h-[280px] bg-zinc-50/50 dark:bg-zinc-950/50">
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex flex-col ${
                  msg.sender === 'player'
                    ? 'items-end'
                    : msg.sender === 'seller'
                    ? 'items-start'
                    : 'items-center'
                }`}
              >
                {msg.sender === 'system' ? (
                  <div className="bg-zinc-200/80 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 text-xs font-semibold py-1.5 px-4 rounded-full text-center shadow-xs max-w-md">
                    {msg.text}
                  </div>
                ) : (
                  <div className="max-w-[85%] sm:max-w-[75%] space-y-1">
                    <div className="flex items-center gap-1.5 px-1">
                      <span className="text-[10px] font-bold text-zinc-400">
                        {msg.sender === 'player' ? 'Siz (Oto Galeri)' : `${sellerAvatar} ${sellerName}`}
                      </span>
                      <span className="text-[10px] text-zinc-400">• {msg.time}</span>
                    </div>

                    <div
                      className={`p-3.5 rounded-2xl text-xs sm:text-sm font-medium shadow-xs leading-relaxed ${
                        msg.sender === 'player'
                          ? 'bg-orange-500 text-white rounded-tr-xs'
                          : 'bg-white dark:bg-zinc-800 text-zinc-800 dark:text-zinc-100 border border-zinc-200 dark:border-zinc-700 rounded-tl-xs'
                      }`}
                    >
                      {msg.text}
                      {msg.price && (
                        <div
                          className={`mt-2 pt-2 border-t font-black flex items-center justify-between text-xs ${
                            msg.sender === 'player'
                              ? 'border-white/20 text-white'
                              : 'border-zinc-100 dark:border-zinc-700 text-orange-600 dark:text-orange-400'
                          }`}
                        >
                          <span>Teklif Edilen Tutar:</span>
                          <span className="text-sm">{formatMoney(msg.price)}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </motion.div>
            ))}

            {isEvaluating && (
              <div className="flex items-center space-x-2 text-zinc-400 text-xs py-2 px-1">
                <span className="animate-pulse">✍️ {sellerName} düşünüyor ve cevap yazıyor...</span>
              </div>
            )}
          </div>

          {/* Bargaining Tactics & Quick Actions */}
          {!hasWalkedAway && !hasAgreed ? (
            <div className="p-4 bg-white dark:bg-zinc-900 border-t border-zinc-200 dark:border-zinc-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
                  <Zap size={14} className="text-orange-500" /> Pazarlık Taktikleri & Teklif Butonları
                </span>
                <span className="text-[11px] text-zinc-400">
                  Kalan Sabır: <strong className="text-rose-500">{patience} Hamle</strong>
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {/* 1. Sünnettir İkram Payı (-%4) */}
                <button
                  type="button"
                  onClick={() => {
                    const offer = Math.floor((currentNegotiatedPrice * 0.96) / 1000) * 1000;
                    handleMakeOffer(
                      offer,
                      'ikram',
                      `Hayırlı işler abi, sünnettir diyerek çay kahve ikramı niyetine ${formatMoney(offer)} verelim, el sıkışalım.`
                    );
                  }}
                  disabled={isEvaluating}
                  className="p-2.5 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 hover:border-orange-500 hover:bg-orange-50/50 dark:hover:bg-orange-950/20 text-left transition-all group disabled:opacity-50"
                >
                  <div className="font-bold text-xs text-zinc-800 dark:text-zinc-200 group-hover:text-orange-600 dark:group-hover:text-orange-400 flex items-center gap-1">
                    ☕ Sünnettir (-%4)
                  </div>
                  <div className="text-[11px] font-black text-orange-600 dark:text-orange-400 mt-1">
                    {formatMoney(Math.floor((currentNegotiatedPrice * 0.96) / 1000) * 1000)}
                  </div>
                </button>

                {/* 2. Nakit Peşin Alıcı (-%8) */}
                <button
                  type="button"
                  onClick={() => {
                    const offer = Math.floor((currentNegotiatedPrice * 0.92) / 1000) * 1000;
                    handleMakeOffer(
                      offer,
                      'nakit',
                      `Usta sıcak para masada, nakit hemen hazır. ${formatMoney(offer)}'ye bırakırsan hemen notere geçiyoruz.`
                    );
                  }}
                  disabled={isEvaluating}
                  className="p-2.5 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 hover:border-orange-500 hover:bg-orange-50/50 dark:hover:bg-orange-950/20 text-left transition-all group disabled:opacity-50"
                >
                  <div className="font-bold text-xs text-zinc-800 dark:text-zinc-200 group-hover:text-orange-600 dark:group-hover:text-orange-400 flex items-center gap-1">
                    💵 Nakit Peşin (-%8)
                  </div>
                  <div className="text-[11px] font-black text-orange-600 dark:text-orange-400 mt-1">
                    {formatMoney(Math.floor((currentNegotiatedPrice * 0.92) / 1000) * 1000)}
                  </div>
                </button>

                {/* 3. Masraf / Ekspertiz Payı (-%14) */}
                <button
                  type="button"
                  onClick={() => {
                    const offer = Math.floor((currentNegotiatedPrice * 0.86) / 1000) * 1000;
                    handleMakeOffer(
                      offer,
                      'masraf',
                      `Araca bakım, pasta cila ve ekspertiz masrafı çıkacak. Masrafları kırışalım, son teklifim ${formatMoney(offer)}.`
                    );
                  }}
                  disabled={isEvaluating}
                  className="p-2.5 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 hover:border-orange-500 hover:bg-orange-50/50 dark:hover:bg-orange-950/20 text-left transition-all group disabled:opacity-50"
                >
                  <div className="font-bold text-xs text-zinc-800 dark:text-zinc-200 group-hover:text-orange-600 dark:group-hover:text-orange-400 flex items-center gap-1">
                    🔧 Masraf Düş (-%14)
                  </div>
                  <div className="text-[11px] font-black text-orange-600 dark:text-orange-400 mt-1">
                    {formatMoney(Math.floor((currentNegotiatedPrice * 0.86) / 1000) * 1000)}
                  </div>
                </button>

                {/* 4. Son Fiyat Sor */}
                <button
                  type="button"
                  onClick={() => {
                    handleMakeOffer(
                      currentNegotiatedPrice,
                      'son_fiyat',
                      'Usta lafı uzatmayalım, esnaf işi son oluru, son fiyatın nedir?'
                    );
                  }}
                  disabled={isEvaluating}
                  className="p-2.5 rounded-xl border border-amber-300 dark:border-amber-700 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 text-left transition-all group disabled:opacity-50"
                >
                  <div className="font-bold text-xs text-amber-800 dark:text-amber-300 flex items-center gap-1">
                    👑 "Son Fiyatın Nedir?"
                  </div>
                  <div className="text-[11px] text-amber-700 dark:text-amber-400 mt-1 font-medium">
                    Dip Fiyatı Öğren
                  </div>
                </button>
              </div>

              {/* Custom Number Input Row */}
              <form onSubmit={handleCustomSubmit} className="flex items-center gap-2 pt-1">
                <div className="relative flex-grow">
                  <input
                    type="text"
                    placeholder="Örn: 650.000 ₺ (Özel teklif tutarı yaz...)"
                    value={customOfferInput}
                    onChange={(e) => setCustomOfferInput(e.target.value)}
                    disabled={isEvaluating}
                    className="w-full pl-3 pr-10 py-2.5 text-xs sm:text-sm bg-zinc-100 dark:bg-zinc-800 rounded-xl border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                  <Coins size={16} className="absolute right-3 top-3 text-zinc-400" />
                </div>

                <button
                  type="submit"
                  disabled={!customOfferInput.trim() || isEvaluating}
                  className="px-4 py-2.5 bg-orange-500 hover:bg-orange-600 disabled:opacity-50 text-white font-bold text-xs sm:text-sm rounded-xl transition-colors flex items-center gap-1.5 flex-shrink-0"
                >
                  <Send size={15} /> Teklif Gönder
                </button>
              </form>
            </div>
          ) : null}

          {/* Bottom Footer Actions */}
          <div className="bg-zinc-100 dark:bg-zinc-850 p-4 border-t border-zinc-200 dark:border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <span className="text-xs text-zinc-500 dark:text-zinc-400 block font-medium">
                {hasAgreed ? 'Anlaşılan Nihai Fiyat' : 'Geçerli Fiyat'}
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-xl sm:text-2xl font-black text-orange-600 dark:text-orange-400">
                  {formatMoney(currentNegotiatedPrice)}
                </span>
                {discountAmount > 0 && (
                  <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-md">
                    -{formatMoney(discountAmount)} İndirim Kazandınız!
                  </span>
                )}
              </div>
            </div>

            <div className="flex items-center space-x-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 sm:flex-none px-4 py-2.5 bg-zinc-200 dark:bg-zinc-700 hover:bg-zinc-300 dark:hover:bg-zinc-600 text-zinc-800 dark:text-zinc-200 font-bold rounded-xl text-xs sm:text-sm transition-colors"
              >
                Vazgeç
              </button>

              {hasWalkedAway ? (
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 sm:flex-none px-5 py-2.5 bg-zinc-400 text-white font-bold rounded-xl text-xs sm:text-sm cursor-not-allowed"
                >
                  Pazarlık Başarısız
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    if (!isAffordable) return;
                    onConfirmBuy(car, currentNegotiatedPrice, discountAmount);
                    onClose();
                  }}
                  disabled={!isAffordable}
                  className={`flex-1 sm:flex-none px-6 py-2.5 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all active:scale-[0.98] shadow-md ${
                    isAffordable
                      ? hasAgreed
                        ? 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-emerald-500/30 ring-2 ring-emerald-400/50 animate-pulse'
                        : 'bg-orange-500 hover:bg-orange-600 text-white shadow-orange-500/25'
                      : 'bg-zinc-300 dark:bg-zinc-700 text-zinc-500 cursor-not-allowed'
                  }`}
                >
                  <ShoppingCart size={16} />
                  {isAffordable
                    ? hasAgreed
                      ? `🤝 Anlaştık! (${formatMoney(currentNegotiatedPrice)}) Satın Al`
                      : `Bu Fiyata Satın Al (${formatMoney(currentNegotiatedPrice)})`
                    : 'Yetersiz Bakiye'}
                </button>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
