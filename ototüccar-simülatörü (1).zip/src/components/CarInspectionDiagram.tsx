import React from 'react';
import { CarInspection, PartStatus } from '../types';
import { PART_NAMES, ensureInspection } from '../utils';
import { AlertTriangle, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface CarInspectionDiagramProps {
  inspection?: CarInspection | null;
  interactive?: boolean;
}

export const CarInspectionDiagram: React.FC<CarInspectionDiagramProps> = ({ inspection: rawInspection }) => {
  const inspection = ensureInspection(rawInspection);

  const getPartFill = (status: PartStatus): string => {
    switch (status) {
      case 'painted':
        return '#3b82f6'; // Blue
      case 'replaced':
        return '#ef4444'; // Red
      case 'original':
      default:
        return '#e2e8f0'; // Light gray
    }
  };

  const getPartStroke = (status: PartStatus): string => {
    switch (status) {
      case 'painted':
        return '#1d4ed8';
      case 'replaced':
        return '#b91c1c';
      case 'original':
      default:
        return '#94a3b8';
    }
  };

  // Group painted & replaced parts
  const paintedParts: string[] = [];
  const replacedParts: string[] = [];
  const originalParts: string[] = [];

  const partKeys: (keyof typeof PART_NAMES)[] = [
    'kaput',
    'tavan',
    'bagaj',
    'solOnCamurluk',
    'solOnKapi',
    'solArkaKapi',
    'solArkaCamurluk',
    'sagOnCamurluk',
    'sagOnKapi',
    'sagArkaKapi',
    'sagArkaCamurluk',
    'onTampon',
    'arkaTampon',
  ];

  partKeys.forEach((key) => {
    const status = inspection[key];
    const name = PART_NAMES[key];
    if (status === 'painted') paintedParts.push(name);
    else if (status === 'replaced') replacedParts.push(name);
    else originalParts.push(name);
  });

  return (
    <div className="bg-white dark:bg-zinc-900 rounded-xl p-4 border border-zinc-200 dark:border-zinc-800">
      <div className="flex items-center justify-between pb-3 mb-4 border-b border-zinc-100 dark:border-zinc-800">
        <div>
          <h4 className="text-sm font-bold text-zinc-900 dark:text-zinc-100 uppercase tracking-wider">
            Boya, Değişen ve Ekspertiz Bilgisi
          </h4>
          <p className="text-xs text-zinc-500">Orijinal, boyalı ve değişen parça detay raporu</p>
        </div>
        {inspection.agirHasarKayitli ? (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-red-100 text-red-700 dark:bg-red-950/70 dark:text-red-300 text-xs font-black rounded-lg border border-red-200 dark:border-red-800 animate-pulse">
            <AlertTriangle size={14} /> Ağır Hasar Kayıtlı!
          </span>
        ) : (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300 text-xs font-bold rounded-lg border border-emerald-200 dark:border-emerald-800">
            <ShieldCheck size={14} /> Ağır Hasar Kaydı Yok
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
        {/* Car Diagram Vector SVG */}
        <div className="md:col-span-5 flex justify-center py-2">
          <div className="relative w-56 h-80 bg-zinc-50 dark:bg-zinc-850 rounded-2xl p-4 flex items-center justify-center border border-zinc-100 dark:border-zinc-800 shadow-inner">
            <svg viewBox="0 0 240 360" className="w-full h-full drop-shadow-sm select-none">
              {/* Wheels */}
              <rect x="24" y="65" width="14" height="38" rx="4" fill="#334155" />
              <rect x="202" y="65" width="14" height="38" rx="4" fill="#334155" />
              <rect x="24" y="240" width="14" height="38" rx="4" fill="#334155" />
              <rect x="202" y="240" width="14" height="38" rx="4" fill="#334155" />

              {/* Ön Tampon */}
              <path
                d="M 65 24 C 95 16, 145 16, 175 24 C 185 27, 192 34, 192 42 L 48 42 C 48 34, 55 27, 65 24 Z"
                fill={getPartFill(inspection.onTampon)}
                stroke={getPartStroke(inspection.onTampon)}
                strokeWidth="2"
              />

              {/* Sol Ön Çamurluk */}
              <path
                d="M 46 44 L 75 44 L 75 110 L 42 110 C 40 85, 42 60, 46 44 Z"
                fill={getPartFill(inspection.solOnCamurluk)}
                stroke={getPartStroke(inspection.solOnCamurluk)}
                strokeWidth="2"
              />

              {/* Sağ Ön Çamurluk */}
              <path
                d="M 165 44 L 194 44 C 198 60, 200 85, 198 110 L 165 110 Z"
                fill={getPartFill(inspection.sagOnCamurluk)}
                stroke={getPartStroke(inspection.sagOnCamurluk)}
                strokeWidth="2"
              />

              {/* Ön Kaput */}
              <path
                d="M 77 44 L 163 44 L 163 112 L 77 112 Z"
                fill={getPartFill(inspection.kaput)}
                stroke={getPartStroke(inspection.kaput)}
                strokeWidth="2"
              />

              {/* Ön Cam */}
              <path
                d="M 75 115 L 165 115 L 155 145 L 85 145 Z"
                fill="#94a3b8"
                opacity="0.4"
              />

              {/* Sol Ön Kapı */}
              <path
                d="M 42 114 L 74 114 L 74 175 L 42 175 Z"
                fill={getPartFill(inspection.solOnKapi)}
                stroke={getPartStroke(inspection.solOnKapi)}
                strokeWidth="2"
              />

              {/* Sağ Ön Kapı */}
              <path
                d="M 166 114 L 198 114 L 198 175 L 166 175 Z"
                fill={getPartFill(inspection.sagOnKapi)}
                stroke={getPartStroke(inspection.sagOnKapi)}
                strokeWidth="2"
              />

              {/* Tavan */}
              <path
                d="M 85 147 L 155 147 L 155 220 L 85 220 Z"
                fill={getPartFill(inspection.tavan)}
                stroke={getPartStroke(inspection.tavan)}
                strokeWidth="2"
              />

              {/* Sol Arka Kapı */}
              <path
                d="M 42 178 L 74 178 L 74 238 L 42 238 Z"
                fill={getPartFill(inspection.solArkaKapi)}
                stroke={getPartStroke(inspection.solArkaKapi)}
                strokeWidth="2"
              />

              {/* Sağ Arka Kapı */}
              <path
                d="M 166 178 L 198 178 L 198 238 L 166 238 Z"
                fill={getPartFill(inspection.sagArkaKapi)}
                stroke={getPartStroke(inspection.sagArkaKapi)}
                strokeWidth="2"
              />

              {/* Arka Cam */}
              <path
                d="M 85 222 L 155 222 L 165 248 L 75 248 Z"
                fill="#94a3b8"
                opacity="0.4"
              />

              {/* Sol Arka Çamurluk */}
              <path
                d="M 42 240 L 74 240 L 74 300 L 50 300 C 44 280, 42 260, 42 240 Z"
                fill={getPartFill(inspection.solArkaCamurluk)}
                stroke={getPartStroke(inspection.solArkaCamurluk)}
                strokeWidth="2"
              />

              {/* Sağ Arka Çamurluk */}
              <path
                d="M 166 240 L 198 240 C 198 260, 196 280, 190 300 L 166 300 Z"
                fill={getPartFill(inspection.sagArkaCamurluk)}
                stroke={getPartStroke(inspection.sagArkaCamurluk)}
                strokeWidth="2"
              />

              {/* Bagaj Kapağı */}
              <path
                d="M 76 250 L 164 250 L 164 302 L 76 302 Z"
                fill={getPartFill(inspection.bagaj)}
                stroke={getPartStroke(inspection.bagaj)}
                strokeWidth="2"
              />

              {/* Arka Tampon */}
              <path
                d="M 48 304 L 192 304 C 192 316, 180 326, 170 330 C 145 338, 95 338, 70 330 C 60 326, 48 316, 48 304 Z"
                fill={getPartFill(inspection.arkaTampon)}
                stroke={getPartStroke(inspection.arkaTampon)}
                strokeWidth="2"
              />
            </svg>
          </div>
        </div>

        {/* Legend and Itemized Status */}
        <div className="md:col-span-7 space-y-4">
          {/* Color Legend */}
          <div className="flex flex-wrap items-center gap-3 p-2.5 bg-zinc-50 dark:bg-zinc-800/40 rounded-xl border border-zinc-100 dark:border-zinc-800 text-xs">
            <div className="flex items-center gap-1.5 font-medium text-zinc-700 dark:text-zinc-300">
              <span className="w-3.5 h-3.5 rounded bg-[#e2e8f0] border border-[#94a3b8] inline-block"></span>
              Orijinal
            </div>
            <div className="flex items-center gap-1.5 font-medium text-blue-700 dark:text-blue-400">
              <span className="w-3.5 h-3.5 rounded bg-blue-500 border border-blue-700 inline-block"></span>
              Boyalı ({paintedParts.length})
            </div>
            <div className="flex items-center gap-1.5 font-medium text-red-700 dark:text-red-400">
              <span className="w-3.5 h-3.5 rounded bg-red-500 border border-red-700 inline-block"></span>
              Değişen ({replacedParts.length})
            </div>
          </div>

          {/* Parts breakdown */}
          <div className="space-y-3">
            {/* Boyalı Parçalar */}
            <div className="space-y-1">
              <div className="text-xs font-bold text-blue-600 dark:text-blue-400 flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-blue-500 inline-block"></span>
                Boyalı Parçalar ({paintedParts.length})
              </div>
              {paintedParts.length > 0 ? (
                <div className="flex flex-wrap gap-1.5 pl-4">
                  {paintedParts.map((part, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 text-xs rounded-md border border-blue-200 dark:border-blue-800 font-medium"
                    >
                      • {part}
                    </span>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-zinc-400 pl-4 italic">Boyalı parça bulunmamaktadır.</p>
              )}
            </div>

            {/* Değişen Parçalar */}
            <div className="space-y-1">
              <div className="text-xs font-bold text-red-600 dark:text-red-400 flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-red-500 inline-block"></span>
                Değişen Parçalar ({replacedParts.length})
              </div>
              {replacedParts.length > 0 ? (
                <div className="flex flex-wrap gap-1.5 pl-4">
                  {replacedParts.map((part, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 text-xs rounded-md border border-red-200 dark:border-red-800 font-medium"
                    >
                      • {part}
                    </span>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-zinc-400 pl-4 italic">Değişen parça bulunmamaktadır.</p>
              )}
            </div>

            {/* Orijinal Parçalar */}
            <div className="space-y-1">
              <div className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                <CheckCircle2 size={12} />
                Orijinal Parçalar ({originalParts.length})
              </div>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 pl-4">
                {originalParts.length === partKeys.length
                  ? 'Araç tamamen hatasız ve boyasızdır.'
                  : `${originalParts.join(', ')}`}
              </p>
            </div>

            {/* Tramer Bilgisi */}
            <div className="pt-2 border-t border-zinc-100 dark:border-zinc-800 flex justify-between items-center text-xs">
              <span className="text-zinc-500">Tramer Hasar Kaydı Tutarı:</span>
              <span className="font-bold text-zinc-900 dark:text-white">
                {inspection.tramerTutar > 0
                  ? new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY', maximumFractionDigits: 0 }).format(
                      inspection.tramerTutar
                    )
                  : '0 TL (Kayıt Yok)'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
