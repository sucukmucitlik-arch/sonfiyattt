import React, { useState, useEffect } from 'react';
import { useGame } from '../store/GameContext';
import { CarCard } from './CarCard';
import { OfferCard } from './OfferCard';
import { CarDetailModal } from './CarDetailModal';
import { formatMoney, calculateRepairCost, calculateRepairDuration, getNextRepairedCondition, isCarRepairable, normalizeImageUrl } from '../utils';
import { getMaxGarageCapacity } from '../utils/upgradeUtils';
import { PlayerCar, CustomerOffer } from '../types';
import { Wrench, Store, Flame, Clock, TrendingUp, CheckCircle, Car, Sparkles, X, ChevronRight, Timer, Award, ArrowUpRight, Ban } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface GarageProps {
  onNavigateToOffers?: () => void;
  onNavigateToCollection?: () => void;
  onNavigateToShop?: () => void;
}

export const Garage: React.FC<GarageProps> = ({ onNavigateToOffers, onNavigateToCollection, onNavigateToShop }) => {
  const { state, dispatch } = useGame();
  const [selectedCarForOffers, setSelectedCarForOffers] = useState<PlayerCar | null>(null);
  const [inspectingCar, setInspectingCar] = useState<PlayerCar | null>(null);
  const [now, setNow] = useState<number>(Date.now());
  const [isEditingName, setIsEditingName] = useState<boolean>(false);
  const [nameInput, setNameInput] = useState<string>(state.galleryName || 'Son Fiyat Motors');

  const upgrades = state.upgrades || {
    parking: 1,
    repair_speed: 1,
    paint_booth: 1,
    marketing: 1,
    mechanic_discount: 1,
  };

  const maxCapacity = getMaxGarageCapacity(upgrades.parking);

  // 1-second interval to update remaining repair timer displays
  useEffect(() => {
    const timer = setInterval(() => {
      setNow(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleSaveName = () => {
    if (nameInput.trim()) {
      dispatch({ type: 'SET_GALLERY_NAME', payload: nameInput.trim() });
    }
    setIsEditingName(false);
  };

  const handleStartRepair = (car: PlayerCar) => {
    const cost = calculateRepairCost(car, upgrades.mechanic_discount);
    const duration = calculateRepairDuration(car, upgrades.repair_speed);
    if (state.money >= cost) {
      dispatch({ 
        type: 'START_REPAIR', 
        payload: { 
          carMarketId: car.marketId, 
          cost, 
          durationSeconds: duration 
        } 
      });
    }
  };

  const inventoryValue = state.garage.reduce((sum, c) => sum + c.purchasePrice, 0);

  // Filter offers for the selected car in modal
  const activeCarOffers = selectedCarForOffers 
    ? state.offers.filter(o => o.carMarketId === selectedCarForOffers.marketId)
    : [];

  return (
    <div className="space-y-6">
      {/* Dealership Storefront Signboard Banner */}
      <div className="bg-gradient-to-r from-zinc-900 via-zinc-900 to-zinc-950 border border-zinc-800 text-white rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/10 blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-orange-600 to-amber-500 flex items-center justify-center text-white text-2xl font-black shadow-lg shadow-orange-500/20 flex-shrink-0">
              🏢
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-black tracking-widest text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded-md border border-orange-500/20">
                  Resmi Galeri Showroomu
                </span>
                <span className="text-[10px] text-zinc-400 font-bold">
                  Kapasite: {state.garage.length}/{maxCapacity}
                </span>
              </div>
              
              {isEditingName ? (
                <div className="flex items-center gap-2 mt-1">
                  <input
                    type="text"
                    maxLength={32}
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    placeholder="Galeri Adı Girin..."
                    className="bg-zinc-950 border border-orange-500 rounded-xl px-3 py-1 text-sm font-black text-white focus:outline-none"
                    autoFocus
                  />
                  <button
                    onClick={handleSaveName}
                    className="px-3 py-1 bg-orange-500 hover:bg-orange-600 text-white text-xs font-black rounded-xl transition-all shadow"
                  >
                    Kaydet
                  </button>
                  <button
                    onClick={() => setIsEditingName(false)}
                    className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-bold rounded-xl"
                  >
                    İptal
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2 mt-0.5">
                  <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                    {state.galleryName || 'Son Fiyat Motors'}
                  </h3>
                  <button
                    onClick={() => {
                      setNameInput(state.galleryName || 'Son Fiyat Motors');
                      setIsEditingName(true);
                    }}
                    className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
                    title="Galeri Adını Değiştir"
                  >
                    <span className="text-xs">✏️ İsim Değiştir</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap w-full sm:w-auto">
            {onNavigateToShop && (
              <button
                onClick={onNavigateToShop}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-2 rounded-xl font-bold text-xs transition-all active:scale-95 shadow-md shadow-blue-600/20"
              >
                <ArrowUpRight size={14} />
                Kapasite Arttır
              </button>
            )}

            {state.offers.length > 0 && onNavigateToOffers && (
              <button
                onClick={onNavigateToOffers}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-2 bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-xl font-black text-xs transition-all active:scale-95 shadow-md shadow-orange-500/20"
              >
                <Flame size={15} className="fill-white" />
                Teklifler ({state.offers.length})
                <ChevronRight size={13} />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Top Header & Gallery Stats */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-black tracking-tight text-zinc-900 dark:text-white flex items-center gap-2">
            <span>Galerim & Vitrin</span>
            <span className="text-xs font-bold text-orange-600 bg-orange-100 dark:bg-orange-950/60 dark:text-orange-300 px-2.5 py-1 rounded-lg border border-orange-200 dark:border-orange-800">
              {state.garage.length} / {maxCapacity} Araç
            </span>
          </h2>
          <p className="text-sm text-zinc-500 mt-1 font-medium">
            Galerinizdeki vitrin araçlarını yönetin, hasarları serviste onarın ve gelen müşteri tekliflerini değerlendirin.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {onNavigateToShop && (
            <button
              onClick={onNavigateToShop}
              className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-2.5 rounded-xl font-bold text-xs transition-all active:scale-95 shadow-md shadow-blue-600/20"
            >
              <ArrowUpRight size={15} />
              Dükkan & Seviyeler
            </button>
          )}

          {onNavigateToCollection && (
            <button
              onClick={onNavigateToCollection}
              className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-600 text-white px-3.5 py-2.5 rounded-xl font-bold text-xs transition-all active:scale-95 shadow-md shadow-amber-500/20"
            >
              <Award size={15} />
              Koleksiyon ({state.collectedModelKeys?.length || 0} Pul)
            </button>
          )}

          {state.offers.length > 0 && onNavigateToOffers && (
            <button
              onClick={onNavigateToOffers}
              className="flex items-center gap-2 bg-orange-500 hover:bg-orange-600 text-white px-4 py-2.5 rounded-xl font-black text-xs transition-all active:scale-95 shadow-md shadow-orange-500/20"
            >
              <Flame size={16} className="fill-white" />
              Tüm Teklifleri İncele ({state.offers.length})
              <ChevronRight size={14} />
            </button>
          )}
        </div>
      </div>

      {/* Gallery Stats Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-zinc-900 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-sm">
          <span className="text-[10px] uppercase font-bold text-zinc-400 block mb-1">Envanter Değeri</span>
          <span className="text-lg font-black text-zinc-900 dark:text-white">{formatMoney(inventoryValue)}</span>
        </div>

        <div className="bg-white dark:bg-zinc-900 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-sm">
          <span className="text-[10px] uppercase font-bold text-zinc-400 block mb-1">Aktif Teklifler</span>
          <span className="text-lg font-black text-orange-600 dark:text-orange-400 flex items-center gap-1.5">
            <Flame size={18} className={state.offers.length > 0 ? "fill-orange-500" : "text-zinc-400"} />
            {state.offers.length} Teklif
          </span>
        </div>

        <div className="bg-white dark:bg-zinc-900 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-sm">
          <span className="text-[10px] uppercase font-bold text-zinc-400 block mb-1">Satılan Araç</span>
          <span className="text-lg font-black text-zinc-900 dark:text-white flex items-center gap-1.5">
            <CheckCircle size={18} className="text-orange-500" />
            {state.carsSold} Adet
          </span>
        </div>

        <div className="bg-white dark:bg-zinc-900 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-sm">
          <span className="text-[10px] uppercase font-bold text-zinc-400 block mb-1">Toplam Kâr</span>
          <span className={`text-lg font-black flex items-center gap-1 ${state.totalProfit >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
            <TrendingUp size={18} />
            {state.totalProfit >= 0 ? '+' : ''}{formatMoney(state.totalProfit)}
          </span>
        </div>
      </div>

      {/* Garage Cars Grid */}
      {state.garage.length === 0 ? (
        <div className="text-center py-24 bg-white dark:bg-zinc-900 rounded-2xl border border-dashed border-zinc-200 dark:border-zinc-800 flex flex-col items-center p-8">
          <div className="w-20 h-20 bg-orange-50 dark:bg-zinc-800 rounded-2xl flex items-center justify-center mb-4 text-orange-500">
            <Store size={40} />
          </div>
          <h3 className="text-lg font-bold text-zinc-900 dark:text-white mb-2">Galeriniz Boş</h3>
          <p className="text-zinc-500 font-medium max-w-md text-sm leading-relaxed mb-4">
            Henüz galerinizde sergilenen bir araç yok. Piyasa ilanlarından fırsat araçlarını satın alın, vitrininize koyun ve müşterilerin tekliflerini bekleyin.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {state.garage.map(car => {
            const repairCheck = isCarRepairable(car);
            const repairCost = calculateRepairCost(car);
            const repairDuration = calculateRepairDuration(car);
            const nextCondition = getNextRepairedCondition(car.condition);
            const carOffers = state.offers.filter(o => o.carMarketId === car.marketId);
            const hasOffers = carOffers.length > 0;

            // Check if car is currently repairing
            const repairInfo = state.activeRepairs.find(r => r.carMarketId === car.marketId);
            const isRepairing = repairInfo && repairInfo.finishTimestamp > now;
            const secondsLeft = isRepairing ? Math.max(1, Math.ceil((repairInfo.finishTimestamp - now) / 1000)) : 0;

            const isTutorialTarget = state.tutorialStep === 'repair_egea' && 
              (car.marketId === 'tutorial_egea_01' || (car.brand === 'Fiat' && car.model.includes('Egea')));

            return (
              <CarCard 
                key={car.marketId} 
                car={car} 
                isGarage
                isHighlighted={isTutorialTarget}
                highlightBadge={isTutorialTarget ? "👉 3. ADIM: BU ARACA BAKIM YAP" : undefined}
                offersCount={carOffers.length}
                repairingSecondsLeft={isRepairing ? secondsLeft : undefined}
                onInspect={() => setInspectingCar(car)}
                secondaryAction={
                  isRepairing ? (
                    <div className="flex items-center gap-1 text-xs font-black text-amber-600 bg-amber-50 dark:bg-amber-950/40 px-2.5 py-1 rounded-lg border border-amber-200 dark:border-amber-800">
                      <Timer size={12} className="animate-spin" />
                      {secondsLeft} sn
                    </div>
                  ) : !repairCheck.repairable ? (
                    <span 
                      className="text-xs font-bold text-rose-600 bg-rose-50 dark:bg-rose-950/40 px-2.5 py-1.5 rounded-lg flex items-center gap-1 border border-rose-200 dark:border-rose-800/40 cursor-not-allowed"
                      title={repairCheck.reason || 'Pert kayıtlı / Tamir edilemez'}
                    >
                      <Ban size={13} />
                      Pert / Onarılamaz
                    </span>
                  ) : car.condition !== 'Temiz' ? (
                    <button
                      onClick={() => handleStartRepair(car)}
                      disabled={state.money < repairCost}
                      className={`text-xs font-bold px-2.5 py-1.5 rounded-lg flex items-center gap-1 transition-all border ${
                        isTutorialTarget
                          ? 'bg-emerald-500 hover:bg-emerald-600 text-white border-emerald-400 ring-2 ring-emerald-400 animate-bounce shadow-lg shadow-emerald-500/30'
                          : 'text-orange-600 hover:text-orange-700 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/40 border-orange-200 dark:border-orange-800/40'
                      }`}
                      title={
                        car.condition === 'Boyalı'
                          ? `Boya koruma & pasta cila (${repairDuration} sn) - Satış cazibesini artırır`
                          : `Serviste onar -> '${nextCondition}' kondisyona yükselt (${repairDuration} sn)`
                      }
                    >
                      <Wrench size={13} />
                      {isTutorialTarget ? 'Hemen Bakım Yap' : car.condition === 'Boyalı' ? 'Boya Bakımı' : 'Onar'} ({formatMoney(repairCost)})
                    </button>
                  ) : undefined
                }
                actionButton={
                  isRepairing ? (
                    <div className="w-full py-2.5 bg-amber-100 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 rounded-xl font-black text-xs flex items-center justify-center gap-2 border border-amber-300 dark:border-amber-700">
                      <Timer size={14} className="animate-spin" />
                      Ustalar Çalışıyor ({secondsLeft} sn kaldı)
                    </div>
                  ) : isTutorialTarget && car.condition !== 'Temiz' ? (
                    <button
                      onClick={() => handleStartRepair(car)}
                      disabled={state.money < repairCost}
                      className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white rounded-xl font-black text-xs flex items-center justify-center gap-2 transition-all active:scale-[0.98] shadow-lg shadow-emerald-500/30 ring-2 ring-white animate-pulse"
                    >
                      <Wrench size={16} />
                      👉 3. ADIM: FIAT EGEA'YA BAKIM YAP ({formatMoney(repairCost)})
                    </button>
                  ) : hasOffers ? (
                    <button
                      onClick={() => setSelectedCarForOffers(car)}
                      className="w-full py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-xl font-black text-xs flex items-center justify-center gap-2 transition-all active:scale-[0.98] shadow-md shadow-orange-500/20"
                    >
                      <Flame size={16} className="fill-white" />
                      Gelen Teklifleri İncele ({carOffers.length})
                    </button>
                  ) : (
                    <button
                      onClick={() => setInspectingCar(car)}
                      className="w-full py-2.5 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800/60 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 rounded-xl font-semibold text-xs flex items-center justify-center gap-2 border border-zinc-200 dark:border-zinc-800 transition-colors"
                    >
                      <Clock size={14} className="text-orange-500 animate-pulse" />
                      Teklif Bekleniyor • Ekspertizi Gör
                    </button>
                  )
                }
              />
            );
          })}
        </div>
      )}

      {/* Car Detail Modal for Garage Car */}
      <CarDetailModal
        car={inspectingCar}
        isOpen={!!inspectingCar}
        onClose={() => setInspectingCar(null)}
        isGarage
        actionButton={
          inspectingCar && (
            <div className="flex items-center gap-2">
              {inspectingCar.condition !== 'Temiz' && isCarRepairable(inspectingCar).repairable && (
                <button
                  onClick={() => {
                    handleStartRepair(inspectingCar);
                    setInspectingCar(null);
                  }}
                  disabled={state.money < calculateRepairCost(inspectingCar)}
                  className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl font-bold text-sm transition-all flex items-center gap-1.5"
                >
                  <Wrench size={15} />
                  {inspectingCar.condition === 'Boyalı' ? 'Boya Bakımı Yap' : 'Serviste Onar'} ({formatMoney(calculateRepairCost(inspectingCar))})
                </button>
              )}
              <button
                onClick={() => {
                  setInspectingCar(null);
                  setSelectedCarForOffers(inspectingCar);
                }}
                className="px-5 py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-xl font-black text-sm transition-all"
              >
                Teklifleri İncele
              </button>
            </div>
          )
        }
      />

      {/* Selected Car Offers Modal */}
      <AnimatePresence>
        {selectedCarForOffers && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/70 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-zinc-50 dark:bg-zinc-900 rounded-2xl p-6 w-full max-w-2xl shadow-2xl border border-zinc-200 dark:border-zinc-800 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex justify-between items-start mb-6 sticky top-0 bg-zinc-50 dark:bg-zinc-900 pb-2 z-10 border-b border-zinc-200 dark:border-zinc-800">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-orange-500/10 text-orange-600 dark:text-orange-400 font-black text-base flex items-center justify-center border border-orange-500/20 shadow-sm flex-shrink-0 overflow-hidden">
                    {selectedCarForOffers.image && (selectedCarForOffers.image.startsWith('http') || selectedCarForOffers.image.startsWith('/') || selectedCarForOffers.image.startsWith('data:')) ? (
                      <img 
                        src={normalizeImageUrl(selectedCarForOffers.image)} 
                        alt={selectedCarForOffers.model}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <span>{selectedCarForOffers.image || '🚗'}</span>
                    )}
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-zinc-900 dark:text-white">
                      {selectedCarForOffers.brand} {selectedCarForOffers.model}
                    </h3>
                    <div className="flex items-center gap-3 text-xs text-zinc-500 font-semibold mt-0.5">
                      <span>Alış Maliyeti: {formatMoney(selectedCarForOffers.totalInvestedCost || selectedCarForOffers.purchasePrice)}</span>
                      <span>•</span>
                      <span>Durum: {selectedCarForOffers.condition}</span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedCarForOffers(null)}
                  className="p-2 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300 rounded-full"
                >
                  <X size={20} />
                </button>
              </div>

              {activeCarOffers.length === 0 ? (
                <div className="text-center py-12 text-zinc-500 font-medium">
                  Bu araç için henüz teklif kalmadı veya kabul edildi.
                </div>
              ) : (
                <div className="space-y-4">
                  {activeCarOffers.map(offer => (
                    <OfferCard key={offer.id} offer={offer} car={selectedCarForOffers} />
                  ))}
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
