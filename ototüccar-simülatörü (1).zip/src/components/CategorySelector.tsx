import React, { useState } from 'react';
import { CAR_DATABASE } from '../data/cars';
import { MarketCar } from '../types';
import { ChevronRight, ArrowLeft, Car, Layers, Zap, X } from 'lucide-react';

interface CategorySelectorProps {
  marketCars: MarketCar[];
  selectedBrand: string | null;
  selectedModel: string | null;
  selectedEngine: string | null;
  onSelectCategory: (brand: string | null, model: string | null, engine: string | null) => void;
  onClose?: () => void;
}

export const CategorySelector: React.FC<CategorySelectorProps> = ({
  marketCars,
  selectedBrand,
  selectedModel,
  selectedEngine,
  onSelectCategory,
  onClose,
}) => {
  const [activeBrand, setActiveBrand] = useState<string | null>(selectedBrand);
  const [activeModel, setActiveModel] = useState<string | null>(selectedModel);

  // Get unique brands with total live market count + database representation
  const allBrands = Array.from(new Set(CAR_DATABASE.map((c) => c.brand))).sort((a, b) =>
    a.localeCompare(b, 'tr')
  );

  const getBrandLiveCount = (brand: string) => {
    return marketCars.filter((c) => c.brand === brand).length;
  };

  const getModelLiveCount = (brand: string, model: string) => {
    return marketCars.filter((c) => c.brand === brand && c.model === model).length;
  };

  const getEngineLiveCount = (brand: string, model: string, engineName: string) => {
    return marketCars.filter(
      (c) => c.brand === brand && c.model === model && c.engine.name.includes(engineName)
    ).length;
  };

  // When inside a brand, get unique models
  const brandModels = activeBrand
    ? Array.from(
        new Set(
          CAR_DATABASE.filter((c) => c.brand === activeBrand).map((c) => c.model)
        )
      ).sort((a, b) => a.localeCompare(b, 'tr'))
    : [];

  // When inside a model, get unique engine variants
  const modelEngines =
    activeBrand && activeModel
      ? Array.from(
          new Set(
            CAR_DATABASE.filter(
              (c) => c.brand === activeBrand && c.model === activeModel
            ).map((c) => c.engine.name)
          )
        )
      : [];

  const handleSelectAllOtomobil = () => {
    setActiveBrand(null);
    setActiveModel(null);
    onSelectCategory(null, null, null);
    if (onClose) onClose();
  };

  const handleSelectAllBrand = (brand: string) => {
    setActiveModel(null);
    onSelectCategory(brand, null, null);
    if (onClose) onClose();
  };

  const handleSelectModel = (brand: string, model: string) => {
    onSelectCategory(brand, model, null);
    if (onClose) onClose();
  };

  const handleSelectEngine = (brand: string, model: string, engine: string) => {
    onSelectCategory(brand, model, engine);
    if (onClose) onClose();
  };

  return (
    <div className="bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-lg overflow-hidden flex flex-col max-h-[85vh]">
      {/* Header with Title and Back Navigation */}
      <div className="bg-orange-500 text-white px-4 py-3.5 flex items-center justify-between shadow-md">
        <div className="flex items-center space-x-3">
          {(activeBrand || activeModel) ? (
            <button
              onClick={() => {
                if (activeModel) {
                  setActiveModel(null);
                } else if (activeBrand) {
                  setActiveBrand(null);
                }
              }}
              className="p-1.5 hover:bg-orange-600 rounded-full transition-colors"
              title="Geri Dön"
            >
              <ArrowLeft size={20} />
            </button>
          ) : (
            <Layers size={20} />
          )}
          <h3 className="font-bold text-base tracking-wide">
            {activeModel ? `${activeBrand} ${activeModel} Motor Seçimi` : activeBrand ? `${activeBrand} Modelleri` : 'Kategori Seçimi'}
          </h3>
        </div>
        
        {onClose && (
          <button
            onClick={onClose}
            className="p-1 hover:bg-orange-600 rounded-lg transition-colors text-white/80 hover:text-white"
          >
            <X size={20} />
          </button>
        )}
      </div>

      {/* Breadcrumb Path */}
      <div className="bg-zinc-50 dark:bg-zinc-800/60 px-4 py-2 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-1.5 text-xs text-zinc-500 dark:text-zinc-400 overflow-x-auto">
        <button
          onClick={() => {
            setActiveBrand(null);
            setActiveModel(null);
          }}
          className="hover:text-orange-600 font-semibold transition-colors"
        >
          Otomobil
        </button>
        {activeBrand && (
          <>
            <ChevronRight size={14} className="opacity-60 flex-shrink-0" />
            <button
              onClick={() => setActiveModel(null)}
              className={`hover:text-orange-600 font-semibold transition-colors ${!activeModel ? 'text-orange-600 dark:text-orange-400' : ''}`}
            >
              {activeBrand}
            </button>
          </>
        )}
        {activeModel && (
          <>
            <ChevronRight size={14} className="opacity-60 flex-shrink-0" />
            <span className="text-orange-600 dark:text-orange-400 font-bold">
              {activeModel}
            </span>
          </>
        )}
      </div>

      {/* Content List Area */}
      <div className="overflow-y-auto divide-y divide-zinc-100 dark:divide-zinc-800/80">
        {/* Step 1: Brands list */}
        {!activeBrand && (
          <>
            <button
              onClick={handleSelectAllOtomobil}
              className="w-full px-5 py-3.5 flex items-center justify-between text-left hover:bg-orange-50 dark:hover:bg-zinc-800/50 transition-colors font-bold text-orange-600 dark:text-orange-400 border-b border-zinc-200 dark:border-zinc-800"
            >
              <div className="flex items-center space-x-3">
                <Car size={18} />
                <span>Tüm "Otomobil" İlanları</span>
              </div>
              <div className="flex items-center space-x-1 text-xs text-zinc-500">
                <span>({marketCars.length} Piyasada)</span>
                <ChevronRight size={16} />
              </div>
            </button>

            {allBrands.map((brand) => {
              const liveCount = getBrandLiveCount(brand);
              return (
                <button
                  key={brand}
                  onClick={() => setActiveBrand(brand)}
                  className="w-full px-5 py-3 flex items-center justify-between text-left hover:bg-zinc-50 dark:hover:bg-zinc-800/40 transition-colors group"
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 rounded-xl bg-orange-500/10 text-orange-600 dark:text-orange-400 font-black text-xs flex items-center justify-center border border-orange-500/20 shadow-sm flex-shrink-0 group-hover:bg-orange-500 group-hover:text-white transition-colors">
                      {brand.substring(0, 3).toUpperCase()}
                    </div>
                    <span className="font-semibold text-zinc-800 dark:text-zinc-200 group-hover:text-orange-600 dark:group-hover:text-orange-400 transition-colors">
                      {brand}
                    </span>
                  </div>
                  <div className="flex items-center space-x-1 text-xs text-zinc-400 group-hover:text-zinc-600 dark:group-hover:text-zinc-300">
                    <span className={liveCount > 0 ? 'font-bold text-orange-600 dark:text-orange-400' : ''}>
                      ({liveCount > 0 ? `${liveCount} İlanda` : 'Katalog'})
                    </span>
                    <ChevronRight size={16} className="text-zinc-300 group-hover:text-orange-500 transition-colors" />
                  </div>
                </button>
              );
            })}
          </>
        )}

        {/* Step 2: Models list for active brand */}
        {activeBrand && !activeModel && (
          <>
            <button
              onClick={() => handleSelectAllBrand(activeBrand)}
              className="w-full px-5 py-3.5 flex items-center justify-between text-left hover:bg-orange-50 dark:hover:bg-zinc-800/50 transition-colors font-bold text-orange-600 dark:text-orange-400 border-b border-zinc-200 dark:border-zinc-800"
            >
              <span>Tüm "{activeBrand}" İlanları</span>
              <div className="flex items-center space-x-1 text-xs text-zinc-500">
                <span>({getBrandLiveCount(activeBrand)} Piyasada)</span>
                <ChevronRight size={16} />
              </div>
            </button>

            {brandModels.map((model) => {
              const liveCount = getModelLiveCount(activeBrand, model);
              return (
                <button
                  key={model}
                  onClick={() => setActiveModel(model)}
                  className="w-full px-5 py-3 flex items-center justify-between text-left hover:bg-zinc-50 dark:hover:bg-zinc-800/40 transition-colors group"
                >
                  <span className="font-semibold text-zinc-800 dark:text-zinc-200 group-hover:text-orange-600 dark:group-hover:text-orange-400 transition-colors">
                    {model}
                  </span>
                  <div className="flex items-center space-x-1 text-xs text-zinc-400 group-hover:text-zinc-600 dark:group-hover:text-zinc-300">
                    <span className={liveCount > 0 ? 'font-bold text-orange-600 dark:text-orange-400' : ''}>
                      ({liveCount > 0 ? `${liveCount} İlanda` : 'Model'})
                    </span>
                    <ChevronRight size={16} className="text-zinc-300 group-hover:text-orange-500 transition-colors" />
                  </div>
                </button>
              );
            })}
          </>
        )}

        {/* Step 3: Engine / Trim options */}
        {activeBrand && activeModel && (
          <>
            <button
              onClick={() => handleSelectModel(activeBrand, activeModel)}
              className="w-full px-5 py-3.5 flex items-center justify-between text-left hover:bg-orange-50 dark:hover:bg-zinc-800/50 transition-colors font-bold text-orange-600 dark:text-orange-400 border-b border-zinc-200 dark:border-zinc-800"
            >
              <span>Tüm "{activeBrand} {activeModel}" İlanları</span>
              <div className="flex items-center space-x-1 text-xs text-zinc-500">
                <span>({getModelLiveCount(activeBrand, activeModel)} Piyasada)</span>
                <ChevronRight size={16} />
              </div>
            </button>

            {modelEngines.map((engine) => {
              const liveCount = getEngineLiveCount(activeBrand, activeModel, engine);
              const carVariant = CAR_DATABASE.find(
                (c) => c.brand === activeBrand && c.model === activeModel && c.engine.name === engine
              );
              return (
                <button
                  key={engine}
                  onClick={() => handleSelectEngine(activeBrand, activeModel, engine)}
                  className="w-full px-5 py-3.5 flex items-center justify-between text-left hover:bg-zinc-50 dark:hover:bg-zinc-800/40 transition-colors group"
                >
                  <div>
                    <div className="font-bold text-zinc-900 dark:text-white group-hover:text-orange-600 dark:group-hover:text-orange-400 transition-colors">
                      {engine}
                    </div>
                    {carVariant && (
                      <div className="text-xs text-zinc-500 flex items-center gap-2 mt-0.5">
                        <span className="flex items-center gap-1">
                          <Zap size={12} className="text-orange-500" />
                          {carVariant.engine.motorGucu}
                        </span>
                        <span>•</span>
                        <span>{carVariant.engine.fuelType}</span>
                        <span>•</span>
                        <span>{carVariant.engine.transmission}</span>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center space-x-1 text-xs text-zinc-400 group-hover:text-zinc-600 dark:group-hover:text-zinc-300">
                    <span className={liveCount > 0 ? 'font-bold text-orange-600 dark:text-orange-400' : ''}>
                      ({liveCount > 0 ? `${liveCount} İlanda` : 'Seçenek'})
                    </span>
                    <ChevronRight size={16} className="text-zinc-300 group-hover:text-orange-500 transition-colors" />
                  </div>
                </button>
              );
            })}
          </>
        )}
      </div>
    </div>
  );
};
