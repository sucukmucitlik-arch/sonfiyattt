import React, { useState } from 'react';
import { CustomerOffer, PlayerCar } from '../types';
import { useGame } from '../store/GameContext';
import { formatMoney, evaluateCounterOffer, getConditionColor, normalizeImageUrl } from '../utils';
import { Check, X, MessageSquare, Handshake, TrendingUp, AlertTriangle, User, ArrowRight, CheckCircle2, XCircle, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface OfferCardProps {
  offer: CustomerOffer;
  car?: PlayerCar;
}

export const OfferCard: React.FC<OfferCardProps> = ({ offer, car }) => {
  const { state, dispatch } = useGame();
  const [showCounterModal, setShowCounterModal] = useState(false);
  const [counterAmount, setCounterAmount] = useState<number>(Math.floor(offer.offeredPrice * 1.05 / 1000) * 1000);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [feedback, setFeedback] = useState<{ message: string; type: 'success' | 'warning' | 'danger' } | null>(null);
  const [outcomeEffect, setOutcomeEffect] = useState<'success' | 'danger' | 'warning' | null>(null);

  const matchedCar = car || state.garage.find(c => c.marketId === offer.carMarketId);

  const costBasis = matchedCar ? (matchedCar.totalInvestedCost || matchedCar.purchasePrice) : 0;
  const profit = matchedCar ? offer.offeredPrice - costBasis : 0;
  const isLoss = profit < 0;
  const profitPercentage = costBasis > 0 
    ? Math.round((profit / costBasis) * 100) 
    : 0;

  const handleAccept = () => {
    dispatch({ type: 'ACCEPT_OFFER', payload: { offerId: offer.id } });
  };

  const handleReject = () => {
    dispatch({ type: 'REJECT_OFFER', payload: { offerId: offer.id } });
  };

  const handleBargain = (percentageIncrease: number) => {
    const targetPrice = Math.floor((offer.offeredPrice * (1 + percentageIncrease / 100)) / 1000) * 1000;
    setCounterAmount(targetPrice);
  };

  const submitCounterOffer = (isSonFiyat: boolean = false) => {
    if (!matchedCar) return;

    setIsEvaluating(true);
    setOutcomeEffect(null);

    setTimeout(() => {
      setIsEvaluating(false);
      const result = evaluateCounterOffer(offer, matchedCar, counterAmount, state.reputation, isSonFiyat);
      
      if (result.success) {
        setOutcomeEffect('success');
        setFeedback({ message: result.message, type: 'success' });
        setTimeout(() => {
          dispatch({
            type: 'COUNTER_OFFER_RESULT',
            payload: {
              offerId: offer.id,
              newPrice: result.newPrice,
              success: true,
              buyerResponse: result.message,
            },
          });
          setShowCounterModal(false);
          setFeedback(null);
          setOutcomeEffect(null);
        }, 1400);
      } else if (result.walkedAway) {
        setOutcomeEffect('danger');
        setFeedback({ message: result.message, type: 'danger' });
        setTimeout(() => {
          dispatch({
            type: 'COUNTER_OFFER_RESULT',
            payload: {
              offerId: offer.id,
              success: false,
              buyerResponse: result.message,
            },
          });
          setShowCounterModal(false);
          setFeedback(null);
          setOutcomeEffect(null);
        }, 1900);
      } else {
        setOutcomeEffect('warning');
        setFeedback({ message: result.message, type: 'warning' });
        setTimeout(() => {
          dispatch({
            type: 'COUNTER_OFFER_RESULT',
            payload: {
              offerId: offer.id,
              newPrice: result.newPrice,
              success: false,
              buyerResponse: result.message,
            },
          });
          setShowCounterModal(false);
          setFeedback(null);
          setOutcomeEffect(null);
        }, 1600);
      }
    }, 800);
  };

  const getBuyerBadgeColor = (type: string) => {
    switch (type) {
      case 'Ölücü / Fırsatçı Alıcı': return 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800';
      case 'Galeri Esnafı': return 'bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800';
      case 'Acele Alıcı': return 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800';
      case 'Koleksiyoner': return 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800';
      default: return 'bg-orange-100 dark:bg-orange-950/60 text-orange-700 dark:text-orange-300 border-orange-200 dark:border-orange-800';
    }
  };

  const isTutorialTarget = state.tutorialStep === 'bargain_egea' && 
    (offer.id === 'tut_offer_ahmet_egea' || offer.buyerName.includes('Ahmet'));

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.92 }}
      className={`bg-white dark:bg-zinc-900 border rounded-2xl p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between relative overflow-hidden ${
        isTutorialTarget
          ? 'border-orange-500 ring-4 ring-orange-500/50 shadow-xl shadow-orange-500/30'
          : 'border-zinc-200 dark:border-zinc-800'
      }`}
    >
      {/* Tutorial Highlight Banner */}
      {isTutorialTarget && (
        <div className="bg-gradient-to-r from-orange-600 to-amber-500 text-white text-xs font-black px-3 py-1.5 -mx-5 -mt-5 mb-4 text-center flex items-center justify-center gap-1.5 shadow-md uppercase tracking-wider animate-pulse">
          <Sparkles size={14} className="fill-white" />
          <span>👉 5. ADIM: AHMET BEY İLE PAZARLIK YAP (SON FİYAT DE)</span>
        </div>
      )}

      <div>
        {/* Header: Buyer info & badge */}
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-2xl shadow-inner border border-zinc-200 dark:border-zinc-700">
              {offer.buyerAvatar}
            </div>
            <div>
              <h4 className="font-bold text-zinc-900 dark:text-white text-base leading-tight">
                {offer.buyerName}
              </h4>
              <div className="flex items-center gap-2 mt-1">
                <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${getBuyerBadgeColor(offer.buyerType)}`}>
                  {offer.buyerType}
                </span>
                <span className="text-xs text-zinc-400 font-medium">
                  Gün {offer.dayReceived}
                </span>
              </div>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] uppercase font-bold text-zinc-400 block">İlgilendiği Araç</span>
            <div className="flex items-center gap-1.5 font-bold text-sm text-zinc-800 dark:text-zinc-200">
              {offer.carImage && (offer.carImage.startsWith('http') || offer.carImage.startsWith('/') || offer.carImage.startsWith('data:')) ? (
                <img 
                  src={normalizeImageUrl(offer.carImage)} 
                  alt={offer.carName} 
                  referrerPolicy="no-referrer"
                  className="w-6 h-6 rounded-md object-cover flex-shrink-0"
                />
              ) : (
                <span>{offer.carImage}</span>
              )}
              <span className="truncate max-w-[140px]">{offer.carName}</span>
            </div>
          </div>
        </div>

        {/* Message bubble */}
        <div className="bg-zinc-50 dark:bg-zinc-800/60 rounded-xl p-3.5 border border-zinc-100 dark:border-zinc-800 text-sm text-zinc-600 dark:text-zinc-300 relative mb-4 italic leading-relaxed flex gap-2.5 items-start">
          <MessageSquare size={16} className="text-orange-500 flex-shrink-0 mt-0.5" />
          <span>"{offer.message}"</span>
        </div>

        {/* Price & Profit breakdown */}
        <div className="bg-gradient-to-br from-zinc-50 to-orange-50/30 dark:from-zinc-800/40 dark:to-zinc-800/80 p-4 rounded-xl border border-zinc-200 dark:border-zinc-700/60 mb-5">
          <div className="flex items-end justify-between mb-2">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
                Teklif Edilen Tutar
              </span>
              <div className="text-2xl font-black text-orange-600 dark:text-orange-400">
                {formatMoney(offer.offeredPrice)}
              </div>
            </div>
            {matchedCar && (
              <div className="text-right">
                <span className="text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 block">
                  Toplam Maliyet
                </span>
                <span className="text-sm font-bold text-zinc-700 dark:text-zinc-300">
                  {formatMoney(costBasis)}
                </span>
              </div>
            )}
          </div>

          {matchedCar && (
            <div className="pt-2.5 border-t border-zinc-200 dark:border-zinc-700 flex items-center justify-between text-xs">
              <span className="text-zinc-500 font-medium">Finansal Sonuç:</span>
              <span className={`font-black flex items-center gap-1 ${profit >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 px-2 py-0.5 rounded border border-rose-200 dark:border-rose-800'}`}>
                <TrendingUp size={13} className={profit < 0 ? 'rotate-180 text-rose-600' : ''} />
                {profit >= 0 ? `+${formatMoney(profit)} KÂR` : `${formatMoney(Math.abs(profit))} ZARAR`} ({profitPercentage >= 0 ? '+' : ''}{profitPercentage}%)
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-3 gap-2">
        <button
          onClick={handleReject}
          className="py-2.5 px-3 rounded-xl font-bold text-xs text-zinc-600 dark:text-zinc-400 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors flex items-center justify-center gap-1 active:scale-95"
        >
          <X size={15} />
          Reddet
        </button>

        <button
          onClick={() => setShowCounterModal(true)}
          disabled={offer.negotiated}
          className={`py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1 active:scale-95
            ${offer.negotiated 
              ? 'bg-zinc-100 dark:bg-zinc-800 text-zinc-400 cursor-not-allowed' 
              : isTutorialTarget
                ? 'bg-orange-500 hover:bg-orange-600 text-white shadow-lg shadow-orange-500/40 ring-2 ring-white animate-bounce'
                : 'bg-orange-50 dark:bg-orange-950/40 text-orange-600 dark:text-orange-400 border border-orange-200 dark:border-orange-800/60 hover:bg-orange-100 dark:hover:bg-orange-900/40'
            }`}
        >
          <Handshake size={15} />
          {offer.negotiated ? 'Son Fiyat Verildi' : 'Son Fiyat De'}
        </button>

        <button
          onClick={handleAccept}
          className="py-2.5 px-3 rounded-xl font-black text-xs text-white bg-orange-500 hover:bg-orange-600 transition-colors flex items-center justify-center gap-1 shadow-sm active:scale-95"
        >
          <Check size={15} />
          Kabul Et & Sat
        </button>
      </div>

      {/* Counter Offer Modal */}
      <AnimatePresence>
        {showCounterModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop with Color Flash Effect */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{
                opacity: 1,
                backgroundColor:
                  outcomeEffect === 'success'
                    ? 'rgba(16, 185, 129, 0.35)'
                    : outcomeEffect === 'danger'
                    ? 'rgba(239, 68, 68, 0.40)'
                    : outcomeEffect === 'warning'
                    ? 'rgba(245, 158, 11, 0.30)'
                    : 'rgba(9, 9, 11, 0.75)',
              }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="absolute inset-0 backdrop-blur-sm"
              onClick={() => !isEvaluating && setShowCounterModal(false)}
            />

            {/* Modal Dialog with Shake & Border Glow */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={
                outcomeEffect === 'danger'
                  ? {
                      opacity: 1,
                      scale: 1,
                      x: [0, -18, 18, -14, 14, -8, 8, -3, 3, 0],
                      boxShadow: '0 0 50px rgba(239, 68, 68, 0.75), 0 25px 50px -12px rgba(0, 0, 0, 0.5)',
                      borderColor: '#ef4444',
                    }
                  : outcomeEffect === 'success'
                  ? {
                      opacity: 1,
                      scale: [1, 1.03, 1],
                      y: [0, -8, 0],
                      boxShadow: '0 0 60px rgba(16, 185, 129, 0.8), 0 25px 50px -12px rgba(0, 0, 0, 0.5)',
                      borderColor: '#10b981',
                    }
                  : outcomeEffect === 'warning'
                  ? {
                      opacity: 1,
                      scale: [1, 1.01, 1],
                      boxShadow: '0 0 40px rgba(245, 158, 11, 0.65), 0 25px 50px -12px rgba(0, 0, 0, 0.5)',
                      borderColor: '#f59e0b',
                    }
                  : {
                      opacity: 1,
                      scale: 1,
                      x: 0,
                      y: 0,
                      boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.35)',
                      borderColor: 'transparent',
                    }
              }
              exit={{ opacity: 0, scale: 0.95 }}
              transition={
                outcomeEffect === 'danger'
                  ? { duration: 0.5, ease: 'easeInOut' }
                  : outcomeEffect === 'success'
                  ? { duration: 0.45, ease: 'easeOut' }
                  : { duration: 0.25 }
              }
              className="bg-white dark:bg-zinc-900 rounded-2xl p-6 w-full max-w-md shadow-2xl border-2 border-zinc-200 dark:border-zinc-800 relative z-10 overflow-hidden"
            >
              {/* Dynamic Outcome Banner Stamp */}
              <AnimatePresence>
                {outcomeEffect === 'success' && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.5, y: -20, rotate: -4 }}
                    animate={{ opacity: 1, scale: 1, y: 0, rotate: -2 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    className="absolute top-3 right-12 z-20 bg-emerald-500 text-white font-black text-xs px-3 py-1.5 rounded-lg shadow-lg flex items-center gap-1.5 border border-emerald-300 pointer-events-none animate-pulse"
                  >
                    <CheckCircle2 size={15} />
                    EL SIKIŞILDI! (KABUL)
                  </motion.div>
                )}
                {outcomeEffect === 'danger' && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.5, y: -20, rotate: 4 }}
                    animate={{ opacity: 1, scale: 1, y: 0, rotate: 2 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    className="absolute top-3 right-12 z-20 bg-red-600 text-white font-black text-xs px-3 py-1.5 rounded-lg shadow-lg flex items-center gap-1.5 border border-red-400 pointer-events-none animate-bounce"
                  >
                    <XCircle size={15} />
                    MASADAN KALKTI (RED)
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-xl font-black text-zinc-900 dark:text-white flex items-center gap-2">
                    <Handshake className={outcomeEffect === 'success' ? 'text-emerald-500 animate-bounce' : outcomeEffect === 'danger' ? 'text-red-500' : 'text-orange-500'} />
                    Pazarlık Masası
                  </h3>
                  <p className="text-xs text-zinc-500 font-medium mt-0.5">
                    {offer.buyerName} ile karşı teklif pazarlığı yapıyorsunuz.
                  </p>
                </div>
                <button
                  onClick={() => !isEvaluating && setShowCounterModal(false)}
                  disabled={isEvaluating}
                  className="p-1.5 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300 rounded-full"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="bg-zinc-50 dark:bg-zinc-800/50 rounded-xl p-4 mb-4 border border-zinc-100 dark:border-zinc-800">
                <div className="flex justify-between text-xs text-zinc-500 mb-1">
                  <span>Müşterinin Teklifi:</span>
                  <span className="font-bold text-zinc-800 dark:text-zinc-200">{formatMoney(offer.offeredPrice)}</span>
                </div>
                <div className="flex justify-between text-xs text-zinc-500 mb-3">
                  <span>Toplam Maliyetiniz:</span>
                  <span className="font-bold text-zinc-800 dark:text-zinc-200">{matchedCar ? formatMoney(costBasis) : '-'}</span>
                </div>

                <div className="pt-3 border-t border-zinc-200 dark:border-zinc-700">
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-bold uppercase tracking-wider text-zinc-600 dark:text-zinc-300 flex items-center gap-1">
                      <TrendingUp size={13} className="text-orange-500" />
                      Karşı Fiyat Belirle (₺)
                    </label>
                    <span className="text-[11px] font-bold text-orange-600 dark:text-orange-400">
                      {counterAmount > offer.offeredPrice 
                        ? `+${formatMoney(counterAmount - offer.offeredPrice)} (+%${Math.round(((counterAmount - offer.offeredPrice) / offer.offeredPrice) * 100)})` 
                        : ''}
                    </span>
                  </div>

                  <div className="relative">
                    <input
                      type="number"
                      step={1000}
                      min={offer.offeredPrice}
                      disabled={isEvaluating || !!outcomeEffect}
                      value={counterAmount || ''}
                      onChange={(e) => {
                        const val = parseInt(e.target.value) || 0;
                        setCounterAmount(val);
                      }}
                      className="w-full bg-white dark:bg-zinc-900 border-2 border-orange-500/40 focus:border-orange-500 rounded-xl px-3.5 py-2 text-xl font-black text-orange-600 dark:text-orange-400 outline-none shadow-inner disabled:opacity-70"
                      placeholder="Örn: 340000"
                    />
                    <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-zinc-400 pointer-events-none">
                      TRY
                    </span>
                  </div>
                </div>
              </div>

              {/* Quick bump buttons */}
              <div className="mb-5">
                <span className="text-xs font-semibold text-zinc-500 block mb-2">Hızlı Fiyat Seçenekleri:</span>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    disabled={isEvaluating || !!outcomeEffect}
                    onClick={() => handleBargain(4)}
                    className="py-2 px-2 rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-[11px] font-bold text-zinc-800 dark:text-zinc-200 hover:border-orange-500 hover:text-orange-500 transition-colors disabled:opacity-50"
                  >
                    + %4 (Güvenli)
                  </button>
                  <button
                    type="button"
                    disabled={isEvaluating || !!outcomeEffect}
                    onClick={() => handleBargain(8)}
                    className="py-2 px-2 rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-[11px] font-bold text-zinc-800 dark:text-zinc-200 hover:border-orange-500 hover:text-orange-500 transition-colors disabled:opacity-50"
                  >
                    + %8 (Dengeli)
                  </button>
                  <button
                    type="button"
                    disabled={isEvaluating || !!outcomeEffect}
                    onClick={() => handleBargain(15)}
                    className="py-2 px-2 rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-[11px] font-bold text-zinc-800 dark:text-zinc-200 hover:border-orange-500 hover:text-orange-500 transition-colors disabled:opacity-50"
                  >
                    + %15 (Esnaf Pazarlığı)
                  </button>
                </div>
              </div>

              {/* Feedback Alert */}
              <AnimatePresence>
                {feedback && (
                  <motion.div
                    initial={{ opacity: 0, y: -5, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className={`p-3.5 rounded-xl text-xs font-semibold mb-4 flex items-center gap-2 shadow-sm
                      ${feedback.type === 'success' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-200 border-2 border-emerald-500' : ''}
                      ${feedback.type === 'warning' ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-200 border-2 border-amber-500' : ''}
                      ${feedback.type === 'danger' ? 'bg-red-100 text-red-800 dark:bg-red-950/80 dark:text-red-200 border-2 border-red-500' : ''}
                    `}
                  >
                    {feedback.type === 'success' ? (
                      <CheckCircle2 size={18} className="text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
                    ) : feedback.type === 'danger' ? (
                      <XCircle size={18} className="text-red-600 dark:text-red-400 flex-shrink-0" />
                    ) : (
                      <MessageSquare size={18} className="text-amber-600 dark:text-amber-400 flex-shrink-0" />
                    )}
                    <span>{feedback.message}</span>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Action buttons: Pazarlık Et vs Son Fiyatım Bu */}
              <div className="space-y-2">
                <motion.button
                  type="button"
                  onClick={() => submitCounterOffer(true)}
                  disabled={isEvaluating || !!outcomeEffect || counterAmount <= offer.offeredPrice}
                  animate={
                    outcomeEffect === 'success'
                      ? { scale: [1, 1.05, 1], backgroundColor: '#10b981', boxShadow: '0 0 25px rgba(16, 185, 129, 0.7)' }
                      : outcomeEffect === 'danger'
                      ? { scale: [1, 0.98, 1], backgroundColor: '#dc2626', x: [0, -8, 8, -4, 4, 0], boxShadow: '0 0 25px rgba(239, 68, 68, 0.7)' }
                      : {}
                  }
                  className={`w-full py-3 px-4 rounded-xl font-black text-white transition-all flex items-center justify-center gap-2 text-sm shadow-md active:scale-95 disabled:opacity-50
                    ${outcomeEffect === 'success' ? 'bg-emerald-500 shadow-emerald-500/40' : outcomeEffect === 'danger' ? 'bg-red-600 shadow-red-500/40' : 'bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 shadow-orange-500/20'}
                  `}
                  title="Müşteriye 'Son Fiyatım Bu, ister al ister alma' de"
                >
                  {isEvaluating ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : outcomeEffect === 'success' ? (
                    <>
                      <CheckCircle2 size={18} className="animate-bounce" />
                      <span>Kabul Edildi! ({formatMoney(counterAmount)})</span>
                    </>
                  ) : outcomeEffect === 'danger' ? (
                    <>
                      <XCircle size={18} />
                      <span>Reddedildi!</span>
                    </>
                  ) : (
                    <>
                      <Handshake size={17} />
                      <span>"{formatMoney(counterAmount)}" Son Fiyatım Bu!</span>
                    </>
                  )}
                </motion.button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setShowCounterModal(false)}
                    disabled={isEvaluating || !!outcomeEffect}
                    className="py-2.5 px-3 rounded-xl font-bold text-zinc-600 dark:text-zinc-400 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors text-xs disabled:opacity-50"
                  >
                    Vazgeç
                  </button>
                  <button
                    type="button"
                    onClick={() => submitCounterOffer(false)}
                    disabled={isEvaluating || !!outcomeEffect || counterAmount <= offer.offeredPrice}
                    className="py-2.5 px-3 rounded-xl font-bold text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/40 border border-orange-200 dark:border-orange-800 hover:bg-orange-100 transition-colors text-xs disabled:opacity-50"
                  >
                    Teklifi Sor
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
