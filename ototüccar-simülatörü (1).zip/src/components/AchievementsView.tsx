import React, { useState, useMemo } from 'react';
import { useGame } from '../store/GameContext';
import { ACHIEVEMENTS_DATA, Achievement, AchievementCategory, AchievementRarity } from '../data/achievements';
import { CAR_DATABASE } from '../data/cars';
import { formatMoney } from '../utils';
import { 
  Trophy, 
  Award, 
  Sparkles, 
  CheckCircle2, 
  Gift, 
  Lock, 
  ShieldCheck, 
  TrendingUp, 
  ShoppingCart, 
  Handshake, 
  Car, 
  Coins, 
  Banknote, 
  Wrench, 
  Paintbrush, 
  Layers, 
  Crown, 
  Building2, 
  Zap, 
  Star,
  Check,
  ChevronRight,
  Filter,
  Medal
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const getAchievementIcon = (iconName: string, className: string = "w-6 h-6") => {
  switch (iconName) {
    case 'ShoppingCart': return <ShoppingCart className={className} />;
    case 'Handshake': return <Handshake className={className} />;
    case 'Car': return <Car className={className} />;
    case 'Trophy': return <Trophy className={className} />;
    case 'Coins': return <Coins className={className} />;
    case 'TrendingUp': return <TrendingUp className={className} />;
    case 'Banknote': return <Banknote className={className} />;
    case 'Wrench': return <Wrench className={className} />;
    case 'Paintbrush': return <Paintbrush className={className} />;
    case 'Sparkles': return <Sparkles className={className} />;
    case 'Layers': return <Layers className={className} />;
    case 'Crown': return <Crown className={className} />;
    case 'Building2': return <Building2 className={className} />;
    case 'Zap': return <Zap className={className} />;
    case 'ShieldCheck': return <ShieldCheck className={className} />;
    case 'Award': return <Award className={className} />;
    default: return <Star className={className} />;
  }
};

const getRarityStyles = (rarity: AchievementRarity) => {
  switch (rarity) {
    case 'bronze':
      return {
        label: 'Bronz',
        badge: 'bg-amber-900/20 text-amber-700 dark:text-amber-400 border-amber-700/30',
        border: 'border-amber-700/20',
        glow: 'from-amber-600/10 to-transparent',
        progress: 'bg-amber-600',
        starColor: 'text-amber-600',
      };
    case 'silver':
      return {
        label: 'Gümüş',
        badge: 'bg-slate-500/20 text-slate-700 dark:text-slate-300 border-slate-400/30',
        border: 'border-slate-400/30',
        glow: 'from-slate-400/10 to-transparent',
        progress: 'bg-slate-400',
        starColor: 'text-slate-400',
      };
    case 'gold':
      return {
        label: 'Altın',
        badge: 'bg-yellow-500/20 text-yellow-700 dark:text-yellow-400 border-yellow-500/40',
        border: 'border-yellow-500/30',
        glow: 'from-yellow-500/15 to-transparent',
        progress: 'bg-gradient-to-r from-amber-500 to-yellow-400',
        starColor: 'text-yellow-500',
      };
    case 'diamond':
      return {
        label: 'Elmas',
        badge: 'bg-cyan-500/20 text-cyan-700 dark:text-cyan-400 border-cyan-500/40',
        border: 'border-cyan-500/40',
        glow: 'from-cyan-500/20 to-transparent',
        progress: 'bg-gradient-to-r from-cyan-500 to-blue-500',
        starColor: 'text-cyan-400',
      };
    case 'legendary':
    default:
      return {
        label: 'Efsanevi',
        badge: 'bg-purple-500/20 text-purple-700 dark:text-purple-300 border-purple-500/40 animate-pulse',
        border: 'border-purple-500/50',
        glow: 'from-purple-600/20 via-pink-500/10 to-transparent',
        progress: 'bg-gradient-to-r from-purple-600 via-pink-500 to-amber-400',
        starColor: 'text-purple-400',
      };
  }
};

const CATEGORIES: { id: 'all' | AchievementCategory; label: string }[] = [
  { id: 'all', label: 'Tüm Görevler' },
  { id: 'trade', label: 'Ticaret & Satış' },
  { id: 'profit', label: 'Kâr & Sermaye' },
  { id: 'workshop', label: 'Sanayi & Bakım' },
  { id: 'collection', label: 'Koleksiyon' },
  { id: 'empire', label: 'İmparatorluk' },
];

export const AchievementsView: React.FC = () => {
  const { state, dispatch } = useGame();
  const [activeCategory, setActiveCategory] = useState<'all' | AchievementCategory>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'claimable' | 'claimed' | 'in_progress'>('all');
  const [claimedToast, setClaimedToast] = useState<string | null>(null);

  const totalCatalogModels = useMemo(() => {
    return new Set(CAR_DATABASE.map(c => `${c.brand.trim().toLowerCase()}_${c.model.trim().toLowerCase()}`)).size;
  }, []);

  const claimedSet = useMemo(() => {
    return new Set(state.claimedAchievementIds || []);
  }, [state.claimedAchievementIds]);

  // Compute status for all achievements
  const evaluatedAchievements = useMemo(() => {
    return ACHIEVEMENTS_DATA.map(item => {
      const progress = item.getProgress(state, totalCatalogModels);
      const isClaimed = claimedSet.has(item.id);
      const isReadyToClaim = progress.isCompleted && !isClaimed;
      const isInProgress = !progress.isCompleted;

      return {
        ...item,
        progress,
        isClaimed,
        isReadyToClaim,
        isInProgress,
      };
    });
  }, [state, totalCatalogModels, claimedSet]);

  const claimableCount = evaluatedAchievements.filter(a => a.isReadyToClaim).length;
  const claimedCount = evaluatedAchievements.filter(a => a.isClaimed).length;
  const totalCount = evaluatedAchievements.length;
  const totalPercent = Math.round((claimedCount / totalCount) * 100);

  // Unlocked title badges
  const unlockedBadges = evaluatedAchievements
    .filter(a => a.isClaimed && a.reward.badgeTitle)
    .map(a => ({ title: a.reward.badgeTitle!, rarity: a.rarity, icon: a.icon }));

  // Handle single claim
  const handleClaim = (achievement: typeof evaluatedAchievements[0]) => {
    if (!achievement.isReadyToClaim) return;

    dispatch({
      type: 'CLAIM_ACHIEVEMENT',
      payload: {
        achievementId: achievement.id,
        moneyReward: achievement.reward.money,
        reputationReward: achievement.reward.reputation,
        title: achievement.title,
      },
    });

    setClaimedToast(`Tebrikler! '${achievement.title}' ödülü alındı.`);
    setTimeout(() => setClaimedToast(null), 3500);
  };

  // Handle claim all
  const handleClaimAll = () => {
    const readyItems = evaluatedAchievements.filter(a => a.isReadyToClaim);
    if (readyItems.length === 0) return;

    readyItems.forEach(item => {
      dispatch({
        type: 'CLAIM_ACHIEVEMENT',
        payload: {
          achievementId: item.id,
          moneyReward: item.reward.money,
          reputationReward: item.reward.reputation,
          title: item.title,
        },
      });
    });

    setClaimedToast(`${readyItems.length} adet başarım ödülü başarıyla tahsil edildi!`);
    setTimeout(() => setClaimedToast(null), 4000);
  };

  // Filtered achievements
  const filteredList = useMemo(() => {
    return evaluatedAchievements.filter(item => {
      if (activeCategory !== 'all' && item.category !== activeCategory) {
        return false;
      }
      if (statusFilter === 'claimable' && !item.isReadyToClaim) {
        return false;
      }
      if (statusFilter === 'claimed' && !item.isClaimed) {
        return false;
      }
      if (statusFilter === 'in_progress' && !item.isInProgress) {
        return false;
      }
      return true;
    });
  }, [evaluatedAchievements, activeCategory, statusFilter]);

  return (
    <div className="space-y-6" id="achievements-view">
      {/* Hero Header Banner */}
      <div className="bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 text-white rounded-2xl p-6 sm:p-8 border border-zinc-700/60 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute left-1/4 bottom-0 w-64 h-64 bg-purple-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="p-2 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-xl">
                <Trophy size={22} />
              </span>
              <span className="text-xs uppercase tracking-widest font-black text-amber-400">
                Onur Listesi & Görevler
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Galeri Başarımları & Rozetler
            </h1>
            <p className="text-sm text-zinc-300 mt-2 max-w-2xl font-medium leading-relaxed">
              Otomotiv piyasasında hedefleri tamamlayın, prestijli rozetler ve devasa nakit ödüller kazanın. Her başarım galerinizin itibarını ve sermayesini katlar.
            </p>
          </div>

          {/* Quick Stats & Claim All Action */}
          <div className="bg-zinc-800/80 backdrop-blur-md border border-zinc-700 p-4 rounded-xl flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full md:w-auto shrink-0 shadow-lg">
            <div className="flex items-center gap-5">
              <div>
                <p className="text-xs text-zinc-400 font-medium">Kazanılan Rozet</p>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="text-2xl font-black text-amber-400">{claimedCount}</span>
                  <span className="text-xs text-zinc-400">/ {totalCount}</span>
                </div>
                {/* Progress bar */}
                <div className="w-28 h-2 bg-zinc-700 rounded-full mt-1.5 overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full transition-all duration-500"
                    style={{ width: `${totalPercent}%` }}
                  />
                </div>
              </div>

              <div className="h-10 w-px bg-zinc-700" />

              <div>
                <p className="text-xs text-zinc-400 font-medium">Hazır Ödül</p>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className={`text-2xl font-black ${claimableCount > 0 ? 'text-emerald-400 animate-pulse' : 'text-zinc-400'}`}>
                    {claimableCount}
                  </span>
                  <span className="text-xs text-zinc-400">Bekliyor</span>
                </div>
                <p className="text-[11px] text-zinc-400 mt-1 font-semibold">
                  %{totalPercent} Tamamlandı
                </p>
              </div>
            </div>

            {claimableCount > 0 && (
              <button
                onClick={handleClaimAll}
                className="bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-black text-xs px-4 py-2.5 rounded-xl transition-all shadow-md shadow-emerald-600/30 flex items-center justify-center gap-1.5 shrink-0"
              >
                <Gift size={15} />
                Tümünü Al ({claimableCount})
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Claimed Toast Alert */}
      <AnimatePresence>
        {claimedToast && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 rounded-2xl flex items-center justify-between gap-3 text-emerald-800 dark:text-emerald-300 shadow-sm"
          >
            <div className="flex items-center gap-2.5">
              <CheckCircle2 size={20} className="text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span className="text-sm font-bold">{claimedToast}</span>
            </div>
            <button 
              onClick={() => setClaimedToast(null)}
              className="text-xs font-black uppercase text-emerald-700 dark:text-emerald-400 hover:underline"
            >
              Kapat
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Unlocked Badges Trophy Shelf */}
      {unlockedBadges.length > 0 && (
        <div className="bg-gradient-to-r from-amber-500/5 via-yellow-500/5 to-transparent dark:from-amber-950/20 dark:via-yellow-950/10 border border-amber-200 dark:border-amber-900/40 rounded-2xl p-4 sm:p-5">
          <div className="flex items-center gap-2 mb-3">
            <Medal size={18} className="text-amber-500" />
            <h3 className="text-xs uppercase font-black tracking-wider text-amber-700 dark:text-amber-400">
              Kazanılan Unvanlar & Şeref Rozetleri ({unlockedBadges.length})
            </h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {unlockedBadges.map((badge, idx) => {
              const rarityStyle = getRarityStyles(badge.rarity);
              return (
                <div
                  key={idx}
                  className="flex items-center gap-2 bg-white dark:bg-zinc-900 border border-amber-200/80 dark:border-amber-800/50 px-3 py-1.5 rounded-xl shadow-xs"
                >
                  <span className="text-amber-500">
                    {getAchievementIcon(badge.icon, "w-4 h-4")}
                  </span>
                  <span className="text-xs font-black text-zinc-900 dark:text-white">
                    {badge.title}
                  </span>
                  <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded border ${rarityStyle.badge}`}>
                    {rarityStyle.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Filter Tabs and Status Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-zinc-900 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-sm">
        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto max-w-full pb-1 sm:pb-0 scrollbar-none">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-2 rounded-xl text-xs font-black transition-all whitespace-nowrap ${
                activeCategory === cat.id
                  ? 'bg-zinc-900 text-white dark:bg-white dark:text-zinc-900 shadow-sm'
                  : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Status Filter */}
        <div className="flex items-center gap-1 self-end sm:self-auto shrink-0 bg-zinc-100 dark:bg-zinc-800 p-1 rounded-xl">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
              statusFilter === 'all'
                ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-xs'
                : 'text-zinc-500 dark:text-zinc-400'
            }`}
          >
            Tümü
          </button>
          <button
            onClick={() => setStatusFilter('claimable')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
              statusFilter === 'claimable'
                ? 'bg-white dark:bg-zinc-700 text-emerald-600 dark:text-emerald-400 shadow-xs'
                : 'text-zinc-500 dark:text-zinc-400'
            }`}
          >
            <Gift size={12} />
            Ödül Hazır ({claimableCount})
          </button>
          <button
            onClick={() => setStatusFilter('claimed')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
              statusFilter === 'claimed'
                ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-xs'
                : 'text-zinc-500 dark:text-zinc-400'
            }`}
          >
            Alınanlar
          </button>
        </div>
      </div>

      {/* Achievements Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredList.map((item) => {
          const rarity = getRarityStyles(item.rarity);
          const isReady = item.isReadyToClaim;
          const isClaimed = item.isClaimed;

          return (
            <div
              key={item.id}
              id={`achievement-${item.id}`}
              className={`bg-white dark:bg-zinc-900 rounded-2xl border transition-all p-5 flex flex-col justify-between relative overflow-hidden group shadow-sm hover:shadow-md ${
                isReady
                  ? 'border-emerald-500/60 ring-2 ring-emerald-500/20'
                  : isClaimed
                    ? 'border-zinc-200 dark:border-zinc-800 opacity-90'
                    : 'border-zinc-200 dark:border-zinc-800'
              }`}
            >
              {/* Subtle top background glow */}
              <div className={`absolute -right-10 -top-10 w-40 h-40 bg-gradient-to-br ${rarity.glow} rounded-full blur-2xl pointer-events-none`} />

              <div>
                {/* Header: Icon, Rarity Badge & Status Tag */}
                <div className="flex items-start justify-between gap-3">
                  <div className={`p-3 rounded-2xl border ${rarity.badge} flex items-center justify-center shrink-0`}>
                    {getAchievementIcon(item.icon, "w-6 h-6")}
                  </div>

                  <div className="flex flex-col items-end gap-1.5">
                    <span className={`text-[11px] font-black px-2.5 py-0.5 rounded-full border uppercase tracking-wider ${rarity.badge}`}>
                      {rarity.label}
                    </span>

                    {isClaimed ? (
                      <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 size={13} /> Tamamlandı
                      </span>
                    ) : isReady ? (
                      <span className="text-[11px] font-black text-emerald-500 flex items-center gap-1 animate-pulse">
                        <Sparkles size={13} /> ÖDÜL HAZIR
                      </span>
                    ) : (
                      <span className="text-[11px] font-medium text-zinc-400 flex items-center gap-1">
                        <Lock size={12} /> Kilitli
                      </span>
                    )}
                  </div>
                </div>

                {/* Title & Description */}
                <h3 className="text-base font-black text-zinc-900 dark:text-white mt-4 group-hover:text-amber-500 dark:group-hover:text-amber-400 transition-colors">
                  {item.title}
                </h3>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1 font-medium leading-relaxed">
                  {item.description}
                </p>

                {/* Progress Bar & Numerical Value */}
                <div className="mt-4">
                  <div className="flex justify-between items-center text-xs mb-1.5 font-bold">
                    <span className="text-zinc-500 dark:text-zinc-400">İlerleme:</span>
                    <span className={item.progress.isCompleted ? 'text-emerald-600 dark:text-emerald-400 font-black' : 'text-zinc-700 dark:text-zinc-300'}>
                      {item.unit === '₺' ? formatMoney(item.progress.current) : item.progress.current} / {item.unit === '₺' ? formatMoney(item.progress.max) : `${item.progress.max} ${item.unit || ''}`}
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden border border-zinc-200/60 dark:border-zinc-700/60">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${rarity.progress}`}
                      style={{ width: `${item.progress.progressPercent}%` }}
                    />
                  </div>
                </div>

                {/* Reward Package Box */}
                <div className="mt-4 p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/80 dark:border-zinc-700/80 text-xs">
                  <div className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-1 flex items-center gap-1">
                    <Gift size={12} /> Görev Ödülü
                  </div>
                  <div className="flex items-center flex-wrap gap-2 text-xs font-black">
                    {item.reward.money && (
                      <span className="text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-md border border-emerald-200 dark:border-emerald-800">
                        +{formatMoney(item.reward.money)}
                      </span>
                    )}
                    {item.reward.reputation && (
                      <span className="text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 rounded-md border border-blue-200 dark:border-blue-800">
                        +{item.reward.reputation} İtibar
                      </span>
                    )}
                    {item.reward.badgeTitle && (
                      <span className="text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 px-2 py-0.5 rounded-md border border-amber-200 dark:border-amber-800 flex items-center gap-1">
                        <Star size={11} className="fill-amber-500" />
                        "{item.reward.badgeTitle}" Rozeti
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="mt-5 pt-3 border-t border-zinc-100 dark:border-zinc-800">
                {isClaimed ? (
                  <button
                    disabled
                    className="w-full py-2.5 px-3 rounded-xl font-bold text-xs bg-zinc-100 dark:bg-zinc-800 text-zinc-400 dark:text-zinc-500 cursor-default flex items-center justify-center gap-1.5"
                  >
                    <Check size={16} className="text-emerald-500" />
                    Ödül Alındı
                  </button>
                ) : isReady ? (
                  <button
                    onClick={() => handleClaim(item)}
                    className="w-full py-2.5 px-3 rounded-xl font-black text-xs bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white shadow-md shadow-emerald-500/20 active:scale-98 transition-all flex items-center justify-center gap-2 animate-bounce"
                  >
                    <Gift size={16} />
                    Ödülü Topla!
                  </button>
                ) : (
                  <div className="w-full py-2 px-3 rounded-xl text-center text-xs font-bold text-zinc-400 dark:text-zinc-500 bg-zinc-100/60 dark:bg-zinc-800/40">
                    %{item.progress.progressPercent} Tamamlandı
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
