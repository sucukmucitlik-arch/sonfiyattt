import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Car, Gauge, ShieldCheck, ChevronRight, Play } from 'lucide-react';

interface IntroSplashProps {
  onComplete: () => void;
}

export const IntroSplash: React.FC<IntroSplashProps> = ({ onComplete }) => {
  const [stage, setStage] = useState<number>(0);
  const [progress, setProgress] = useState<number>(0);

  useEffect(() => {
    // Stage 0: Initial company presentation "Sucuk Mucitlik A.Ş. Presents"
    const t0 = setTimeout(() => setStage(1), 2200);
    
    // Stage 1: Main Game Title & Car Drive-In Animation
    const t1 = setTimeout(() => setStage(2), 4800);

    return () => {
      clearTimeout(t0);
      clearTimeout(t1);
    };
  }, []);

  // Smooth progress bar fill
  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 2;
      });
    }, 90);

    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.05, filter: 'blur(10px)' }}
      transition={{ duration: 0.8, ease: 'easeInOut' }}
      className="fixed inset-0 z-[100] bg-zinc-950 text-white flex flex-col justify-between p-6 sm:p-12 overflow-hidden select-none"
    >
      {/* Background Animated Gradient Glows */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-orange-600/20 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-10 left-1/4 w-[400px] h-[250px] bg-amber-600/15 rounded-full blur-[100px]" />
        
        {/* Subtle grid pattern */}
        <div 
          className="absolute inset-0 opacity-[0.07]" 
          style={{ 
            backgroundImage: `radial-gradient(circle at 1px 1px, rgba(255,255,255,0.4) 1px, transparent 0)`,
            backgroundSize: '32px 32px' 
          }} 
        />
      </div>

      {/* Top Header / Branding */}
      <div className="relative z-10 flex justify-between items-center w-full max-w-5xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="flex items-center gap-2"
        >
          <div className="w-8 h-8 rounded-lg bg-orange-500/20 border border-orange-500/40 flex items-center justify-center text-orange-400 font-black text-xs">
            SM
          </div>
          <span className="text-xs font-bold tracking-widest uppercase text-zinc-400">
            Sucuk Mucitlik A.Ş. Studios
          </span>
        </motion.div>

        {/* Skip Button */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          onClick={onComplete}
          className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-700 text-xs font-semibold text-zinc-300 hover:text-white transition-all shadow-lg active:scale-95"
        >
          <span>Geç</span>
          <ChevronRight size={14} />
        </motion.button>
      </div>

      {/* Center Cinematic Stage */}
      <div className="relative z-10 flex flex-col items-center justify-center max-w-4xl mx-auto w-full my-auto text-center py-6">
        <AnimatePresence mode="wait">
          {stage === 0 ? (
            /* STAGE 0: Company Intro */
            <motion.div
              key="presents"
              initial={{ opacity: 0, scale: 0.85, filter: 'blur(8px)' }}
              animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
              exit={{ opacity: 0, scale: 1.15, filter: 'blur(10px)' }}
              transition={{ duration: 0.7, ease: 'easeOut' }}
              className="flex flex-col items-center space-y-4"
            >
              <motion.div
                initial={{ scale: 0, rotate: -20 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: 'spring', stiffness: 260, damping: 20, delay: 0.2 }}
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-gradient-to-br from-orange-500 via-red-500 to-amber-600 p-[2px] shadow-[0_0_50px_rgba(249,115,22,0.4)]"
              >
                <div className="w-full h-full bg-zinc-950 rounded-2xl flex items-center justify-center">
                  <span className="text-3xl sm:text-4xl">🥓</span>
                </div>
              </motion.div>

              <div className="space-y-1">
                <motion.h2
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="text-2xl sm:text-4xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-zinc-100 via-orange-200 to-amber-400"
                >
                  SUCUK MUCİTLİK A.Ş.
                </motion.h2>
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.7 }}
                  className="text-xs sm:text-sm uppercase tracking-[0.35em] text-orange-400 font-bold"
                >
                  GURURLA SUNAR • PRESENTS
                </motion.p>
              </div>
            </motion.div>
          ) : (
            /* STAGE 1 & 2: Game Title + Animated Car on Highway */
            <motion.div
              key="game_title"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.8 }}
              className="w-full flex flex-col items-center space-y-8"
            >
              {/* Main Game Title */}
              <div className="space-y-2">
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: 'spring', damping: 15 }}
                  className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-400 text-xs font-bold uppercase tracking-wider mb-2"
                >
                  <Sparkles size={14} className="animate-spin text-amber-400" style={{ animationDuration: '4s' }} />
                  Oto Galeri & Alım Satım Simülasyonu
                </motion.div>

                <motion.h1
                  initial={{ letterSpacing: '0.05em', y: 20 }}
                  animate={{ letterSpacing: '-0.02em', y: 0 }}
                  transition={{ duration: 0.8, ease: 'easeOut' }}
                  className="text-5xl sm:text-7xl md:text-8xl font-black tracking-tight text-white drop-shadow-2xl"
                >
                  SON <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 via-amber-400 to-yellow-500">FİYAT</span>
                </motion.h1>

                <p className="text-zinc-400 text-sm sm:text-base max-w-md mx-auto font-medium">
                  Al, topla, restore et, pazarlık masasında "Son Fiyatım Bu" de ve galeri imparatorluğunu kur!
                </p>
              </div>

              {/* Animated Asphalt Highway & Moving Luxury Car */}
              <div className="relative w-full max-w-2xl h-24 sm:h-28 overflow-hidden rounded-2xl bg-gradient-to-b from-zinc-900 to-zinc-950 border border-zinc-800 shadow-inner flex flex-col justify-end">
                {/* Speed lines in background */}
                <div className="absolute inset-0 flex items-center justify-around opacity-30 pointer-events-none">
                  {[...Array(6)].map((_, i) => (
                    <motion.div
                      key={i}
                      animate={{ x: [300, -300] }}
                      transition={{
                        repeat: Infinity,
                        duration: 1.2,
                        delay: i * 0.2,
                        ease: 'linear',
                      }}
                      className="w-12 h-[1px] bg-gradient-to-r from-transparent via-orange-400 to-transparent"
                    />
                  ))}
                </div>

                {/* Moving Vehicle */}
                <div className="relative w-full h-16 flex items-center">
                  <motion.div
                    initial={{ x: '-30%' }}
                    animate={{ x: ['-20%', '25%', '15%', '45%'] }}
                    transition={{
                      duration: 3.5,
                      ease: 'easeInOut',
                      repeat: Infinity,
                      repeatType: 'reverse',
                    }}
                    className="flex flex-col items-center drop-shadow-[0_10px_20px_rgba(249,115,22,0.4)]"
                  >
                    {/* Headlight Beam */}
                    <div className="relative">
                      <div className="text-4xl sm:text-5xl filter drop-shadow-[0_0_12px_rgba(249,115,22,0.6)] transform scale-x-[-1]">
                        🏎️
                      </div>
                      {/* Headlight ray */}
                      <div 
                        className="absolute right-0 top-1/2 -translate-y-1/2 w-32 h-12 bg-gradient-to-r from-amber-200/40 via-orange-400/10 to-transparent blur-md pointer-events-none rounded-full transform -rotate-3"
                      />
                    </div>
                  </motion.div>
                </div>

                {/* Road Surface & Dashed Lane Lines */}
                <div className="w-full h-3 bg-zinc-800 border-t border-zinc-700 relative overflow-hidden flex items-center">
                  <motion.div
                    animate={{ x: [0, -60] }}
                    transition={{ repeat: Infinity, duration: 0.5, ease: 'linear' }}
                    className="w-[200%] flex gap-6"
                  >
                    {[...Array(20)].map((_, idx) => (
                      <div key={idx} className="w-8 h-1 bg-amber-400/80 rounded-full flex-shrink-0" />
                    ))}
                  </motion.div>
                </div>
              </div>

              {/* Start Button */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={onComplete}
                className="group relative px-8 sm:px-12 py-4 rounded-2xl bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 text-white font-black text-base sm:text-lg shadow-[0_0_35px_rgba(249,115,22,0.45)] flex items-center gap-3 transition-all cursor-pointer"
              >
                <Play size={20} className="fill-white group-hover:translate-x-0.5 transition-transform" />
                <span>GALERİYİ AÇ</span>
                <span className="absolute -top-2 -right-2 bg-emerald-500 text-[10px] font-black uppercase px-2 py-0.5 rounded-full border border-emerald-300">
                  Hazır
                </span>
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Footer Info & Progress Bar */}
      <div className="relative z-10 w-full max-w-md mx-auto flex flex-col items-center space-y-3">
        <div className="w-full bg-zinc-900 rounded-full h-1.5 overflow-hidden border border-zinc-800">
          <motion.div 
            className="h-full bg-gradient-to-r from-orange-500 to-amber-400"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="flex justify-between items-center w-full text-[11px] text-zinc-500 font-medium">
          <span>v2.4 Mobil Galeri</span>
          <span className="flex items-center gap-1 text-zinc-400 font-semibold">
            <ShieldCheck size={13} className="text-emerald-500" />
            Sucuk Mucitlik A.Ş. Güvencesiyle
          </span>
        </div>
      </div>
    </motion.div>
  );
};
