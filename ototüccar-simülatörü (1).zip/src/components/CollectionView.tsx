import React, { useState } from 'react';
import { useGame } from '../store/GameContext';
import { CAR_DATABASE } from '../data/cars';
import { getModelStampKey, formatMoney, formatKm, normalizeImageUrl } from '../utils';
import { Sparkles, Trophy, Award, CheckCircle2, Lock, Star, Search, Filter, Layers } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CarDetailModal } from './CarDetailModal';
import { CarModel, MarketCar } from '../types';

export const CollectionView: React.FC = () => {
  const { state } = useGame();
  const [selectedBrand, setSelectedBrand] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [inspectingCar, setInspectingCar] = useState<MarketCar | null>(null);

  // Total unique models in database
  const totalModelsCount = CAR_DATABASE.length;

  // Set of collected stamps (from state)
  const collectedSet = new Set(state.collectedModelKeys || []);
  const collectedCount = CAR_DATABASE.filter(car => 
    collectedSet.has(getModelStampKey(car.brand, car.model))
  ).length;

  const progressPercentage = Math.round((collectedCount / totalModelsCount) * 100);

  // Unique brands
  const brands = Array.from(new Set(CAR_DATABASE.map(c => c.brand)));

  // Filter cars based on brand and search query
  const filteredCars = CAR_DATABASE.filter(car => {
    const matchesBrand = selectedBrand === 'all' || car.brand === selectedBrand;
    const matchesSearch = searchQuery === '' || 
      `${car.brand} ${car.model} ${car.series || ''}`.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesBrand && matchesSearch;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner & Stamp Progress Card */}
      <div className="bg-gradient-to-br from-orange-500 via-amber-500 to-yellow-500 rounded-3xl p-6 sm:p-8 text-white shadow-xl shadow-orange-500/15 relative overflow-hidden">
        {/* Subtle background stamps graphic */}
        <div className="absolute -right-8 -bottom-8 opacity-15 pointer-events-none transform rotate-12">
          <Trophy size={240} />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-black uppercase tracking-wider">
              <Sparkles size={14} className="text-yellow-200" />
              Araç Koleksiyon Albümü
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
              Galeri Araç Koleksiyonu & Pulları
            </h2>
            <p className="text-white/90 text-sm max-w-xl font-medium leading-relaxed">
              Piyasadan satın aldığınız her farklı model için koleksiyon pulu kazanırsınız. Pazardaki tüm modelleri toplayıp efsanevi otomobil koleksiyoneri unvanına ulaşın!
            </p>
          </div>

          {/* Large Stamp Counter Pill */}
          <div className="bg-white/95 dark:bg-zinc-900/95 text-zinc-900 dark:text-white p-5 rounded-2xl shadow-lg border border-white/40 flex items-center gap-4 sm:min-w-[240px]">
            <div className="w-14 h-14 bg-gradient-to-tr from-orange-500 to-amber-400 rounded-2xl flex items-center justify-center text-white shadow-md flex-shrink-0">
              <Award size={32} />
            </div>
            <div>
              <div className="text-xs font-bold text-zinc-400 uppercase tracking-wider">
                Toplanan Pul
              </div>
              <div className="text-2xl sm:text-3xl font-black text-orange-600 dark:text-orange-400 flex items-baseline gap-1">
                <span>{collectedCount}</span>
                <span className="text-sm font-bold text-zinc-400">/ {totalModelsCount} Pul</span>
              </div>
              <div className="text-xs font-bold text-emerald-600 dark:text-emerald-400 mt-0.5">
                %{progressPercentage} Tamamlandı
              </div>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mt-6 space-y-2 relative z-10">
          <div className="flex justify-between text-xs font-bold text-white/90">
            <span>Koleksiyon İlerlemesi</span>
            <span>{totalModelsCount} Araçta {collectedCount} Model Kazanıldı</span>
          </div>
          <div className="w-full h-3.5 bg-black/20 backdrop-blur-sm rounded-full overflow-hidden p-0.5 border border-white/20">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${progressPercentage}%` }}
              transition={{ duration: 0.8, ease: 'easeOut' }}
              className="h-full bg-gradient-to-r from-yellow-300 to-white rounded-full shadow-sm"
            />
          </div>
        </div>
      </div>

      {/* Brand Filters and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
        {/* Search */}
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
          <input
            type="text"
            placeholder="Model veya marka ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl text-sm font-medium text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all"
          />
        </div>

        {/* Brand Selector Pills (Horizontally Scrollable) */}
        <div className="w-full sm:w-auto flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-hide max-w-full">
          <button
            onClick={() => setSelectedBrand('all')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              selectedBrand === 'all'
                ? 'bg-orange-500 text-white shadow-sm'
                : 'bg-white dark:bg-zinc-900 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 border border-zinc-200 dark:border-zinc-800'
            }`}
          >
            Tüm Markalar ({CAR_DATABASE.length})
          </button>
          {brands.map(brand => {
            const brandModels = CAR_DATABASE.filter(c => c.brand === brand);
            const brandCollected = brandModels.filter(c => collectedSet.has(getModelStampKey(c.brand, c.model))).length;
            const isCompleted = brandCollected === brandModels.length;

            return (
              <button
                key={brand}
                onClick={() => setSelectedBrand(brand)}
                className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  selectedBrand === brand
                    ? 'bg-orange-500 text-white shadow-sm'
                    : 'bg-white dark:bg-zinc-900 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 border border-zinc-200 dark:border-zinc-800'
                }`}
              >
                <span>{brand}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                  isCompleted 
                    ? 'bg-emerald-500 text-white' 
                    : selectedBrand === brand ? 'bg-orange-600 text-white' : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-500'
                }`}>
                  {brandCollected}/{brandModels.length}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Stamps Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {filteredCars.map((car, index) => {
          const stampKey = getModelStampKey(car.brand, car.model);
          const isCollected = collectedSet.has(stampKey);

          return (
            <motion.div
              key={`${car.brand}_${car.model}_${index}`}
              whileHover={{ y: -3 }}
              onClick={() => {
                // Convert CarModel to dummy MarketCar for inspection view
                const previewCar: MarketCar = {
                  ...car,
                  marketId: `preview_${stampKey}`,
                  km: 45000,
                  condition: 'Temiz',
                  price: car.basePrice,
                  adTitle: `${car.year} ${car.brand} ${car.model} ${car.series || ''}`,
                };
                setInspectingCar(previewCar);
              }}
              className={`relative rounded-2xl border p-4 transition-all duration-300 cursor-pointer overflow-hidden flex flex-col justify-between ${
                isCollected
                  ? 'bg-white dark:bg-zinc-900 border-amber-300 dark:border-amber-700/60 shadow-md shadow-amber-500/5 ring-1 ring-amber-400/30'
                  : 'bg-zinc-50/70 dark:bg-zinc-900/40 border-dashed border-zinc-300 dark:border-zinc-800 opacity-70 grayscale hover:grayscale-0 hover:opacity-100'
              }`}
            >
              {/* Stamp Corner Ribbon / Badge */}
              <div className="flex justify-between items-start mb-3">
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400">
                  {car.brand}
                </span>

                {isCollected ? (
                  <span className="inline-flex items-center gap-1 bg-amber-500 text-white text-[11px] font-black px-2 py-0.5 rounded-full shadow-sm">
                    <Star size={11} className="fill-white" /> Pul Kazanıldı
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 bg-zinc-200 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 text-[10px] font-bold px-2 py-0.5 rounded-full">
                    <Lock size={10} /> Henüz Alınmadı
                  </span>
                )}
              </div>

              {/* Stamp Car Visual */}
              <div className="h-32 bg-gradient-to-b from-zinc-100 to-zinc-200 dark:from-zinc-800 dark:to-zinc-850/80 rounded-xl relative flex items-center justify-center p-3 mb-3 overflow-hidden">
                {car.image && (car.image.startsWith('http') || car.image.startsWith('/') || car.image.startsWith('data:')) ? (
                  <img
                    src={normalizeImageUrl(car.image)}
                    alt={`${car.brand} ${car.model}`}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover rounded-lg"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                ) : (
                  <span className="text-6xl drop-shadow-md select-none">{car.image || '🚗'}</span>
                )}

                {/* Stamp Postal Outline Effect if Collected */}
                {isCollected && (
                  <div className="absolute inset-0 border-2 border-amber-400/40 rounded-xl pointer-events-none" />
                )}
              </div>

              {/* Info */}
              <div>
                <h4 className="font-black text-sm sm:text-base text-zinc-900 dark:text-white leading-tight">
                  {car.brand} {car.model}
                </h4>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5 truncate">
                  {car.series || car.engine.name} • {car.year}
                </p>

                <div className="mt-3 pt-2.5 border-t border-zinc-100 dark:border-zinc-800 flex justify-between items-center text-xs">
                  <span className="text-zinc-400 font-medium">Katalog Değeri</span>
                  <span className="font-black text-zinc-800 dark:text-zinc-200">
                    {formatMoney(car.basePrice)}
                  </span>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Inspect Modal */}
      {inspectingCar && (
        <CarDetailModal
          car={inspectingCar}
          isOpen={!!inspectingCar}
          onClose={() => setInspectingCar(null)}
        />
      )}
    </div>
  );
};
