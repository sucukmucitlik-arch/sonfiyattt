import { CAR_DATABASE } from './data/cars';
import { MarketCar, PlayerCar, Condition, CustomerOffer, BuyerType, CarInspection, PartStatus, EngineSpec, CarModel, InspectionPartKey, SellerType, DealGrade, TradeReport } from './types';

let _uniqueIdCounter = 0;
export const generateUniqueId = (prefix: string = 'id'): string => {
  _uniqueIdCounter += 1;
  const time = Date.now();
  const rand = Math.random().toString(36).substring(2, 9);
  return `${prefix}_${time}_${rand}_${_uniqueIdCounter}`;
};

export const formatMoney = (amount: number): string => {
  return new Intl.NumberFormat('tr-TR', {
    style: 'currency',
    currency: 'TRY',
    maximumFractionDigits: 0,
  }).format(amount);
};

export const formatKm = (km: number): string => {
  return new Intl.NumberFormat('tr-TR').format(km) + ' km';
};

export const normalizeImageUrl = (url?: string): string => {
  if (!url) return '';
  const trimmed = url.trim();
  // Hizliresim page link to direct image link conversion
  if (trimmed.includes('hizliresim.com/') && !trimmed.includes('i.hizliresim.com/')) {
    const parts = trimmed.split('hizliresim.com/');
    const id = parts[1]?.replace('/', '');
    if (id) {
      return `https://i.hizliresim.com/${id}.jpg`;
    }
  }
  return trimmed;
};

const ALL_PARTS: InspectionPartKey[] = [
  'kaput',
  'tavan',
  'bagaj',
  'solOnCamurluk',
  'solOnKapi',
  'solArkaKapi',
  'solArkaCamurluk',
  'sagOnCamurluk',
  'sagOnKapi',
  'sagArkaKapi',
  'sagArkaCamurluk',
  'onTampon',
  'arkaTampon',
];

export const PART_NAMES: Record<InspectionPartKey, string> = {
  kaput: 'Ön Kaput',
  tavan: 'Tavan',
  bagaj: 'Bagaj Kapağı',
  solOnCamurluk: 'Sol Ön Çamurluk',
  solOnKapi: 'Sol Ön Kapı',
  solArkaKapi: 'Sol Arka Kapı',
  solArkaCamurluk: 'Sol Arka Çamurluk',
  sagOnCamurluk: 'Sağ Ön Çamurluk',
  sagOnKapi: 'Sağ Ön Kapı',
  sagArkaKapi: 'Sağ Arka Kapı',
  sagArkaCamurluk: 'Sağ Arka Çamurluk',
  onTampon: 'Ön Tampon',
  arkaTampon: 'Arka Tampon',
};

export const DEFAULT_INSPECTION: CarInspection = {
  kaput: 'original',
  tavan: 'original',
  bagaj: 'original',
  solOnCamurluk: 'original',
  solOnKapi: 'original',
  solArkaKapi: 'original',
  solArkaCamurluk: 'original',
  sagOnCamurluk: 'original',
  sagOnKapi: 'original',
  sagArkaKapi: 'original',
  sagArkaCamurluk: 'original',
  onTampon: 'original',
  arkaTampon: 'original',
  agirHasarKayitli: false,
  tramerTutar: 0,
};

export const ensureInspection = (inspection?: Partial<CarInspection> | null, condition?: Condition): CarInspection => {
  if (!inspection) {
    return generateInspection(condition || 'Temiz');
  }
  return {
    kaput: inspection.kaput || 'original',
    tavan: inspection.tavan || 'original',
    bagaj: inspection.bagaj || 'original',
    solOnCamurluk: inspection.solOnCamurluk || 'original',
    solOnKapi: inspection.solOnKapi || 'original',
    solArkaKapi: inspection.solArkaKapi || 'original',
    solArkaCamurluk: inspection.solArkaCamurluk || 'original',
    sagOnCamurluk: inspection.sagOnCamurluk || 'original',
    sagOnKapi: inspection.sagOnKapi || 'original',
    sagArkaKapi: inspection.sagArkaKapi || 'original',
    sagArkaCamurluk: inspection.sagArkaCamurluk || 'original',
    onTampon: inspection.onTampon || 'original',
    arkaTampon: inspection.arkaTampon || 'original',
    agirHasarKayitli: Boolean(inspection.agirHasarKayitli ?? (condition === 'Ağır Hasarlı')),
    tramerTutar: typeof inspection.tramerTutar === 'number' ? inspection.tramerTutar : 0,
  };
};

export const ensureEngine = (engine?: Partial<EngineSpec> | null): EngineSpec => {
  return {
    name: engine?.name || '1.6 Motor',
    fuelType: (engine?.fuelType as any) || 'Benzin',
    transmission: (engine?.transmission as any) || 'Manuel',
    motorGucu: engine?.motorGucu || '110 hp',
    motorHacmi: engine?.motorHacmi || '1598 cc',
    cekis: (engine?.cekis as any) || 'Önden Çekiş',
    hizlanma: engine?.hizlanma || '11.0 sn',
    azamiSurat: engine?.azamiSurat || '185 km/saat',
    yakitTuketimi: engine?.yakitTuketimi || '6.0 lt / 100km',
  };
};

export const ensureCar = <T extends MarketCar | PlayerCar>(car: any): T => {
  if (!car) return car;
  const condition: Condition = car.condition || 'Temiz';
  const inspection = ensureInspection(car.inspection, condition);
  const engine = ensureEngine(car.engine);

  const dbMatch = CAR_DATABASE.find(c => c.brand === car.brand && c.model === car.model && c.image && c.image.startsWith('http'));
  const image = (car.image && (car.image.startsWith('http') || car.image.startsWith('/') || car.image.startsWith('data:'))) 
    ? car.image 
    : (dbMatch?.image || car.image || '🚗');

  return {
    ...car,
    brand: car.brand || 'Otomobil',
    model: car.model || 'Model',
    series: car.series || '',
    year: car.year || 2020,
    basePrice: car.basePrice || car.price || 500000,
    price: car.price || car.basePrice || 500000,
    km: typeof car.km === 'number' ? car.km : 100000,
    type: car.type || 'Sedan',
    image,
    color: car.color || 'Beyaz',
    condition,
    engine,
    inspection,
    adTitle: car.adTitle || `${car.year || 2020} ${car.brand || ''} ${car.model || ''}`,
    marketId: car.marketId || `car_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
  } as T;
};

export const generateInspection = (condition: Condition): CarInspection => {
  const inspection: CarInspection = {
    kaput: 'original',
    tavan: 'original',
    bagaj: 'original',
    solOnCamurluk: 'original',
    solOnKapi: 'original',
    solArkaKapi: 'original',
    solArkaCamurluk: 'original',
    sagOnCamurluk: 'original',
    sagOnKapi: 'original',
    sagArkaKapi: 'original',
    sagArkaCamurluk: 'original',
    onTampon: 'original',
    arkaTampon: 'original',
    agirHasarKayitli: false,
    tramerTutar: 0,
  };

  if (condition === 'Temiz') {
    return inspection;
  }

  if (condition === 'Boyalı') {
    // 1 to 3 random parts painted
    const paintCount = Math.floor(Math.random() * 3) + 1;
    const partsToPaint = [...ALL_PARTS].sort(() => Math.random() - 0.5).slice(0, paintCount);
    partsToPaint.forEach(part => {
      // Don't usually paint tavan on simple painted cars
      if (part !== 'tavan' || Math.random() < 0.1) {
        inspection[part] = 'painted';
      }
    });
    inspection.tramerTutar = Math.floor(Math.random() * 18000) + 4000;
    return inspection;
  }

  if (condition === 'Değişen') {
    // 1 or 2 parts replaced, 1 to 3 parts painted
    const replacedCount = Math.floor(Math.random() * 2) + 1;
    const paintedCount = Math.floor(Math.random() * 3) + 1;
    const shuffled = [...ALL_PARTS].sort(() => Math.random() - 0.5);
    
    const partsToReplace = shuffled.slice(0, replacedCount);
    const partsToPaint = shuffled.slice(replacedCount, replacedCount + paintedCount);

    partsToReplace.forEach(part => {
      if (part !== 'tavan') inspection[part] = 'replaced';
      else inspection[part] = 'painted';
    });

    partsToPaint.forEach(part => {
      if (inspection[part] === 'original') {
        inspection[part] = 'painted';
      }
    });

    inspection.tramerTutar = Math.floor(Math.random() * 45000) + 20000;
    return inspection;
  }

  // Ağır Hasarlı
  inspection.agirHasarKayitli = true;
  const replacedCount = Math.floor(Math.random() * 3) + 2;
  const paintedCount = Math.floor(Math.random() * 4) + 2;
  const shuffled = [...ALL_PARTS].sort(() => Math.random() - 0.5);

  shuffled.slice(0, replacedCount).forEach(part => {
    inspection[part] = 'replaced';
  });

  shuffled.slice(replacedCount, replacedCount + paintedCount).forEach(part => {
    if (inspection[part] === 'original') {
      inspection[part] = 'painted';
    }
  });

  // Tavan hasar olasılığı
  if (Math.random() < 0.45) {
    inspection.tavan = 'painted';
  }

  // %65 olasılıkla ağır hasarlı araçlar şasi/motor hasarlı ve TAMİR EDİLEMEZ (Pert) olur
  if (Math.random() < 0.65) {
    inspection.isUnrepairable = true;
    const reasons = [
      'Şasi podye bükük ve airbag patlak. Pert kayıtlı (Serviste toplanamaz / onarılamaz).',
      'Motor bloğu kilitli ve şanzıman çatlak. Ağır hasar kayıtlı (Tamir edilemez, parça/hurda amaçlı).',
      'Tavan ve direkler kesilip eklenmiş ağır pert araç. Güvenlik gerekçesiyle onarımı mümkün değildir.',
      'Su baskını (Sel) hasarlı ve elektrik tesisatı yanık. Komple pert kayıtlı, servis kabul etmiyor.'
    ];
    inspection.unrepairableReason = reasons[Math.floor(Math.random() * reasons.length)];
  }

  inspection.tramerTutar = Math.floor(Math.random() * 220000) + 110000;
  return inspection;
};

export const isCarRepairable = (car: MarketCar | PlayerCar | null | undefined): { repairable: boolean; reason?: string } => {
  if (!car) return { repairable: false, reason: 'Geçersiz araç' };
  if (car.condition === 'Temiz') {
    return { repairable: false, reason: 'Araç zaten kusursuz temiz durumda, serviste onarım gerekmez.' };
  }
  if (car.isUnrepairable || car.inspection?.isUnrepairable) {
    return { 
      repairable: false, 
      reason: car.unrepairableReason || car.inspection?.unrepairableReason || 'Bu araç ağır pert kayıtlı ve şasi/motor hasarlıdır. Serviste onarılamaz!' 
    };
  }
  return { repairable: true };
};

const AD_TITLE_PREFIXES = [
  'HATASIZ BOYASIZ',
  'İLK SAHİBİNDEN DOKTORDAN',
  'GARAJ ARABASI FIRSAT',
  'EMSALSİZ TEMİZLİKTE',
  'YETKİLİ SERVİS BAKIMLI',
  'ACİL İHTİYAÇTAN UYGUN',
  'KUSURSUZ KONDİSYONDA',
  'ÖZEL SİPARİŞ EN DOLUSU',
  'MASRAFSIZ BİNİCİYE',
  'ESNAFTAN PIRIL PIRIL',
];

export const generateAdTitle = (car: MarketCar | CarModel, condition: Condition, km: number): string => {
  const kmK = Math.round(km / 1000);
  const trans = car.engine.transmission === 'Otomatik' ? 'OTOMATİK' : 'MANUEL';
  
  if (condition === 'Temiz') {
    return `-${AD_TITLE_PREFIXES[Math.floor(Math.random() * 4)]} ${car.year} ${car.brand.toUpperCase()} ${car.model.toUpperCase()} ${kmK} BİNDE ${trans}-`;
  }
  if (condition === 'Boyalı') {
    return `-${car.year} ${car.brand.toUpperCase()} ${car.model.toUpperCase()} ${car.series ? car.series.toUpperCase() : ''} ${kmK} BİNDE ÇİZİK BOYALI-`;
  }
  if (condition === 'Değişen') {
    return `-UYGUN FİYATLI ${car.year} ${car.brand.toUpperCase()} ${car.model.toUpperCase()} ${kmK} KM YÜRÜYENİ KUSURSUZ-`;
  }
  return `-AĞIR HASAR KAYITLI ${car.year} ${car.brand.toUpperCase()} ${car.model.toUpperCase()} ÇALIŞIR YÜRÜR DURUMDA-`;
};

const CAR_COLORS = [
  'Beyaz',
  'Siyah',
  'Füme',
  'Gümüş Gri',
  'Demir Mavi',
  'Kırmızı',
  'Sedefli Beyaz',
  'Aytaşı Gri',
  'Safir Mavi',
  'Gece Siyahı',
  'Şampanya Sarısı',
  'Titan Grisi',
  'Yarış Mavisi',
];

export interface SellerProfile {
  type: SellerType;
  name: string;
  avatar: string;
  quotes: string[];
  priceMarkupRange: [number, number]; // e.g. [1.15, 1.30] for tok satıcı (overpriced)
  minAcceptableRatio: number; // lowest acceptable price ratio of asking price
  patience: number;
}

const SELLER_PROFILES: SellerProfile[] = [
  {
    type: 'Tok Satıcı',
    name: 'Hüseyin Bey (Tok Satıcı)',
    avatar: '👑',
    quotes: [
      'Mal ortada usta, kuruş inmem. Fiyatı pahalı bulan yürüsün veya Tofaş baksın.',
      'Keyfe keder satılık! Garajımda yerim bol, aciliyetim sıfır. Malımın kıymetini bilirim.',
      'Piyasanın en hatasızı. Ölücüler aramasın, 1 TL bile düşmem.',
      'Emsalsiz araç! Cebinde parası yetmeyen başka kapıya gitsin.',
    ],
    priceMarkupRange: [1.16, 1.32], // +16% to +32% pahalı!
    minAcceptableRatio: 0.96, // Maximum %4 indirim verir
    patience: 2,
  },
  {
    type: 'Gözü Açık Satıcı',
    name: 'Serkan (Altın El Oto)',
    avatar: '🦊',
    quotes: [
      'Piyasayı araştır gel usta, bu kondisyonda araba zor bulursun. Az bir şey çay parası ikram ederim.',
      'Dosta gider temiz araç, kıymetini bilene yarar. Çayımızı içene ufak bir jest yaparız.',
      'İlan yeni düştü, arayan çok. Fazla kıramam ama ciddiysen anlaşırız.',
    ],
    priceMarkupRange: [1.08, 1.18], // +8% to +18% pahalı
    minAcceptableRatio: 0.90, // %10 indirim
    patience: 3,
  },
  {
    type: 'Normal Binici',
    name: 'Mustafa Öğretmen',
    avatar: '👨‍💼',
    quotes: [
      'Model yükseltmek için satıyorum. Noter masrafı ve ufak bir ikram benden olsun.',
      'Ailece temiz baktık, bakımları yetkili serviste yapıldı. Ciddi alıcıyı üzmem.',
      'Piyasa değerini yazdım, sünnettir diyerek makul bir pazarlık yaparız.',
    ],
    priceMarkupRange: [0.98, 1.05], // Normal piyasa
    minAcceptableRatio: 0.91, // %9 indirim
    patience: 3,
  },
  {
    type: 'Galeri Esnafı',
    name: 'Selim Bey (Oto Vizyon)',
    avatar: '💼',
    quotes: [
      'Meslektaşım hayırlı işler, dükkana başka araç çekeceğim. Hızlı ticaret olsun dersen tatlıya bağlayalım.',
      'Vitrin arabasıdır, masrafsızdır. Esnaf işi fiyatta anlaşırız.',
    ],
    priceMarkupRange: [1.02, 1.12],
    minAcceptableRatio: 0.89,
    patience: 3,
  },
  {
    type: 'Acil İhtiyaçtan',
    name: 'Sedat Bey (Nakit Lazım)',
    avatar: '⚡',
    quotes: [
      'Ev peşinatı için acil satılık! Nakit parayı masaya koyanla hemen notere geçerim.',
      'Fiyatı piyasanın altına yazdım, geleni üzmem. Çabuk olan kazanır!',
      'Borç kapama amaçlı kelepir satılık. Nakit getirene güzel ikramım var.',
    ],
    priceMarkupRange: [0.84, 0.94], // -6% to -16% Kelepir fırsat!
    minAcceptableRatio: 0.82, // %18'e kadar pazarlık payı!
    patience: 4,
  },
];

export interface DealGradeInfo {
  grade: DealGrade;
  title: string;
  badgeLabel: string;
  badgeClass: string;
  cardClass: string;
  bgLight: string;
  textColor: string;
  borderColor: string;
  description: string;
  advice: string;
  percentDiff: number;
  icon: string;
  stars: number;
}

// 1. Alış Sonrası Değerlendirme (Purchase Performance Grading: A / B / C / D)
export const getPurchaseGradeInfo = (
  paidPrice: number,
  fairMarketValue?: number,
  originalAskingPrice?: number
): DealGradeInfo => {
  const fmv = fairMarketValue && fairMarketValue > 0 ? fairMarketValue : paidPrice;
  const percentDiff = Math.round(((paidPrice - fmv) / fmv) * 100);
  const discountAmount = originalAskingPrice && originalAskingPrice > paidPrice 
    ? originalAskingPrice - paidPrice 
    : 0;

  if (percentDiff <= -7 || (discountAmount > 0 && discountAmount >= fmv * 0.10)) {
    // A: Usta Alım / Fırsat
    return {
      grade: 'A',
      title: 'A • Usta Esnaf / Kelepir Alım',
      badgeLabel: 'A (Kelepir Alım)',
      badgeClass: 'bg-emerald-500 text-white font-black shadow-xs',
      cardClass: 'border-emerald-500/40 bg-emerald-500/5',
      bgLight: 'bg-emerald-50 dark:bg-emerald-950/40',
      textColor: 'text-emerald-600 dark:text-emerald-400',
      borderColor: 'border-emerald-200 dark:border-emerald-800',
      description: `Piyasa rayicinin %${Math.abs(percentDiff)} altına kapattın! Yüksek kâr marjı garantiledin.`,
      advice: 'Bu aracı az masrafla toparlayıp piyasa rayicinden satarak yüksek kâr elde edebilirsin.',
      percentDiff,
      icon: '🔥',
      stars: 5,
    };
  } else if (percentDiff <= 2) {
    // B: Uygun Fiyat
    return {
      grade: 'B',
      title: 'B • Başarılı / Uygun Alım',
      badgeLabel: 'B (Uygun Alım)',
      badgeClass: 'bg-sky-500 text-white font-black shadow-xs',
      cardClass: 'border-sky-500/30 bg-sky-500/5',
      bgLight: 'bg-sky-50 dark:bg-sky-950/40',
      textColor: 'text-sky-600 dark:text-sky-400',
      borderColor: 'border-sky-200 dark:border-sky-800',
      description: `Piyasa değerinde veya hafif altında (%${Math.abs(percentDiff)} ${percentDiff <= 0 ? 'indirimli' : 'fark'}). Temiz kâr bırakır.`,
      advice: 'İyi bir alış yaptın. Gelen müşteri tekliflerinde iyi pazarlık yaparak kârını artır.',
      percentDiff,
      icon: '✅',
      stars: 4,
    };
  } else if (percentDiff <= 9) {
    // C: Standart Piyasa Alımı
    return {
      grade: 'C',
      title: 'C • Standart Piyasa Alımı',
      badgeLabel: 'C (Piyasa Alımı)',
      badgeClass: 'bg-amber-500 text-white font-black shadow-xs',
      cardClass: 'border-amber-500/30 bg-amber-500/5',
      bgLight: 'bg-amber-50 dark:bg-amber-950/40',
      textColor: 'text-amber-600 dark:text-amber-400',
      borderColor: 'border-amber-200 dark:border-amber-800',
      description: `Piyasa değerinin %+${percentDiff} üzerinde standart alım. Masrafları düşük tutmalısın.`,
      advice: 'Alış fiyatı standart seviyede. İyi bir alıcı gelene kadar acele etmeden bekle.',
      percentDiff,
      icon: '⚖️',
      stars: 3,
    };
  } else {
    // D: Pahalı Alım / Tok Satıcı
    return {
      grade: 'D',
      title: 'D • Pahalı Alım / Tok Satıcı',
      badgeLabel: 'D (Pahalı Alım)',
      badgeClass: 'bg-rose-500 text-white font-black shadow-xs',
      cardClass: 'border-rose-500/30 bg-rose-500/5',
      bgLight: 'bg-rose-50 dark:bg-rose-950/40',
      textColor: 'text-rose-600 dark:text-rose-400',
      borderColor: 'border-rose-200 dark:border-rose-800',
      description: `Piyasa değerinin %+${percentDiff} üzerinde pahalıya aldın! Tok satıcıya denk geldin.`,
      advice: 'Kâr edebilmek için aracı acele etmeden, değerini bilen meraklı veya acele alıcılara satmalısın.',
      percentDiff,
      icon: '⚠️',
      stars: 2,
    };
  }
};

// 2. Satış Sonrası Değerlendirme (Sale Performance Grading: A / B / C / D)
export const getSaleGradeInfo = (
  soldPrice: number,
  totalCost: number
): DealGradeInfo => {
  const cost = totalCost > 0 ? totalCost : soldPrice;
  const profit = soldPrice - cost;
  const profitMargin = Math.round((profit / cost) * 100);

  if (profitMargin >= 20 || profit >= 80000) {
    // A: Efsanevi Satış / Rekor Kâr
    return {
      grade: 'A',
      title: 'A • Efsanevi Satış / Rekor Kâr',
      badgeLabel: 'A (Rekor Kâr)',
      badgeClass: 'bg-emerald-500 text-white font-black shadow-xs',
      cardClass: 'border-emerald-500/40 bg-emerald-500/5',
      bgLight: 'bg-emerald-50 dark:bg-emerald-950/40',
      textColor: 'text-emerald-600 dark:text-emerald-400',
      borderColor: 'border-emerald-200 dark:border-emerald-800',
      description: `%+${profitMargin} kâr marjı ile dev kazanç! Galericilikte zirve performans sergiledin.`,
      advice: 'Mükemmel bir ticaret! Bu kâr ile galerini büyütebilir veya üst segment araçlar alabilirsin.',
      percentDiff: profitMargin,
      icon: '👑',
      stars: 5,
    };
  } else if (profitMargin >= 10 || profit >= 35000) {
    // B: Başarılı Satış / Güzel Kâr
    return {
      grade: 'B',
      title: 'B • Başarılı Satış / Sağlam Kâr',
      badgeLabel: 'B (Güzel Kâr)',
      badgeClass: 'bg-sky-500 text-white font-black shadow-xs',
      cardClass: 'border-sky-500/30 bg-sky-500/5',
      bgLight: 'bg-sky-50 dark:bg-sky-950/40',
      textColor: 'text-sky-600 dark:text-sky-400',
      borderColor: 'border-sky-200 dark:border-sky-800',
      description: `%+${profitMargin} kâr marjı (+${formatMoney(profit)}) ile temiz ve sağlam bir kazanç elde ettin.`,
      advice: 'Çok güzel bir satış. Galerine istikrarlı büyüme sağlıyor.',
      percentDiff: profitMargin,
      icon: '🌟',
      stars: 4,
    };
  } else if (profitMargin >= 1 || profit > 0) {
    // C: Makul Satış / Hızlı Devir
    return {
      grade: 'C',
      title: 'C • Makul Satış / Hızlı Devir',
      badgeLabel: 'C (Makul Satış)',
      badgeClass: 'bg-amber-500 text-white font-black shadow-xs',
      cardClass: 'border-amber-500/30 bg-amber-500/5',
      bgLight: 'bg-amber-50 dark:bg-amber-950/40',
      textColor: 'text-amber-600 dark:text-amber-400',
      borderColor: 'border-amber-200 dark:border-amber-800',
      description: `%+${profitMargin} kâr ile makul bir satış. Sürümden kazandırıp sıcak para getirdi.`,
      advice: 'Nakit akışını hızlandıran iyi bir devir oldu. Sıradaki araçta daha yüksek kâr hedefle.',
      percentDiff: profitMargin,
      icon: '🤝',
      stars: 3,
    };
  } else {
    // D: Zararına / Düşük Kâr
    return {
      grade: 'D',
      title: profit < 0 ? 'D • Zararına Satış' : 'D • Başabaş / Düşük Kâr',
      badgeLabel: profit < 0 ? 'D (Zararına)' : 'D (Düşük Kâr)',
      badgeClass: 'bg-rose-500 text-white font-black shadow-xs',
      cardClass: 'border-rose-500/30 bg-rose-500/5',
      bgLight: 'bg-rose-50 dark:bg-rose-950/40',
      textColor: 'text-rose-600 dark:text-rose-400',
      borderColor: 'border-rose-200 dark:border-rose-800',
      description: profit < 0 
        ? `Bu satıştan -${formatMoney(Math.abs(profit))} zarar edildi (%${profitMargin}).`
        : `Maliyeti ancak kurtaran bir satış oldu (%${profitMargin} kâr).`,
      advice: profit < 0 
        ? 'Zararı telafi etmek için piyasadan kelepir araçlar bulup pazarlıkla ucuza kapat.' 
        : 'Pazarlıkta müşteriyi biraz daha yukarı çekmeyi dene.',
      percentDiff: profitMargin,
      icon: '📉',
      stars: 1,
    };
  }
};

export const calculateBuyTradeReport = (
  car: MarketCar,
  paidPrice: number,
  discountAmount?: number
): TradeReport => {
  const fmv = car.fairMarketValue || paidPrice;
  const gradeInfo = getPurchaseGradeInfo(paidPrice, fmv, car.originalAskingPrice || car.price);
  const totalDiscount = discountAmount || Math.max(0, (car.originalAskingPrice || car.price) - paidPrice);

  return {
    id: `report_buy_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    type: 'buy',
    grade: gradeInfo.grade,
    carBrand: car.brand,
    carModel: car.model,
    carYear: car.year,
    carImage: car.image,
    price: paidPrice,
    referenceValue: fmv,
    diffAmount: fmv - paidPrice,
    diffPercentage: gradeInfo.percentDiff,
    partnerName: car.sellerName || 'Satıcı',
    partnerAvatar: car.sellerAvatar || '👨‍💼',
    discountAmount: totalDiscount,
    title: gradeInfo.title,
    badgeLabel: gradeInfo.badgeLabel,
    badgeClass: gradeInfo.badgeClass,
    description: gradeInfo.description,
    advice: gradeInfo.advice,
    stars: gradeInfo.stars,
    timestamp: Date.now(),
  };
};

export const calculateSaleTradeReport = (
  car: PlayerCar,
  offer: CustomerOffer
): TradeReport => {
  const totalCost = car.totalInvestedCost || car.purchasePrice;
  const profit = offer.offeredPrice - totalCost;
  const gradeInfo = getSaleGradeInfo(offer.offeredPrice, totalCost);

  return {
    id: `report_sell_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    type: 'sell',
    grade: gradeInfo.grade,
    carBrand: car.brand,
    carModel: car.model,
    carYear: car.year,
    carImage: car.image,
    price: offer.offeredPrice,
    referenceValue: totalCost,
    diffAmount: profit,
    diffPercentage: gradeInfo.percentDiff,
    partnerName: offer.buyerName || 'Müşteri',
    partnerAvatar: offer.buyerAvatar || '💼',
    title: gradeInfo.title,
    badgeLabel: gradeInfo.badgeLabel,
    badgeClass: gradeInfo.badgeClass,
    description: gradeInfo.description,
    advice: gradeInfo.advice,
    stars: gradeInfo.stars,
    timestamp: Date.now(),
  };
};

// Backward compatibility alias if needed
export const getDealGradeInfo = (askingPrice: number, fairMarketValue?: number): DealGradeInfo => {
  return getPurchaseGradeInfo(askingPrice, fairMarketValue);
};

export const generateSingleMarketCar = (baseCar?: CarModel, index = 0): MarketCar => {
  const model = baseCar || CAR_DATABASE[Math.floor(Math.random() * CAR_DATABASE.length)];
  
  // Weighted condition probability
  const rand = Math.random();
  let condition: Condition;
  if (rand > 0.60) condition = 'Temiz';
  else if (rand > 0.32) condition = 'Boyalı';
  else if (rand > 0.12) condition = 'Değişen';
  else condition = 'Ağır Hasarlı';
  
  // Slight year variation around base year (-2 to +1, clamped)
  const yearOffset = Math.floor(Math.random() * 3) - 1;
  const year = Math.min(2024, Math.max(2010, model.year + yearOffset));
  
  // Generate KM based on condition and year
  const age = 2024 - year;
  let km = Math.floor(Math.random() * 28000) + (age * 17000) + 10000;
  
  if (condition === 'Temiz') km = Math.floor(km * 0.55);
  if (condition === 'Ağır Hasarlı') km = Math.floor(km * 1.35);
  km = Math.max(12000, Math.floor(km));

  // Calculate base fair market value based on condition and KM
  let priceMultiplier = 1;
  if (condition === 'Temiz') priceMultiplier = 1.08;
  if (condition === 'Boyalı') priceMultiplier = 0.94;
  if (condition === 'Değişen') priceMultiplier = 0.78;
  if (condition === 'Ağır Hasarlı') priceMultiplier = 0.52;
  
  // KM depreciation
  const kmDepreciation = Math.min((km / 100000) * 0.05, 0.22);
  
  // Base price adjustment for year
  const yearPriceFactor = 1 + (year - model.year) * 0.04;
  const fairMarketValue = Math.max(85000, Math.floor((model.basePrice * yearPriceFactor * (priceMultiplier - kmDepreciation)) / 1000) * 1000);

  // Pick seller profile
  const sellerProfile = SELLER_PROFILES[Math.floor(Math.random() * SELLER_PROFILES.length)];
  const markupMin = sellerProfile.priceMarkupRange[0];
  const markupMax = sellerProfile.priceMarkupRange[1];
  const markup = markupMin + Math.random() * (markupMax - markupMin);

  const finalAskingPrice = Math.floor((fairMarketValue * markup) / 1000) * 1000;
  const overpricedPercentage = Math.round(((finalAskingPrice - fairMarketValue) / fairMarketValue) * 100);
  const isOverpriced = overpricedPercentage >= 8;

  const minAcceptablePrice = Math.floor((finalAskingPrice * sellerProfile.minAcceptableRatio) / 1000) * 1000;
  const sellerQuote = sellerProfile.quotes[Math.floor(Math.random() * sellerProfile.quotes.length)];
  
  const inspection = generateInspection(condition);
  const pickedColor = Math.random() > 0.4 ? CAR_COLORS[Math.floor(Math.random() * CAR_COLORS.length)] : model.color;
  
  const modifiedCar: CarModel = {
    ...model,
    year,
    color: pickedColor,
  };

  let adTitle = generateAdTitle(modifiedCar, condition, km);
  if (sellerProfile.type === 'Tok Satıcı') {
    adTitle = `-KEYFE KEDER SATILIK ${modifiedCar.year} ${modifiedCar.brand.toUpperCase()} ${modifiedCar.model.toUpperCase()} HATASIZ EMSALSİZ-`;
  } else if (sellerProfile.type === 'Acil İhtiyaçtan') {
    adTitle = `-ACİL İHTİYAÇTAN KELEPİR ${modifiedCar.year} ${modifiedCar.brand.toUpperCase()} ${modifiedCar.model.toUpperCase()} İLK GELEN ALIR-`;
  }

  const isUnrepairable = inspection.isUnrepairable || false;
  const unrepairableReason = inspection.unrepairableReason;

  return {
    ...modifiedCar,
    marketId: `market_${Date.now()}_${Math.random().toString(36).substr(2, 9)}_${index}`,
    condition,
    km,
    price: Math.max(finalAskingPrice, 75000),
    originalAskingPrice: Math.max(finalAskingPrice, 75000),
    fairMarketValue,
    isOverpriced,
    overpricedPercentage,
    sellerType: sellerProfile.type,
    sellerName: sellerProfile.name,
    sellerAvatar: sellerProfile.avatar,
    sellerPatience: sellerProfile.patience,
    sellerMinPrice: minAcceptablePrice,
    sellerQuote,
    inspection,
    adTitle,
    isUnrepairable,
    unrepairableReason,
  };
};

export const generateFullMarketCatalog = (): MarketCar[] => {
  const cars: MarketCar[] = [];
  let index = 0;

  // Generate 2 to 3 varied listings for every single car in CAR_DATABASE
  CAR_DATABASE.forEach((model) => {
    // Generate at least 2 or 3 distinct listings for this model
    const variationsCount = 3;
    for (let i = 0; i < variationsCount; i++) {
      cars.push(generateSingleMarketCar(model, index++));
    }
  });

  // Shuffle the cars array so they are mixed nicely
  for (let i = cars.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [cars[i], cars[j]] = [cars[j], cars[i]];
  }

  return cars;
};

export const generateMarketCars = (count?: number): MarketCar[] => {
  // If count is not specified or large, return full massive catalog (120+ cars)
  if (!count || count >= CAR_DATABASE.length) {
    return generateFullMarketCatalog();
  }
  
  // If a specific smaller count is requested, generate that many
  const cars: MarketCar[] = [];
  for (let i = 0; i < count; i++) {
    cars.push(generateSingleMarketCar(undefined, i));
  }
  return cars;
};

export const calculateRepairCost = (car: MarketCar, mechanicDiscountLevel: number = 1): number => {
  if (car.condition === 'Temiz') return 0;
  if (car.isUnrepairable || car.inspection?.isUnrepairable) return 0;
  
  let rawCost = 0;
  // Boyalı araç kozmetik bakım & pasta cila
  if (car.condition === 'Boyalı') rawCost = Math.floor(car.basePrice * 0.04);
  // Değişen parçalı araç kaporta ve montaj onarımı
  else if (car.condition === 'Değişen') rawCost = Math.floor(car.basePrice * 0.14);
  // Ağır hasarlı onarılabilir araç şasi düzeltme ve ağır servis onarımı
  else rawCost = Math.floor(car.basePrice * 0.32);

  // Apply mechanic discount: lvl 1: 0%, lvl 2: 20%, lvl 3: 40%, lvl 4: 65%
  const discounts = [0, 0, 0.20, 0.40, 0.65];
  const discountRate = discounts[mechanicDiscountLevel] || 0;
  return Math.max(1500, Math.floor(rawCost * (1 - discountRate)));
};

export const calculateRepairDuration = (car: MarketCar, speedUpgradeLevel: number = 1): number => {
  // Base duration in seconds
  let baseSeconds = 5;
  if (car.condition === 'Boyalı') baseSeconds = 8; // 8 seconds for paint touch-up & detailing
  else if (car.condition === 'Değişen') baseSeconds = 18; // 18 seconds for bodywork & part repair
  else if (car.condition === 'Ağır Hasarlı') baseSeconds = 30; // 30 seconds for heavy rebuild

  // Speed multiplier: lvl 1: 1.0x, lvl 2: 1.5x, lvl 3: 2.5x, lvl 4: 5.0x
  const speedMultipliers = [1, 1.0, 1.5, 2.5, 5.0];
  const mult = speedMultipliers[speedUpgradeLevel] || 1.0;
  return Math.max(2, Math.round(baseSeconds / mult));
};

export const getNextRepairedCondition = (condition: Condition): Condition => {
  // Gerçekçi onarım akışı:
  // Ağır Hasarlı -> Onarılınca 'Değişen' olur (şasi/tramer düzeltilir, parçalar değişmiş kalır)
  // Değişen -> Onarılınca 'Boyalı' olur (değişen parçalar gövdeye boyanıp uyarlanır)
  // Boyalı -> Onarılınca 'Boyalı' kalır ama ekspertiz boya rötuşları kusursuzlaşır ve satış değeri/itibar yükselir
  if (condition === 'Ağır Hasarlı') return 'Değişen';
  if (condition === 'Değişen') return 'Boyalı';
  return 'Boyalı';
};

export const getModelStampKey = (brand: string, model: string): string => {
  return `${brand.trim().toLowerCase()}_${model.trim().toLowerCase()}`;
};

export const getConditionColor = (condition: Condition): string => {
  switch (condition) {
    case 'Temiz': return 'text-emerald-600 bg-emerald-500/10 border-emerald-500/20';
    case 'Boyalı': return 'text-sky-600 bg-sky-500/10 border-sky-500/20';
    case 'Değişen': return 'text-amber-600 bg-amber-500/10 border-amber-500/20';
    case 'Ağır Hasarlı': return 'text-rose-600 bg-rose-500/10 border-rose-500/20';
    default: return 'text-gray-500 bg-gray-500/10 border-gray-500/20';
  }
};

const BUYER_PROFILES: { name: string; avatar: string; type: BuyerType; quotes: Record<Condition, string[]> }[] = [
  {
    name: 'Kurnaz Selami (Spotçu & Ölücü)',
    avatar: '🦊',
    type: 'Ölücü / Fırsatçı Alıcı',
    quotes: {
      Temiz: [
        'Piyasa çok durgun usta, kimse nakit bağlamıyor. Rakamım nakit bu, ister sat ister garajda çürüsün.',
        'Millet araç satamıyor usta, bu fiyata verirsen 10 dakikaya IBAN atayım.',
      ],
      Boyalı: [
        'Boyalı arabaya kimse para vermez bu devirde. Benim teklifim bu, piyasası ölü zaten.',
        'Tavanda vernik yanığı var gibi, boyası tutmaz. Zarar etme ver bana kurtul.',
      ],
      Değişen: [
        'Değişenli araç elimde patlar usta. En fazla bu parayı veririm, kabul edersen çekici gönderiyorum.',
        'İlan aylarca bekler bu fiyata. Ben sıcak parayı önüne koyuyorum, düşünme ver.',
      ],
      'Ağır Hasarlı': [
        'Pert arabayı kime satacaksın usta? Hurda fiyatına ancak alırım, nakit cebinde kalsın.',
        'Şasisi bitik araba, anca parçaya gider. Bu rakamdan tek kuruş yukarı çıkmam.',
      ],
    },
  },
  {
    name: 'Ahmet Yılmaz',
    avatar: '👨‍💼',
    type: 'Bireysel Alıcı',
    quotes: {
      Temiz: [
        'Ailecek kullanacağımız temiz bir araba arıyorduk, araç tam istediğimiz gibi. Fiyatta anlaşırsak notere geçelim.',
        'Kazasız ve temiz duruyor. Fiyatı uygun buldum, nakit hazır.',
      ],
      Boyalı: [
        'Çizik boyalarını dert etmem, motoru yürüyeni sağlamsa bu fiyata alırım.',
        'Birkaç parça boya sorun değil, günlük işe gidip gelmek için bütçeme uygun.',
      ],
      Değişen: [
        'Değişeni varmış ama fiyat makul olursa düşünebilirim.',
        'Parça değişimi beni çok korkutmaz, yürüyeni düzgünse el sıkışalım.',
      ],
      'Ağır Hasarlı': [
        'Ağır hasar kaydı varmış, bu fiyata bırakırsanız ayağımı yerden kessin diye alırım.',
        'Bütçem kısıtlı, hasar kaydına rağmen çalışıyorsa ilgileniyorum.',
      ],
    },
  },
  {
    name: 'Selim Koç (Koçlar Otomotiv)',
    avatar: '🧔‍♂️',
    type: 'Galeri Esnafı',
    quotes: {
      Temiz: [
        'Hayırlı işler meslektaşım. Galeride vitrine koymalık araç, nakit bu rakama hemen bağlayalım.',
        'Selamlar, dükkana müşteri var. Hızlı ticaret olsun dersen hemen EFT yapayım.',
      ],
      Boyalı: [
        'Biz de esnafız, ufak tefek boyayı sorun etmeyiz. Rakam bu, uyarsa yarım saate alayım.',
        'Boyalı araç piyasada hızlı dönüyor. Fiyatta anlaşırsak hemen notere gidelim.',
      ],
      Değişen: [
        'Değişen parçaları dükkanda toparlarım. Rakamım nettir, düşünürsen ara.',
        'Al-sat yapıyorum usta, sen de kazan ben de kazanayım. Teklifim hazır.',
      ],
      'Ağır Hasarlı': [
        'Ağır hasarlı aracı toplayıp satarım, nakit hazır. Bu fiyata bırakırsan çekiciyle aldırayım.',
        'Esnaf işi bir rakam teklif ettim, uygunsa noteri halledelim.',
      ],
    },
  },
  {
    name: 'Burak & Merve Öztürk',
    avatar: '👩‍💼',
    type: 'Acele Alıcı',
    quotes: {
      Temiz: [
        'Hafta sonu acil şehir dışına çıkmamız gerekiyor, aracı çok beğendik! Hemen alabiliriz.',
        'Acil araba lazım oldu, ekspertiz yaptırıp hemen devir almak istiyoruz.',
      ],
      Boyalı: [
        'İlanı yeni gördük, acil ihtiyacımız var. Boyası çok önemli değil, temizse alıyoruz.',
        'Bugün içinde teslim alabilirsek bu fiyata hemen kapatırız.',
      ],
      Değişen: [
        'Arabasız kaldık, acil lazım. Yürüyeninde sıkıntı yoksa hemen ödeme yapalım.',
        'Acelemiz var, bu fiyatta anlaşırsak hemen gelelim.',
      ],
      'Ağır Hasarlı': [
        'Kısa süreliğine acil araç lazım, bu rakam uygunsa hemen alalım.',
        'Şantiye ve iş için acil lazım, teklifimiz budur.',
      ],
    },
  },
  {
    name: 'Kemal Şahin',
    avatar: '👴',
    type: 'Bireysel Alıcı',
    quotes: {
      Temiz: [
        'Emeklilik ikramiyemle temiz bir araç bakıyordum. İlanınız dikkatimi çekti, teklifim budur.',
        'Gözüm gibi bakacağım temiz bir araba. Fiyatta az bir ikram yaparsanız hayırlı olsun derim.',
      ],
      Boyalı: [
        'Ufak tefek boya nazar boncuğudur, motoru diriyse aracı alırım.',
        'Yaşına göre boyası normal. Bu fiyattan verirseniz yarın gelebilirim.',
      ],
      Değişen: [
        'Değişen parçaları varmış, fiyatı ona göre teklif ettim. Hayırlı işler.',
        'Yürüyen aksamı sağlamsa değişen kaportaya takılmam.',
      ],
      'Ağır Hasarlı': [
        'Köyde bahçeye gidip gelmek için bakıyorum, hasarı mühim değil.',
        'Fiyatı uygun tutarsanız alıp kullanırım.',
      ],
    },
  },
  {
    name: 'Emre Çelik',
    avatar: '🧑‍💻',
    type: 'Koleksiyoner',
    quotes: {
      Temiz: [
        'Araç kondisyonu çok başarılı görünüyor. Değerini bilirim, teklifim nakittir.',
        'Tam koleksiyonuma ve zevkime uygun! Rakamı uygun görürseniz hemen anlaştık.',
      ],
      Boyalı: [
        'Orijinalliği kısmen bozulmuş ama modeli çok sevdiğim için teklif vermek istedim.',
        'Bu modelin hastasıyım, teklifim masada.',
      ],
      Değişen: [
        'Değişenli olmasa daha yüksek verirdim ama modeli sevdiğim için bu teklifi yapıyorum.',
        'Kasa hatları düzgünse alıp garajıma çekerim.',
      ],
      'Ağır Hasarlı': [
        'Proje aracı olarak değerlendirmek istiyorum, bu fiyata bırakırsanız alırım.',
        'Restorasyon veya modifiye için ilgileniyorum.',
      ],
    },
  },
];

export const generateCustomerOffer = (
  car: PlayerCar,
  currentDay: number,
  reputation: number,
  paintBoothLevel: number = 1
): CustomerOffer => {
  const profile = BUYER_PROFILES[Math.floor(Math.random() * BUYER_PROFILES.length)];
  
  let conditionMultiplier = 1.0;
  if (car.condition === 'Temiz') conditionMultiplier = 1.10;
  if (car.condition === 'Boyalı') conditionMultiplier = 0.95;
  if (car.condition === 'Değişen') conditionMultiplier = 0.80;
  if (car.condition === 'Ağır Hasarlı') conditionMultiplier = 0.52;

  // If car is unrepairable pert, valuation drops heavily
  if (car.isUnrepairable || car.inspection?.isUnrepairable) {
    conditionMultiplier = 0.40;
  }

  // Paint booth upgrade bonus: +0%, +5%, +10%, +18% bonus offer price
  const paintBonuses = [0, 0, 0.05, 0.10, 0.18];
  const paintBonus = paintBonuses[paintBoothLevel] || 0;

  // Garaged days depreciation: for every day beyond purchase day, car value slightly depreciates (-2.5% per day, capped at -25%)
  const daysInGarage = Math.max(0, currentDay - (car.boughtAtDay || currentDay));
  const garageDepreciation = Math.min(daysInGarage * 0.025, 0.25);

  const marketVal = car.basePrice * conditionMultiplier * (1 + paintBonus) * (1 - garageDepreciation);
  const costBasis = car.totalInvestedCost || car.purchasePrice;

  let typeMultiplier = 1.0;
  if (profile.type === 'Ölücü / Fırsatçı Alıcı') {
    // Aggressive lowball offers: 70% to 84% of cost basis (guaranteed heavy loss if accepted)
    typeMultiplier = 0.72 + Math.random() * 0.12;
  } else if (profile.type === 'Galeri Esnafı') {
    // Wholesale trade offer: 82% to 94% of market value (often below retail cost)
    typeMultiplier = 0.84 + Math.random() * 0.09;
  } else if (profile.type === 'Acele Alıcı') {
    typeMultiplier = 1.03 + Math.random() * 0.12;
  } else if (profile.type === 'Koleksiyoner') {
    typeMultiplier = car.condition === 'Temiz' ? 1.05 + Math.random() * 0.18 : 0.88 + Math.random() * 0.10;
  } else {
    // Bireysel Alıcı: 0.88 to 1.04
    typeMultiplier = 0.88 + Math.random() * 0.16;
  }

  const repBonus = (reputation - 50) / 1200;
  
  // Calculate offer price
  let offerBase = profile.type === 'Ölücü / Fırsatçı Alıcı' ? costBasis : marketVal;
  let finalPrice = Math.floor((offerBase * (typeMultiplier + repBonus)) / 1000) * 1000;

  // Safety floor
  finalPrice = Math.max(finalPrice, 35000);

  const quotesList = profile.quotes[car.condition] || profile.quotes['Temiz'];
  const message = quotesList[Math.floor(Math.random() * quotesList.length)];

  return {
    id: `offer_${Date.now()}_${Math.random().toString(36).substr(2, 7)}`,
    carMarketId: car.marketId,
    carName: `${car.brand} ${car.model} ${car.series || ''}`,
    carImage: car.image,
    buyerName: profile.name,
    buyerType: profile.type,
    buyerAvatar: profile.avatar,
    offeredPrice: finalPrice,
    originalPrice: finalPrice,
    message,
    dayReceived: currentDay,
    expiresDay: currentDay + 2,
  };
};

export const generateDailyOffers = (
  garage: PlayerCar[],
  currentDay: number,
  reputation: number,
  marketingLevel: number = 1,
  paintBoothLevel: number = 1
): CustomerOffer[] => {
  const newOffers: CustomerOffer[] = [];
  // Marketing upgrade increases chance of receiving offer
  // lvl 1: 0.55, lvl 2: 0.70, lvl 3: 0.85, lvl 4: 0.95
  const marketingChances = [0.55, 0.55, 0.70, 0.85, 0.95];
  let baseChance = marketingChances[marketingLevel] || 0.55;

  for (const car of garage) {
    let chance = baseChance;
    if (car.condition === 'Temiz') chance += 0.15;
    if (car.condition === 'Ağır Hasarlı') chance -= 0.10;
    chance += (reputation - 50) / 200;

    if (Math.random() < Math.max(0.2, chance)) {
      newOffers.push(generateCustomerOffer(car, currentDay, reputation, paintBoothLevel));
      
      if (Math.random() < 0.30 && car.condition === 'Temiz') {
        newOffers.push(generateCustomerOffer(car, currentDay, reputation, paintBoothLevel));
      }
    }
  }

  return newOffers;
};

export const evaluateCounterOffer = (
  offer: CustomerOffer,
  car: PlayerCar,
  counterPrice: number,
  reputation: number,
  isSonFiyat: boolean = false
): { success: boolean; newPrice?: number; message: string; walkedAway: boolean } => {
  const currentOffer = offer.offeredPrice;
  const increasePercent = (counterPrice - currentOffer) / currentOffer;

  if (counterPrice <= currentOffer) {
    return {
      success: true,
      newPrice: currentOffer,
      message: 'Zaten anlaştık usta, el sıkışalım!',
      walkedAway: false,
    };
  }

  // If player used "Son Fiyatım Bu" button
  if (isSonFiyat) {
    if (increasePercent <= 0.05) {
      return {
        success: true,
        newPrice: counterPrice,
        message: `Tamam usta, "Son Fiyatım ${formatMoney(counterPrice)}" dedin, esnaflığına saygı duydum. Noterde buluşalım, hayırlı olsun!`,
        walkedAway: false,
      };
    } else if (increasePercent <= 0.12) {
      const repBonus = reputation / 300;
      const acceptChance = (offer.buyerType === 'Acele Alıcı' ? 0.75 : offer.buyerType === 'Koleksiyoner' ? 0.65 : 0.48) + repBonus;
      
      if (Math.random() < acceptChance) {
        return {
          success: true,
          newPrice: counterPrice,
          message: `Madem son fiyatın ${formatMoney(counterPrice)}, aracı da beğendim, son sözüne binaen kabul ediyorum. Hayırlı uğurlu olsun!`,
          walkedAway: false,
        };
      } else if (Math.random() < 0.65) {
        const compromisePrice = Math.floor((currentOffer + counterPrice) / 2 / 1000) * 1000;
        return {
          success: false,
          newPrice: compromisePrice,
          message: `Son fiyatın ${formatMoney(counterPrice)} beni aşıyor ama senin hatrına ${formatMoney(compromisePrice)} veririm. Orta yolda buluşalım.`,
          walkedAway: false,
        };
      } else {
        return {
          success: false,
          message: `Son fiyatın ${formatMoney(counterPrice)} bütçemi çok aşıyor usta. Başka araca bakacağım, hayırlı işler.`,
          walkedAway: true,
        };
      }
    } else {
      if (Math.random() < 0.8) {
        return {
          success: false,
          message: `Usta ${formatMoney(counterPrice)} son fiyat olmaz, bu fiyata piyasada sıfır ayarında araç var. Ben çekiliyorum.`,
          walkedAway: true,
        };
      } else {
        return {
          success: false,
          newPrice: currentOffer,
          message: `Son fiyatın çok yüksek usta. Benim de son sözüm ${formatMoney(currentOffer)}, uyarsa ver.`,
          walkedAway: false,
        };
      }
    }
  }

  // Standard counter negotiation
  if (increasePercent <= 0.06) {
    const successChance = 0.85 + (reputation / 500);
    if (Math.random() < successChance) {
      return {
        success: true,
        newPrice: counterPrice,
        message: 'Kırmayalım seni esnaf kardeşim, el sıkışalım! Anlaştık.',
        walkedAway: false,
      };
    } else {
      const middle = Math.floor((currentOffer + counterPrice) / 2 / 1000) * 1000;
      return {
        success: false,
        newPrice: middle,
        message: `O kadar çıkamam ama senin hatrına ${formatMoney(middle)} yaparım, uyarsa alırım.`,
        walkedAway: false,
      };
    }
  }

  if (increasePercent <= 0.14) {
    const successChance = 0.40 + (reputation / 400);
    if (Math.random() < successChance) {
      return {
        success: true,
        newPrice: counterPrice,
        message: 'Zorladın ama araç gerçekten içime sindi, kabul ediyorum!',
        walkedAway: false,
      };
    } else if (Math.random() < 0.6) {
      const middle = Math.floor((currentOffer * 1.04) / 1000) * 1000;
      return {
        success: false,
        newPrice: middle,
        message: `Çok istedin usta. Son teklifim ${formatMoney(middle)}, daha da yukarı çıkmam.`,
        walkedAway: false,
      };
    } else {
      return {
        success: false,
        message: 'Çok yüksek istedin usta, bu fiyata başka araç bakarım. Ben çekiliyorum.',
        walkedAway: true,
      };
    }
  }

  if (Math.random() < 0.8) {
    return {
      success: false,
      message: 'Bu fiyata sıfırını alırım usta! Pazarlığın da bir raconu var, ben vazgeçtim.',
      walkedAway: true,
    };
  } else {
    return {
      success: false,
      newPrice: currentOffer,
      message: 'O rakamlar beni aşar. İlk teklifim geçerli, uyarsa ver uymazsa canın sağ olsun.',
      walkedAway: false,
    };
  }
};

export interface BuyBargainResult {
  accepted: boolean;
  newPrice: number;
  sellerMessage: string;
  walkedAway: boolean;
  patienceLeft: number;
  angerLevel: 'happy' | 'neutral' | 'annoyed' | 'angry';
}

export const evaluateBuyBargain = (
  car: MarketCar,
  playerOfferPrice: number,
  currentPrice: number,
  tactic: 'ikram' | 'nakit' | 'masraf' | 'son_fiyat' | 'custom',
  patienceLeft: number,
  reputation: number
): BuyBargainResult => {
  const sellerType = car.sellerType || 'Normal Binici';
  const minPrice = car.sellerMinPrice || Math.floor(car.price * 0.92);
  const askingPrice = car.originalAskingPrice || car.price;

  // Calculate discount percentage requested compared to current price
  const discountAmount = currentPrice - playerOfferPrice;
  const discountPercent = discountAmount / currentPrice;

  // Special "Son Fiyat Sor" tactic
  if (tactic === 'son_fiyat') {
    let bestPossiblePrice = minPrice;
    if (sellerType === 'Tok Satıcı') {
      bestPossiblePrice = Math.floor((askingPrice * 0.97) / 1000) * 1000;
      return {
        accepted: false,
        newPrice: bestPossiblePrice,
        sellerMessage: `Bak kardeşim, "Son Fiyat" sordun diye söylüyorum: Benim aracım emsalsiz, son oluru ${formatMoney(bestPossiblePrice)}'dir. Tek kuruş altına vermem, işine gelirse.`,
        walkedAway: false,
        patienceLeft: Math.max(1, patienceLeft - 1),
        angerLevel: 'neutral',
      };
    } else if (sellerType === 'Acil İhtiyaçtan') {
      bestPossiblePrice = Math.floor((askingPrice * 0.85) / 1000) * 1000;
      return {
        accepted: false,
        newPrice: bestPossiblePrice,
        sellerMessage: `Nakit lazımdı usta. Madem son fiyat sordun, noter masrafı da içinde en son ${formatMoney(bestPossiblePrice)} yaparım. Uyarsa hemen notere geçelim!`,
        walkedAway: false,
        patienceLeft,
        angerLevel: 'happy',
      };
    } else {
      bestPossiblePrice = Math.floor((askingPrice * 0.92) / 1000) * 1000;
      return {
        accepted: false,
        newPrice: bestPossiblePrice,
        sellerMessage: `Esnaf hatrına ve son söz olarak ${formatMoney(bestPossiblePrice)} derim. Bu fiyata araba kalmadı, hayırlı olsun der misin?`,
        walkedAway: false,
        patienceLeft: Math.max(1, patienceLeft - 1),
        angerLevel: 'neutral',
      };
    }
  }

  // If player offers full asking price or more
  if (playerOfferPrice >= currentPrice) {
    return {
      accepted: true,
      newPrice: currentPrice,
      sellerMessage: 'Anlaştık kardeşim! Noterde buluşalım, hayırlı uğurlu olsun.',
      walkedAway: false,
      patienceLeft,
      angerLevel: 'happy',
    };
  }

  // Tok Satıcı handling
  if (sellerType === 'Tok Satıcı') {
    if (discountPercent > 0.08) {
      const remainingPatience = patienceLeft - 1;
      if (remainingPatience <= 0) {
        return {
          accepted: false,
          newPrice: currentPrice,
          sellerMessage: `${formatMoney(playerOfferPrice)} mi?! Kardeşim ben keyfe keder satıyorum dedim, ölücülük yapma! Bu arabayı sana satmıyorum, ilan kapandı!`,
          walkedAway: true,
          patienceLeft: 0,
          angerLevel: 'angry',
        };
      }
      return {
        accepted: false,
        newPrice: currentPrice,
        sellerMessage: `Dalga mı geçiyorsun usta? ${formatMoney(playerOfferPrice)} teklif mi olur bu arabaya? Fiyatım ${formatMoney(currentPrice)}, kuruş inmem!`,
        walkedAway: false,
        patienceLeft: remainingPatience,
        angerLevel: 'annoyed',
      };
    } else if (playerOfferPrice >= minPrice) {
      return {
        accepted: true,
        newPrice: playerOfferPrice,
        sellerMessage: `Hadi senin ayağına taş değmesin, ${formatMoney(playerOfferPrice)} olsun. Çay parası ikram ettik, hayırlı olsun.`,
        walkedAway: false,
        patienceLeft,
        angerLevel: 'neutral',
      };
    } else {
      const compromise = Math.floor((currentPrice * 0.98) / 1000) * 1000;
      return {
        accepted: false,
        newPrice: compromise,
        sellerMessage: `O fiyata vermem. Sana son bir jest ${formatMoney(compromise)} yaparım, uyarsa al uymazsa kalsın.`,
        walkedAway: false,
        patienceLeft: patienceLeft - 1,
        angerLevel: 'neutral',
      };
    }
  }

  // Extreme lowball check (<75% of asking price)
  if (playerOfferPrice < askingPrice * 0.74) {
    const remainingPatience = patienceLeft - 2;
    if (remainingPatience <= 0) {
      return {
        accepted: false,
        newPrice: currentPrice,
        sellerMessage: `Usta ${formatMoney(playerOfferPrice)} ne demek?! Hurda parasına araba istiyorsun. Pazarlık bitti, iyi günler.`,
        walkedAway: true,
        patienceLeft: 0,
        angerLevel: 'angry',
      };
    }
    return {
      accepted: false,
      newPrice: currentPrice,
      sellerMessage: `Çok öldürdün fiyatı esnaf kardeşim. ${formatMoney(playerOfferPrice)} teklifini duymamış olayım. Ciddi bir rakam söyle.`,
      walkedAway: false,
      patienceLeft: remainingPatience,
      angerLevel: 'annoyed',
    };
  }

  // Direct acceptance condition
  if (playerOfferPrice >= minPrice) {
    let acceptMsg = `Tamamdır esnaf kardeşim, ${formatMoney(playerOfferPrice)} teklifini kabul ediyorum. Hayırlı olsun!`;
    if (tactic === 'nakit') {
      acceptMsg = `Madem nakit hazır ve hemen notere gidiyoruz, ${formatMoney(playerOfferPrice)}'ye verdim gitti. Hayırlı olsun!`;
    } else if (tactic === 'masraf') {
      acceptMsg = `Ekspertiz masrafı lafı olmaz, aramızda kalsın ${formatMoney(playerOfferPrice)} olsun. Anlaştık!`;
    } else if (tactic === 'ikram') {
      acceptMsg = `Sünnettir dedin, seni kırmayalım. ${formatMoney(playerOfferPrice)}'ye bağladık.`;
    }
    return {
      accepted: true,
      newPrice: playerOfferPrice,
      sellerMessage: acceptMsg,
      walkedAway: false,
      patienceLeft,
      angerLevel: 'happy',
    };
  }

  // Counter offer / Middle ground negotiation
  const remainingPatience = patienceLeft - 1;
  if (remainingPatience <= 0) {
    return {
      accepted: false,
      newPrice: currentPrice,
      sellerMessage: `Daha fazla inemem usta, fiyatım ${formatMoney(currentPrice)}. Başka araç bak istersen, hayırlı işler.`,
      walkedAway: true,
      patienceLeft: 0,
      angerLevel: 'neutral',
    };
  }

  // Calculate seller's counter offer
  const middleStep = Math.floor(((currentPrice + minPrice) / 2) / 1000) * 1000;
  const sellerCounter = Math.max(minPrice, middleStep);

  return {
    accepted: false,
    newPrice: sellerCounter,
    sellerMessage: `O rakam beni kurtarmaz usta. Ama seni de kırmayalım, orta yolda ${formatMoney(sellerCounter)} yapayım. Uyarsa el sıkışalım.`,
    walkedAway: false,
    patienceLeft: remainingPatience,
    angerLevel: 'neutral',
  };
};
